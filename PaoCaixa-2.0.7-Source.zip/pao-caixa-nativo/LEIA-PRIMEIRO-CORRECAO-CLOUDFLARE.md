> Referência histórica da 2.0.3. Para instalar, atualizar e publicar a versão atual, siga `GUIA-PaoCaixa-Windows.md`. A configuração Cloudflare já existente foi preservada; esta release não exige recriar o Worker.

# Pão & Caixa 2.0.3 — correção de conexão Cloudflare (teste)

## O que foi corrigido
- Prazo de 3 dias para a primeira validação não expira imediatamente por causa da desserialização de `DateTime.MinValue` em fusos como Brasília.
- Falhas na chamada HTTPS deixam de ser silenciosas. A última consulta é mostrada ao clicar em **Verificar liberação**, e um botão **Testar Cloudflare** aparece em **Painel Biel**.
- Registro do diagnóstico em `%APPDATA%\PaoCaixa\remote-control-diagnostico.txt` (sem senhas/tokens).

## Passos para executar no mesmo Windows
1. Feche o Pão & Caixa e faça uma cópia dos dados locais se houver algo importante.
2. Na pasta `pao-caixa-nativo`, mantenha `resources\remote-control.json` com a URL do seu Worker.
3. Execute `COMPILAR-APLICATIVO-2.0.3.bat` (não altera a instalação antiga).
4. Abra `build\remote-control.json` e confira a URL.
5. Execute `build\PaoCaixa.exe`. Em **Painel Biel**, clique **Testar Cloudflare**. Se estiver bloqueado, clique **Verificar liberação**.
6. Se o teste disser **Conectado ao servidor: instalacao liberada e registrada na Cloudflare**, abra o painel web e atualize a lista.
7. Se houver erro, copie apenas as duas linhas de status do diagnóstico (não envie senhas).

**Não distribua esta compilação em produção ainda.** Teste bloqueio, desbloqueio, perda de rede e atualização antes de gerar o instalador de distribuição.
