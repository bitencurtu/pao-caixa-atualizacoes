using System;
using System.Threading;
namespace PaoCaixa {
 internal sealed class ManualUpdate {
  readonly Updates updates;readonly Func<string> blocked;readonly Action prepare;
  internal Action<CancellationToken> Check;internal Action<Action<int>,CancellationToken> Download;
  internal int CheckTimeout=8000,DownloadTimeout=180000;
  internal ManualUpdate(Updates updater,string channel,string directory,Func<string> blockReason,Action prepareInstall){
   updates=updater;blocked=blockReason;prepare=prepareInstall;
   Check=token=>updates.Check(channel,token);Download=(progress,token)=>updates.Download(channel,directory,progress,token);
  }
  void Report(Action<string> progress,string message){updates.Status=message;progress(message);}
  internal bool Run(Action<string> progress){
   Report(progress,"Verificando atualizações…");
   using(var timeout=new CancellationTokenSource()){timeout.CancelAfter(CheckTimeout);Check(timeout.Token);}
   if(!updates.CheckSucceeded||updates.Available==null)return false;
   var feed=updates.Available;
   if(new Version(feed.version)<=new Version(Updates.Version)){Report(progress,"Você está usando a versão mais recente.");return false;}
   string reason=blocked();if(reason!=null){Report(progress,reason);return false;}
   using(var timeout=new CancellationTokenSource()){
    timeout.CancelAfter(DownloadTimeout);
    Download(percent=>Report(progress,"Baixando atualização: "+percent+"%"),timeout.Token);
   }
   Updates.Verify(updates.Downloaded,feed);
   Report(progress,"Criando backup dos dados…");prepare();
   Updates.Verify(updates.Downloaded,feed);
   Report(progress,"Instalando atualização. O programa será reiniciado…");return true;
  }
 }
}
