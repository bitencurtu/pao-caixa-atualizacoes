@echo off
cd /d "%~dp0"
echo Configure a URL publica HTTPS do seu Cloudflare Worker no arquivo que sera aberto.
echo Exemplo: {"url":"https://seu-worker.seu-usuario.workers.dev/"}
echo.
notepad resources\remote-control.json
