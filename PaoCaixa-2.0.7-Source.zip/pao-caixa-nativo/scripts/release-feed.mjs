import {readFileSync,writeFileSync,statSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {resolve,basename} from 'node:path';
const root=resolve(import.meta.dirname,'..');
const {version}=JSON.parse(readFileSync(resolve(root,'version.json'),'utf8'));
if(!/^\d+\.\d+\.\d+$/.test(version))throw Error('Versão inválida');
const exe=resolve(root,'release',`PaoCaixa-Instalador-${version}-x86.exe`),name=basename(exe);
const bytes=readFileSync(exe),size=statSync(exe).size;
const sha512=createHash('sha512').update(bytes).digest('base64');
const sha256=createHash('sha256').update(bytes).digest('hex');
// Explicit LF and UTF-8 without BOM: the released 2.0.3 updater requires LF.
writeFileSync(resolve(root,'release/latest.yml'),`version: ${version}\nfiles:\n  - url: ${name}\n    sha512: ${sha512}\n    size: ${size}\npath: ${name}\nsha512: ${sha512}\nreleaseDate: '${new Date().toISOString()}'\n`,'utf8');
writeFileSync(resolve(root,'release/SHA256.txt'),`${sha256}  ${name}\n`,'utf8');
console.log(`Release ${version}: ${size} bytes. Manifesto LF, SHA-512 e SHA-256 prontos.`);
