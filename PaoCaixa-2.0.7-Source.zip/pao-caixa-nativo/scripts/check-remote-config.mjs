import fs from 'node:fs';
let config;
try{config=JSON.parse(fs.readFileSync('resources/remote-control.json','utf8'));}catch{console.error('ERRO: resources/remote-control.json nao e JSON valido.');process.exit(1);}
try{const url=new URL(config.url);if(url.protocol!=='https:'||url.username||url.password||url.search||url.hash)throw Error();console.log('Servidor remoto configurado:',url.origin);}catch{console.error('ERRO: configure antes a URL HTTPS do seu Cloudflare Worker em resources/remote-control.json.');process.exit(1);}
