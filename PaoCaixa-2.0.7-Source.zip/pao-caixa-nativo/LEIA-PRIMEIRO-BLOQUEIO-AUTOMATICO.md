> Referência histórica da 2.0.3. Para instalar, atualizar e publicar a versão atual, siga `GUIA-PaoCaixa-Windows.md`. A configuração Cloudflare já existente foi preservada; esta release não exige recriar o Worker.

# Pão & Caixa 2.0.3 — Bloqueio remoto automático (teste)

## O que mudou
- Enquanto o Pão & Caixa estiver aberto, consulta a Cloudflare a cada 15 segundos, em segundo plano.
- Ao receber o status `blocked`, salva o rascunho e muda automaticamente para **Acesso suspenso**, sem precisar reiniciar.
- Ao desbloquear, a tela de suspensão volta automaticamente ao login na próxima consulta. O botão **Verificar liberação** continua funcionando.
- Não reabre a mesma tela de suspensão a cada consulta (evita piscadas).
- Se houver operação em andamento ou diálogo modal, aguarda a finalização da janela para trocar a tela. O backend local impede novas operações depois que o bloqueio é conhecido.
- Após falha de internet, mantém a última decisão conhecida e respeita a política offline existente.
- Reduz gravações de estado em disco (salva mudança de bloqueio imediatamente e renova autorização em intervalos de 5 minutos).

## Como testar
1. Feche a versão anterior e faça um backup de `%APPDATA%\PaoCaixa` se houver dados importantes.
2. Abra `resources\remote-control.json` e confirme a URL do seu Worker (já configurada).
3. Execute `COMPILAR-APLICATIVO-2.0.3.bat`.
4. Execute `build\PaoCaixa.exe` com internet. Ele usa o mesmo banco local do seu usuário.
5. Entre no Pão & Caixa e abra o painel web da Cloudflare. Bloqueie o computador: espere até 15 segundos pela consulta, podendo haver atraso adicional devido à propagação de KV.
6. A tela **Acesso suspenso** deverá aparecer sem fechar o programa. Desbloqueie no painel: o aplicativo deverá retornar ao login automaticamente na próxima consulta.
7. Teste também o botão **Verificar liberação**, internet desconectada e rascunho de venda.

## Importante
- Esta é uma versão do projeto com código-fonte; o `.exe` deve ser compilado no Windows. Não inclui executável recompilado nem é uma atualização publicada no GitHub.
- Não altere o Cloudflare Worker nem `ADMIN_TOKEN`: continuam os mesmos.
- Não publique para clientes antes de testar no Windows o bloqueio, a desconexão, operações em andamento e o instalador.
- O Cloudflare Workers KV tem consistência eventual, portanto não há garantia de bloqueio exatamente em 15 segundos.
