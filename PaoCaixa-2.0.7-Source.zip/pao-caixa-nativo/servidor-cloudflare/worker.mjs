// Pão & Caixa — controle remoto 2.0.3. Cloudflare Worker + KV.
// Bindings: DEVICES (Workers KV), ADMIN_TOKEN (Secret, 32+ bytes aleatórios).
function json(data, code=200) {
 return new Response(JSON.stringify(data), {status:code,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'}});
}
function validId(v) { return typeof v==='string' && /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(v); }
function clean(v,max) {return String(v??'').replace(/[\x00-\x1f\x7f]/g,' ').trim().slice(0,max);}
function isAdmin(req,env) {
 const expected=String(env.ADMIN_TOKEN??'');
 const given=req.headers.get('authorization')??'';
 if(expected.length<32 || !given.startsWith('Bearer '))return false;
 const token=given.slice(7);
 let diff=expected.length^token.length;
 for(let i=0;i<Math.max(expected.length,token.length);i++)diff|=(expected.charCodeAt(i)||0)^(token.charCodeAt(i)||0);
 return diff===0;
}
async function body(req) {
 if(Number(req.headers.get('content-length')||0)>2048)throw new Error('Corpo grande demais');
 const raw=await req.text();
 if(raw.length>2048)throw new Error('Corpo grande demais');
 const val=JSON.parse(raw);if(!val||typeof val!=='object'||Array.isArray(val))throw new Error('JSON inválido');
 return val;
}
const PAGE=`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Pão & Caixa — Controle Remoto</title><style>
:root{font-family:system-ui,Segoe UI,Arial,sans-serif;color:#e2ece2;background:#0d1712}body{max-width:980px;margin:32px auto;padding:0 18px}h1{font-size:26px}small,p{color:#a8bbae}button,input{font:inherit;border-radius:9px;padding:11px;border:1px solid #385845}input{background:#182b20;color:#fff;min-width:260px;max-width:100%}button{cursor:pointer;color:#e7f5e6;background:#255137;border-color:#3b7050;margin:3px}button:hover{background:#306a47}.danger{background:#76302e;border-color:#a8554f}.good{background:#266647}.panel,.item{background:#15271c;border:1px solid #315240;border-radius:12px;padding:17px;margin:13px 0}.row{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}.muted{color:#a8bbae;font-size:13px}.blocked{color:#ffb2a4}.allowed{color:#98ebac}.id{font-family:ui-monospace,Consolas,monospace;overflow-wrap:anywhere}#items:empty:after{content:'Nenhuma instalação registrada até agora.';color:#a8bbae}#message{min-height:24px}</style></head><body><h1>🥖 Pão & Caixa · Controle Remoto</h1><p>Bloqueie ou libere instalações pela internet. Não são enviados dados de vendas.</p><div class="panel"><label for="key">Chave de administrador (segredo do Worker)</label><div class="row"><input id="key" type="password" autocomplete="off" placeholder="Cole sua chave administrativa"><button id="connect">Acessar painel</button><button id="disconnect">Sair</button></div><small>A chave fica apenas nesta aba até você sair. Nunca compartilhe com os computadores dos clientes.</small><p id="message" role="status"></p></div><div class="row"><h2>Computadores registrados</h2><button id="reload">Atualizar lista</button></div><div id="items"></div><script>
const key=document.querySelector('#key'),items=document.querySelector('#items'),msg=document.querySelector('#message');
let token='';async function call(path,opts={}){const r=await fetch(path,{...opts,headers:{'authorization':'Bearer '+token,'content-type':'application/json'}});const v=await r.json();if(!r.ok)throw Error(v.error||'Erro no servidor');return v}
function make(tag,text,cls){let e=document.createElement(tag);e.textContent=text;if(cls)e.className=cls;return e}
async function load(){if(!token){msg.textContent='Informe a chave administrativa.';return;}try{const data=await call('/api/admin/devices');items.replaceChildren();for(const d of data.devices){const card=make('div','','item'),top=make('div','','row'),left=make('div',''),right=make('div','');left.append(make('strong',d.name||d.computer||'Computador sem nome'),make('div',d.id,'id muted'),make('div',d.blocked?'BLOQUEADO':'LIBERADO',d.blocked?'blocked':'allowed'),make('div','Versão: '+(d.version||'—')+' · Último contato registrado: '+(d.lastSeen?new Date(d.lastSeen).toLocaleString('pt-BR'):'—'),'muted'));if(d.reason)left.append(make('div','Motivo: '+d.reason,'muted'));const rename=make('button','Renomear'),toggle=make('button',d.blocked?'Desbloquear':'Bloquear',d.blocked?'good':'danger');rename.onclick=async()=>{const name=prompt('Nome amigável deste computador:',d.name||d.computer||'');if(name===null)return;try{await call('/api/admin/name',{method:'POST',body:JSON.stringify({id:d.id,name})});await load()}catch(e){msg.textContent=e.message}};toggle.onclick=async()=>{const reason=d.blocked?'':prompt('Motivo do bloqueio (opcional):','Acesso suspenso pelo responsável.');if(reason===null)return;if(!confirm((d.blocked?'Liberar':'Bloquear')+' o computador '+(d.name||d.computer||d.id)+'?'))return;try{await call('/api/admin/state',{method:'POST',body:JSON.stringify({id:d.id,blocked:!d.blocked,reason})});await load()}catch(e){msg.textContent=e.message}};right.append(rename,toggle);top.append(left,right);card.append(top);items.append(card)}msg.textContent=data.devices.length+' instalação(ões) encontrada(s).'}catch(e){items.replaceChildren();msg.textContent=e.message}}
document.querySelector('#connect').onclick=()=>{token=key.value;key.value='';load()};document.querySelector('#reload').onclick=load;document.querySelector('#disconnect').onclick=()=>{token='';key.value='';items.replaceChildren();msg.textContent='Sessão encerrada.'};
</script></body></html>`;
export default {
 async fetch(request,env) {
  const path=new URL(request.url).pathname;
  try {
   if(!env.DEVICES)return json({error:'Binding DEVICES (KV) não configurado.'},503);
   if(path==='/' && request.method==='GET')return new Response(PAGE,{headers:{'content-type':'text/html; charset=utf-8','cache-control':'no-store','x-frame-options':'DENY','referrer-policy':'no-referrer','x-content-type-options':'nosniff','content-security-policy':"default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"}});
   if(path==='/api/device' && request.method==='POST'){
    const b=await body(request);if(!validId(b.id))return json({error:'Identificador inválido'},400);
    const key='device:'+b.id;let device=await env.DEVICES.get(key,'json');const now=Date.now();
    if(!device){device={id:b.id,computer:clean(b.computer,80),name:'',version:clean(b.version,30),firstSeen:now,lastSeen:now};await env.DEVICES.put(key,JSON.stringify(device));}
    else if(!device.lastSeen || now-device.lastSeen>12*3600*1000){device.lastSeen=now;device.version=clean(b.version,30);await env.DEVICES.put(key,JSON.stringify(device));}
    const policy=await env.DEVICES.get('policy:'+b.id,'json');
    return json({id:b.id,status:policy&&policy.blocked===true?'blocked':'allowed',reason:policy&&policy.blocked===true?clean(policy.reason,200):''});
   }
   if(path.startsWith('/api/admin/')){
    if(!isAdmin(request,env))return json({error:'Chave administrativa inválida.'},401);
    if(path==='/api/admin/devices'&&request.method==='GET'){
     const all=[];let cursor;
     do{const page=await env.DEVICES.list({prefix:'device:',limit:1000,...(cursor?{cursor}:{})});for(const k of page.keys){const device=await env.DEVICES.get(k.name,'json');if(!device)continue;const policy=await env.DEVICES.get('policy:'+device.id,'json');all.push({...device,blocked:!!(policy&&policy.blocked===true),reason:policy?.reason||''});}cursor=page.list_complete?null:page.cursor;}while(cursor&&all.length<5000);
     all.sort((a,b)=>(b.lastSeen||0)-(a.lastSeen||0));return json({devices:all});
    }
    if(path==='/api/admin/state'&&request.method==='POST'){
     const b=await body(request);if(!validId(b.id)||typeof b.blocked!=='boolean'||typeof b.reason!=='string'||b.reason.length>200)return json({error:'Dados inválidos.'},400);
     if(!await env.DEVICES.get('device:'+b.id))return json({error:'Instalação não registrada.'},404);
     await env.DEVICES.put('policy:'+b.id,JSON.stringify({blocked:b.blocked,reason:clean(b.reason,200),changedAt:Date.now()}));return json({ok:true});
    }
    if(path==='/api/admin/name'&&request.method==='POST'){
     const b=await body(request);if(!validId(b.id)||typeof b.name!=='string'||b.name.length>80)return json({error:'Dados inválidos.'},400);
     const d=await env.DEVICES.get('device:'+b.id,'json');if(!d)return json({error:'Instalação não registrada.'},404);
     d.name=clean(b.name,80);await env.DEVICES.put('device:'+b.id,JSON.stringify(d));return json({ok:true});
    }
   }
   return json({error:'Recurso não encontrado.'},404);
  }catch(e){if(e instanceof SyntaxError||e.message==='Corpo grande demais'||e.message==='JSON inválido')return json({error:'Requisição inválida.'},400);return json({error:'Serviço temporariamente indisponível.'},503);}
 }
};
