# SQLite incluído

- Origem oficial: https://www.sqlite.org/2026/sqlite-dll-win-x86-3540000.zip
- Versão: SQLite 3.54.0, DLL Windows x86.
- SHA3-256 do ZIP original: `98d8e1c16846db4f6348d6bd6e2c2ce5a33a04b837153265c1eb96a34cea3870`.
- Download oficial: https://www.sqlite.org/download.html
- Licença SQLite: domínio público, https://www.sqlite.org/copyright.html

O hash foi conferido antes de extrair `sqlite3.dll`. A DLL importa somente `KERNEL32.dll`; não exige um pacote separado de Visual C++ Runtime. Os backups usam `VACUUM INTO` e incluem as alterações confirmadas no WAL. A DLL x86 deve acompanhar o executável x86, inclusive em Windows de 64 bits.
