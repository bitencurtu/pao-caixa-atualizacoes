> Referência histórica da 2.0.3. Para instalar, atualizar e publicar a versão atual, siga `GUIA-PaoCaixa-Windows.md`. A configuração Cloudflare já existente foi preservada; esta release não exige recriar o Worker.

# Pão & Caixa 2.0.3 — bloqueio remoto

## Primeiro: não publique antes de testar

O Pão & Caixa 2.0.2 **não entende comandos de bloqueio remoto**. A funcionalidade começa nos computadores que **instalarem a 2.0.3**. Não é possível forçar o bloqueio da 2.0.1/2.0.2 apenas publicando um arquivo no GitHub. A release 2.0.3 precisa incluir um instalador compilado no Windows (o ZIP não contém o executável final).

## 1. Hospede seu servidor de controle na Cloudflare

1. Acesse o painel Cloudflare e crie um **Worker**. Use o código de `servidor-cloudflare/worker.mjs` (módulo JavaScript). Publique o Worker e anote a URL HTTPS (`https://...workers.dev`).
2. Na seção de armazenamento KV, crie uma namespace (por exemplo `PAOCAIXA_DEVICES`). Em **Bindings** do Worker, vincule essa namespace como variável **`DEVICES`** (tipo Workers KV).
3. Em **Variables and Secrets** do Worker, crie um **Secret** chamado exatamente **`ADMIN_TOKEN`**. Use um segredo forte e aleatório de pelo menos 32 caracteres. Uma opção para criar 64 caracteres em PowerShell é executar `(New-Guid).ToString('N') + (New-Guid).ToString('N')` e guardar o resultado em um gerenciador de senhas. Não compartilhe esse segredo com clientes, não coloque no GitHub e **nunca** o inclua no app.
4. Abra a URL do Worker no navegador. Será exibido o painel **Pão & Caixa · Controle Remoto**. Digite o segredo para acessar. A lista estará vazia até um PC executar a versão 2.0.3.

O Worker oferece um painel protegido por segredo e dois caminhos: acesso de clientes (sem chave administrativa, apenas para consultar seu próprio status) e acesso administrativo (com segredo). Não há conexão direta ao banco de vendas.

## 2. Vincule o Pão & Caixa ao Worker

1. No projeto, abra `CONFIGURAR-BLOQUEIO-REMOTO.bat`.
2. Edite `resources/remote-control.json` para `{"url":"https://SEU-WORKER.workers.dev/"}` (substitua pela URL real). Salve o arquivo.
3. Execute `COMPILAR-APLICATIVO-2.0.3.bat` para um teste local no Windows, sem alterar sua instalação. Abra `build/PaoCaixa.exe` apenas numa cópia/teste com seus recursos; não copie o executável sobre sua instalação de produção.
4. Para gerar o **instalador de atualização**, execute `GERAR-INSTALADOR.bat`. Ele exige .NET Framework no Windows, NSIS e Node.js. Se a URL ainda estiver vazia, o script **recusará criar a release**.
5. Publique na release `v2.0.3` do repositório GitHub **os quatro arquivos gerados na pasta `release`**, inclusive `latest.yml`. Mantenha o mesmo endereço de release usado pelos clientes nas versões anteriores.

## 3. Faça um teste ANTES de distribuir

1. Instale a 2.0.3 em um computador de teste, mantendo cópia do banco original e backups.
2. Abra o aplicativo com internet. Ele registra seu identificador no Worker; localize-o pelo nome do computador no painel online.
3. Clique em **Bloquear** no painel, com um motivo. No PC de teste clique em **Verificar liberação** se estiver na tela de bloqueio, ou aguarde até dois minutos com a aplicação aberta. A propagação dos dados do Cloudflare KV também pode demorar mais um pouco.
4. Verifique que não é possível entrar/registrar vendas e que o banco e backups não foram apagados.
5. Clique em **Desbloquear** no painel e confira a liberação no PC de teste. Teste também perder internet temporariamente.

## Comportamento de internet e segurança

- Em um PC que **já recebeu bloqueio**, o bloqueio fica gravado e **permanece** se perder internet. Para desbloquear, precisa reconectar e verificar novamente.
- Após uma consulta online com resultado liberado, o programa tem **7 dias de tolerância sem conexão**; depois exige validação online para continuar funcionando. Instalações novas que nunca conseguiram se conectar têm **3 dias iniciais de tolerância**. Isso evita parada imediata numa queda breve de rede, mas não é bloqueio remoto instantâneo de um computador offline.
- O app consulta o Worker ao abrir e a cada **2 minutos** enquanto está rodando. KV usa consistência eventual, portanto mudanças podem levar alguns minutos para aparecer.
- O bloqueio **não apaga vendas, produtos, banco de dados nem backup**. Antes da verificação periódica, o app tenta salvar a venda em andamento. Teste fechamento de caixa e restauração de backup antes de uso comercial.
- O ID de instalação e a decisão em cache ficam em `%APPDATA%\PaoCaixa`. Somente o ID, nome do computador, versão do app e horários aproximados de contato vão ao Worker; **não** são enviados pagamentos, senhas ou vendas.
- **Limitação real:** isso é controle administrativo remoto, não proteção antiviolação. Alguém com controle do Windows pode editar o programa ou os dados locais, e computadores que nunca receberam a 2.0.3 não serão alcançados pelo sistema. Use licenciamento, assinatura de executável e distribuição controlada se precisar impedir adulterações.
- Se não estiver configurado o servidor, o código pode rodar para testes locais sem bloqueio remoto; a geração do instalador exige a URL para evitar releases não configuradas.
