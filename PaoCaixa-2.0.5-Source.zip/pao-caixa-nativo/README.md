# Pão & Caixa 2.0.5

PDV Windows nativo em C# 5, Windows Forms, .NET Framework 4.5+ e SQLite x86. O cliente não precisa de Node, navegador ou GPU dedicada.

## Mudanças desta versão

- Rolagem de catálogo, carrinho e páginas com desaceleração gradual, relógio monotônico e timer ativo somente durante o movimento. O ponteiro direciona a roda para o painel sob o mouse, inclusive sobre seus textos. Grades nativas, listas suspensas e textos multilinha mantêm o comportamento próprio.
- Calendário desenhado com as cores dos temas claro e escuro, setas separadas, destaque da seleção e de hoje. Aceita teclado, anos bissextos, limites de data e abre dentro da área visível da tela. Escape cancela sem mudar o filtro.
- A barra manual e reposicionamentos explícitos interrompem animações pendentes. Redimensionar ou reduzir o conteúdo mantém a posição dentro dos limites.
- As tabelas reutilizam a fonte dos cabeçalhos ao trocar tema. Retornos do download não tentam atualizar janelas encerradas. Desconto inválido desabilita o botão de pagamento até a correção.

A estrutura geral da interface, as regras de vendas e caixa, o esquema SQLite, as contas e os perfis foram preservados. A atualização automática da 2.0.4 continua antes do login, com verificação do instalador, backup e adiamento caso haja caixa aberto ou pedido salvo em qualquer conta. O controle Cloudflare continua em consultas de 15 segundos e com a mesma política offline.

Leia `GUIA-PaoCaixa-Windows.md` para instalação, uso, contas, backup e atualização; `VALIDACAO.md` registra o escopo das verificações. Documentos de testes da 2.0.3 são referências históricas, não o procedimento de publicação atual.

## Estrutura e distribuição

`src` contém o aplicativo; `resources` contém a configuração, exemplos e ícone; `vendor/sqlite` contém a DLL oficial x86; `tests` usa somente dados e senhas fictícios. Os dados reais permanecem em `%APPDATA%\PaoCaixa`, separados da pasta de instalação. O instalador não inclui banco de clientes.

O ZIP `PaoCaixa-2.0.5-Source.zip` é compilado e testado pelo workflow `.github/workflows/publicar.yml`. Pull requests validam sem publicar; main publica como Latest somente após sucesso dos testes. A distribuição tem instalador EXE, `latest.yml` em UTF-8 sem BOM com LF e `SHA256.txt`, todos gerados pela mesma compilação. Não é necessário compilar no computador do cliente.

Os números de versão em `version.json`, `src/Updates.cs`, `src/Program.cs`, `resources/app.manifest` e `installer.nsi` precisam concordar. Para desenvolvimento local, `GERAR-INSTALADOR.bat` é uma alternativa à automação.

## Validação

CoreTests verifica vendas, dinheiro/troco, estoque, caixa, permissões, migração e backups. UpdateTests verifica canal, arquivo, cancelamento, prazos, guardas e instalação automática; a versão futura de teste deriva da versão atual, para não ficar desatualizada a cada release. RemotePolicyTests verifica bloqueio e autorização offline. VisualBehaviorTests verifica calendário, rolagem, roteamento da roda e recursos de interface. UiTests e StartupUiTests percorrem a interface com dados fictícios e geram imagens locais.

O GitHub Actions usa o compilador C# do .NET Framework no Windows, executa os testes, consulta o canal HTTPS real e instala silenciosamente o pacote em uma pasta temporária sem abrir o PDV nem cadastrar PCs de teste na Cloudflare. Windows 7/8, Celeron com 4 GB, DPI e periféricos ainda exigem verificação em equipamento real. O instalador não possui assinatura Authenticode.
