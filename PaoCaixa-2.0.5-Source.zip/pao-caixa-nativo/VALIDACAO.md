# Pão & Caixa 2.0.5 — validação

Base: fonte da 2.0.4 publicada no commit a4b390dc0f7a70a1e8df46dc5bfa3076278e5cb2, blob 1d2be9acc0b2f4199e0f82399134e9840588b2be. A fonte anterior permanece no repositório.

## Escopo

Calendário, animação e encaminhamento da roda do mouse, reaproveitamento da fonte de tabelas, atualização da tela após fechamento e habilitação do pagamento com desconto inválido. Não há alteração de esquema SQLite, operações financeiras, política remota ou permissões.

## Verificações

- 55 verificações de núcleo: SQLite real, migração, produtos, contas, perfis, pedidos privados, dinheiro/troco, pagamentos mistos, estoque, suprimento/sangria, cancelamento e backups.
- 43 verificações de atualização: leitor antigo e novo, formato LF/CRLF/BOM, falhas, hash, backup, cancelamento, prazo, cache, guardas e proteção contra reinícios repetidos.
- 12 verificações de política remota, incluindo UUID persistente e proteção do pedido durante bloqueio.
- 38 verificações específicas de interface: pixels intermediários na rolagem, acumulação e reversão da roda, interrupção manual, redimensionamento, conteúdo reduzido, roda sobre filhos, preservação de controles nativos, fonte reaproveitada, mês/ano e bissexto, limites de data, teclado, cancelamento, tema, abertura repetida e popup dentro da tela.
- Varredura local com imagens dos dois temas, todas as páginas, janelas menores, venda vazia/grande, pagamento, calendário e tela de atualização. Inclui botão de pagamento com desconto inválido e retorno de interface depois de fechar a janela.
- Worker testado com KV simulado; nenhuma instalação real é criada pelos testes.

O workflow Windows executa os quatro grupos de testes acima, testes do Worker e a integração do manifesto com o leitor original da 2.0.3. A integração consulta o canal GitHub HTTPS e instala o NSIS real em pasta temporária, verificando o mutex, versão, dependências e ausência de banco de clientes. A execução do Actions é a evidência da conclusão no Windows; PRs validam sem publicar e main publica somente após sucesso.

## Preservação e limites

Os arquivos de Store, Models, Sqlite, Passwords, Reports, recursos de contas/seed/ícone/configuração CLR/URL Cloudflare e fluxo de atualização foram comparados com a fonte 2.0.4. Os testes usam dados e senhas fictícios. O instalador mantém a pasta de dados e cria backup antes da atualização pelo aplicativo.

Windows 7/8/8.1, Celeron/4 GB, DPI, impressão e falha elétrica exigem testes em equipamento real; o runner Windows não reproduz esses computadores. O instalador não tem assinatura Authenticode. Nenhum segredo administrativo foi alterado no servidor por esta release.
