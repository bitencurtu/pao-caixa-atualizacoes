using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace PaoCaixa {
 internal sealed class ReceiptDocument {
  enum Style { Store, Title, Center, Rule, Section, Item, Normal, Small, Total }
  sealed class Row {
   internal string Text,Value;
   internal Style Style;
  }

  readonly List<Row> rows=new List<Row>();
  internal readonly long Number;
  internal int RowCount {get{return rows.Count;}}

  internal ReceiptDocument(Settings shop,Sale sale,string localDate){
   Number=sale.number;
   Add(shop.name,Style.Store);
   Add("Comprovante de venda #"+sale.number,Style.Title);
   Add(localDate,Style.Center);
   Add("Atendimento: "+sale.operatorName,Style.Center);
   Add(sale.status=="paid"?"Venda concluída":"Venda cancelada",Style.Center);
   Add("",Style.Rule);
   Add("ITENS DA VENDA",Style.Section);
   foreach(var item in sale.items){
    Add(item.name,Style.Item);
    Add(D.Qty(item.quantity,item.unit)+" "+item.unit+" × "+D.Money(item.price),Style.Small,D.Money(item.total));
   }
   Add("",Style.Rule);
   Add("Subtotal",Style.Normal,D.Money(sale.subtotal));
   Add("Desconto",Style.Normal,D.Money(sale.discount));
   Add("TOTAL",Style.Total,D.Money(sale.total));
   Add("PAGAMENTO",Style.Section);
   foreach(var payment in sale.payments){
    int method=Array.IndexOf(D.Methods,payment.method);
    Add(method>=0?D.MethodNames[method]:payment.method,Style.Normal,D.Money(payment.amount));
   }
   Add("Recebido em dinheiro",Style.Normal,D.Money(sale.cashReceived));
   Add("Troco",Style.Normal,D.Money(sale.change));
   if(!string.IsNullOrWhiteSpace(sale.note))Add("Observação: "+sale.note,Style.Small);
   Add("",Style.Rule);
   if(!string.IsNullOrWhiteSpace(shop.footer))Add(shop.footer,Style.Center);
   Add("Comprovante não fiscal",Style.Center);
  }

  void Add(string text,Style style,string value=null){
   rows.Add(new Row{Text=text??"",Value=value,Style=style});
  }

  internal string PlainText(){
   var text=new StringBuilder();
   foreach(var row in rows){
    if(row.Style==Style.Rule)text.AppendLine();
    else text.AppendLine(row.Value==null?row.Text:row.Text+": "+row.Value);
   }
   return text.ToString();
  }

  internal int Draw(Graphics graphics,RectangleF bounds,string via,int first,bool preview,bool measureOnly,out float height){
   using(var normal=new Font("Arial",9))
   using(var small=new Font("Arial",8))
   using(var bold=new Font("Arial",9,FontStyle.Bold))
   using(var title=new Font("Arial",14,FontStyle.Bold))
   using(var total=new Font("Arial",11,FontStyle.Bold))
   using(var accent=new SolidBrush(preview?Color.FromArgb(133,24,36):Color.Black))
   using(var muted=new SolidBrush(preview?Color.FromArgb(91,70,62):Color.Black))
   using(var line=new Pen(preview?Color.FromArgb(229,205,187):Color.Black))
   using(var text=new StringFormat{Trimming=StringTrimming.None})
   using(var centered=new StringFormat(text){Alignment=StringAlignment.Center})
   using(var right=new StringFormat(text){Alignment=StringAlignment.Far}){
    float y=bounds.Top;
    if(!string.IsNullOrEmpty(via)){
     string label=first==0?via.ToUpperInvariant():via.ToUpperInvariant()+" · CONTINUAÇÃO";
     float headingHeight=Measure(graphics,label,small,bounds.Width,centered)+6;
     if(!measureOnly)graphics.DrawString(label,small,muted,new RectangleF(bounds.X,y,bounds.Width,headingHeight),centered);
     y+=headingHeight;
    }
    int index=first;
    for(;index<rows.Count;index++){
     Row row=rows[index];
     Font font=row.Style==Style.Store?title:row.Style==Style.Total?total:
      row.Style==Style.Title||row.Style==Style.Section||row.Style==Style.Item?bold:
      row.Style==Style.Small||row.Style==Style.Center?small:normal;
     var format=row.Style==Style.Store||row.Style==Style.Title||row.Style==Style.Center?centered:text;
     float valueWidth=row.Value==null?0:Math.Min(bounds.Width*.49f,graphics.MeasureString(row.Value,font).Width+2);
     float textWidth=valueWidth==0?bounds.Width:bounds.Width-valueWidth-5;
     float textHeight=row.Style==Style.Rule?10:Measure(graphics,row.Text,font,textWidth,format);
     if(row.Value!=null)textHeight=Math.Max(textHeight,Measure(graphics,row.Value,font,valueWidth,right));
     float padding=row.Style==Style.Total?8:row.Style==Style.Section?5:2;
     float rowHeight=textHeight+padding;
     if(y+rowHeight>bounds.Bottom){
      if(index>first)break;
      if(!preview)throw new InvalidOperationException("A área imprimível está pequena demais. Confira o tamanho do papel no driver.");
     }
     if(!measureOnly&&y+rowHeight>=graphics.VisibleClipBounds.Top&&y<=graphics.VisibleClipBounds.Bottom){
      if(row.Style==Style.Rule)graphics.DrawLine(line,bounds.X,y+5,bounds.Right,y+5);
      else{
       if(preview&&row.Style==Style.Total){
        using(var background=new SolidBrush(Color.FromArgb(255,236,210)))graphics.FillRectangle(background,bounds.X,y,bounds.Width,rowHeight);
       }
       Brush ink=row.Style==Style.Store||row.Style==Style.Section||row.Style==Style.Total?accent:
        row.Style==Style.Center||row.Style==Style.Small?muted:Brushes.Black;
       float top=y+(row.Style==Style.Total?3:0);
       graphics.DrawString(row.Text,font,ink,new RectangleF(bounds.X,top,textWidth,textHeight),format);
       if(row.Value!=null)
        graphics.DrawString(row.Value,font,ink,new RectangleF(bounds.Right-valueWidth,top,valueWidth,textHeight),right);
      }
     }
     y+=rowHeight;
    }
    height=y-bounds.Top;
    return index;
   }
  }

  static float Measure(Graphics graphics,string text,Font font,float width,StringFormat format){
   return (float)Math.Ceiling(graphics.MeasureString(text.Length==0?" ":text,font,new SizeF(Math.Max(width,1),100000),format).Height)+1;
  }
 }

 internal sealed class ReceiptPreview:CanvasView {
  readonly ReceiptDocument receipt;

  internal ReceiptPreview(ReceiptDocument document){
   receipt=document;
   Dock=DockStyle.Fill;
  }

  protected override void OnPaint(PaintEventArgs e){
   var graphics=e.Graphics;
   graphics.Clear(Ui.Bg);
   int viewport=Math.Max(1,ClientSize.Width-ScrollBar.Width);
   int width=Math.Min(390,Math.Max(1,viewport-24));
   if(width<90)return;
   int left=(viewport-width)/2,top=14+ScrollOffset.Y;
   var bounds=new RectangleF(left+15,top+14,width-30,1000000);
   float contentHeight;
   receipt.Draw(graphics,bounds,null,0,true,true,out contentHeight);
   int paperHeight=(int)Math.Ceiling(contentHeight)+28;
   VirtualSize=new Size(0,paperHeight+28);
   graphics.FillRectangle(Brushes.White,left,top,width,paperHeight);
   using(var pen=new Pen(Color.FromArgb(229,205,187)))graphics.DrawRectangle(pen,left,top,width,paperHeight);
   receipt.Draw(graphics,bounds,null,0,true,false,out contentHeight);
  }
 }

 internal static class ReceiptPrinter {
  [StructLayout(LayoutKind.Sequential)]
  struct PrinterInfo {
   public IntPtr Name,Port;
   public uint Attributes,DeviceTimeout,RetryTimeout;
  }
  [DllImport("winspool.drv",CharSet=CharSet.Unicode,SetLastError=true)]
  static extern bool OpenPrinter(string name,out IntPtr printer,IntPtr defaults);
  [DllImport("winspool.drv",CharSet=CharSet.Unicode,SetLastError=true)]
  static extern bool GetPrinter(IntPtr printer,int level,IntPtr buffer,int size,out int required);
  [DllImport("winspool.drv",SetLastError=true)]
  static extern bool ClosePrinter(IntPtr printer);

  static string PortName(string name){
   IntPtr handle;
   if(Environment.OSVersion.Platform!=PlatformID.Win32NT||!OpenPrinter(name,out handle,IntPtr.Zero))return null;
   try{
    int required;
    GetPrinter(handle,5,IntPtr.Zero,0,out required);
    if(required<Marshal.SizeOf(typeof(PrinterInfo)))return null;
    IntPtr buffer=Marshal.AllocHGlobal(required);
    try{
     return GetPrinter(handle,5,buffer,required,out required)?
      Marshal.PtrToStringUni(((PrinterInfo)Marshal.PtrToStructure(buffer,typeof(PrinterInfo))).Port):null;
    }finally{Marshal.FreeHGlobal(buffer);}
   }finally{ClosePrinter(handle);}
  }

  internal static bool IsVirtual(string name,string port){
   if(new[]{"PDF","XPS","ONENOTE","FAX","SEND TO","ENVIAR PARA","DOCUMENT WRITER"}.Any(word=>name.IndexOf(word,StringComparison.OrdinalIgnoreCase)>=0))return true;
   return (port??"").Split(',').Select(part=>part.Trim().ToUpperInvariant())
    .Any(part=>part=="FILE:"||part=="PORTPROMPT:"||part=="NUL:"||part=="NUL"||part=="SHRFAX:");
  }

  internal static string Choose(Form owner,string previouslySelected){
   var devices=PrinterSettings.InstalledPrinters.Cast<string>()
    .Where(name=>!IsVirtual(name,null)&&!IsVirtual(name,PortName(name)))
    .Where(name=>new PrinterSettings{PrinterName=name}.IsValid).ToArray();
   if(devices.Length==0)
    throw new InvalidOperationException("Nenhuma impressora física foi encontrada. Adicione a impressora nas Configurações do Windows e tente novamente.");
   string preferred=devices.FirstOrDefault(name=>string.Equals(name,previouslySelected,StringComparison.OrdinalIgnoreCase))
    ??devices.FirstOrDefault(name=>string.Equals(name,new PrinterSettings().PrinterName,StringComparison.OrdinalIgnoreCase));
   if(preferred!=null)return preferred;
   if(devices.Length==1)return devices[0];
   using(var dialog=new Fields("Impressora do comprovante")){
    dialog.ClientSize=new Size(520,155);
    var printer=dialog.Choice("Impressora",devices);
    return Ui.Show(owner,dialog)==DialogResult.OK?(string)printer.SelectedItem:null;
   }
  }

  internal static void Print(ReceiptDocument receipt,string printer,string via){
   using(var doc=new PrintDocument()){
    doc.PrinterSettings.PrinterName=printer;
    doc.PrinterSettings.PrintToFile=false;
    if(!doc.PrinterSettings.IsValid)throw new InvalidOperationException("A impressora selecionada está indisponível.");
    doc.DocumentName="Pão & Caixa - Venda #"+receipt.Number+" - "+via;
    var page=doc.DefaultPageSettings;
    var printable=page.PrintableArea;
    var sheet=page.Bounds;
    page.Margins=new Margins(Math.Max(7,(int)Math.Ceiling(printable.Left)),
     Math.Max(7,(int)Math.Ceiling(sheet.Width-printable.Right)),
     Math.Max(7,(int)Math.Ceiling(printable.Top)),Math.Max(7,(int)Math.Ceiling(sheet.Height-printable.Bottom)));
    doc.OriginAtMargins=true;
    doc.PrintController=new StandardPrintController();
    int row=0;
    doc.PrintPage+=(sender,e)=>{
     if(e.MarginBounds.Width<60||e.MarginBounds.Height<35)
      throw new InvalidOperationException("Confira o tamanho do papel configurado para esta impressora.");
     float height;
     float width=Math.Min(318,e.MarginBounds.Width);
     float left=(e.MarginBounds.Width-width)/2;
     int next=receipt.Draw(e.Graphics,new RectangleF(left,0,width,e.MarginBounds.Height),via,row,false,false,out height);
     row=next;
     e.HasMorePages=height>0&&row<receipt.RowCount;
    };
    doc.Print();
   }
  }
 }
}
