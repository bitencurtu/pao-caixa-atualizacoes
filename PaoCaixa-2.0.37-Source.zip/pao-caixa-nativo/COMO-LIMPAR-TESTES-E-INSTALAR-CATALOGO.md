﻿# Pão & Caixa 2.0.37 — base limpa da padaria

## O que foi pedido
A versão 2.0.31 apenas somava os produtos novos aos que já existiam. Nesta versão existe a operação **Apagar testes e instalar os 117 produtos**, para deixar exclusivamente os itens que o cliente enviou em 05/11/2026.

## Como usar no computador do cliente (sem acesso remoto)
1. Publique `PaoCaixa-2.0.37-Source.zip` no repositório do GitHub e confira se o Actions terminou verde e gerou a release.
2. Peça ao cliente para atualizar o Pão & Caixa, fechando o caixa e os pedidos primeiro, se o instalador solicitar.
3. No computador da padaria, entre com conta **Administrador** e vá a **Configurações**.
4. Na área **Iniciar catálogo do cliente**, clique **Apagar testes e instalar os 117 produtos**.
5. Confirme que essa é a base de testes que deve ser substituída, e digite **ZERAR TESTES**.
6. O sistema cria backup SQLite completo em `%APPDATA%\\PaoCaixa\\backups`, remove o conteúdo comercial antigo e carrega os 117 itens. Confirme o resultado na aba Produtos.

**Importante:** não ocorre limpeza automática em computadores diferentes da padaria. O mesmo canal do GitHub pode ser usado em outras instalações, e apagar dados nelas seria um erro grave. Se for necessário que a limpeza seja 100% automática *somente* em um computador, identifique a instalação pelo **ID remoto** do painel do proprietário e crie uma atualização direcionada.

## Exatamente o que é limpo
- Produtos antigos e fotos associadas.
- Vendas e seus pagamentos.
- Caixas abertos/fechados, sangrias e suprimentos.
- Movimentações de estoque.
- Pedidos em andamento e rascunhos das contas.
- Histórico de acesso da base de testes, mantendo o registro da operação de limpeza.
- Contador de vendas volta para 1.

## O que é preservado
- Contas de acesso, senhas e permissões.
- Nome da padaria, dados do comprovante e configurações.
- Controle remoto/bloqueio desta instalação.
- Um backup completo com os dados anteriores, para recuperação em caso de erro.

## Como os 117 produtos entram
- Exatamente os 117 itens do arquivo `CATALOGO-CLIENTE-2026-11-05.md`.
- Preços fornecidos pelo cliente; porções de 100 g são cadastradas como equivalente por kg.
- **Estoque inicial = 0**, **custo inicial = 0** (não foram informados). O estoque deve ser ajustado antes de vender.
- A operação só pode acontecer uma vez nesta instalação; reiniciar/atualizar o sistema nunca repetirá a limpeza.
- Se o backup falhar, a limpeza é cancelada. Se uma instrução SQL falhar, a transação é revertida.

## Testes
Testes estáticos executados no ambiente Linux. `CoreTests.cs` contém novos testes reais de SQLite que serão executados pelo GitHub Actions no Windows. A compilação Windows e o teste visual devem ser confirmados na execução do Actions antes de instalar.

## Para quem já instalou e limpou os testes na versão 2.0.32
Ao abrir a versão 2.0.35, o sistema detecta o marcador exclusivo da limpeza anterior e inclui os 24 novos itens. Não execute uma segunda limpeza nem apague vendas. A migração faz backup antes e cria um registro para não repetir. A atualização não adiciona produtos em outras instalações que nunca executaram a limpeza confirmada.
