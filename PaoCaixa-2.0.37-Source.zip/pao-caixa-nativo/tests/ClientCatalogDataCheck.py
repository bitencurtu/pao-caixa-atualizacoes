# -*- coding: utf-8 -*-
# Arquivo gerado apenas para inspeção humana: testes de importação rodam no Windows.
from pathlib import Path
import re
source=(Path(__file__).parent.parent/'src'/'ClientCatalog.cs').read_text(encoding='utf-8-sig')
rows=re.findall(r'new Entry\("',source)
assert len(rows)==117, len(rows)
print('OK: 117 itens no catálogo da atualização')
