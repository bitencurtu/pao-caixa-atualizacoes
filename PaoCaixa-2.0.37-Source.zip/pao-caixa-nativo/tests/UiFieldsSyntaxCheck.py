#!/usr/bin/env python3
"""Preflight for the Fields.Add layout regression seen in version 2.0.27."""
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'src'/'Ui.cs'
s=p.read_text(encoding='utf-8')
start=s.index('  public void Add(string label,Control control){')
end=s.index('  public TextBox TextField(',start)
method=s[start:end]
assert 'control.Height=42;' in method
assert 'control.Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Right;' in method
assert 'table.Controls.Add(control,1,row);' in method
# These expressions must remain executable, never inside // comments.
for line in method.splitlines():
    if '//' in line:
        assert not any(x in line.split('//',1)[1] for x in ('control.Height=','control.Anchor=','table.Controls.Add('))
print('PASS Fields.Add height/anchor statements are not hidden in a line comment')
