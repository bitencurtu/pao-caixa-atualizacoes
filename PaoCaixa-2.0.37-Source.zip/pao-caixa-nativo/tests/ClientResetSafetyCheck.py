# coding: utf-8
"""Static safety gates for the customer test-database reset; CI runs Windows C# CoreTests too."""
from pathlib import Path
import re
root = Path(__file__).resolve().parent.parent
store = (root / 'src/Store.cs').read_text(encoding='utf-8-sig')
main = (root / 'src/MainForm.cs').read_text(encoding='utf-8-sig')
settings = (root / 'src/SettingsPage.cs').read_text(encoding='utf-8-sig')
client = (root / 'src/ClientCatalog.cs').read_text(encoding='utf-8-sig')
assert len(re.findall(r'new Entry\("', client)) == 117, 'Catálogo diferente de 117 produtos'
assert 'db.ApplyClientCatalogOnce();' not in main, 'Não importar automaticamente em canal compartilhado'
assert 'ResetDemoDataAndInstallClientCatalog' in settings and 'db.Admin()' in settings
assert 'ZERAR TESTES' in settings and 'MessageBoxButtons.YesNo' in settings
start = store.index('public string ResetDemoDataAndInstallClientCatalog()')
end = store.index('public void AdjustStock', start)
reset = store[start:end]
assert reset.index('Backup("antes-limpar-testes")') < reset.index('sql.Transaction('), 'Backup deve ser anterior a transação'
assert 'ClientResetApplied()' in reset and 'client_data_resets' in reset
for table in ['product_photos','stock_moves','cash_moves','sales','sessions','products','user_drafts','draft']:
    assert f'"{table}"' in reset, f'Tabela {table} não limpa'
assert 'DELETE FROM users' not in reset and 'DELETE FROM installation_control' not in reset
assert 'next_sale=1' in reset and 'D.Validate(LoadRaw())' in reset
print('PASS: 117 itens, limpeza protegida, backup, consistência, sem importação global')

# A importação incremental só é executada após a limpeza confirmada anteriormente.
extra = store[store.index('public int AppendClientCatalogExtrasAfterReset()'):store.index('const string ClientResetKey=')]
assert "client_data_resets" in extra and "ClientCatalog.ExtrasMigrationKey" in extra
assert extra.index('ClientResetKey') < extra.index('Backup("antes-produtos-adicionais")')
assert 'AppendClientCatalogExtrasAfterReset()' in main
assert 'importa os 117 itens' in settings
print('PASS: 24 novos itens protegidos por reset prévio e marcador único')
