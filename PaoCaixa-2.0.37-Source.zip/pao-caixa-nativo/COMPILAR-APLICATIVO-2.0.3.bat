@echo off
setlocal DisableDelayedExpansion
cd /d "%~dp0"
title Pao e Caixa - Compilar 2.0.29
set "PDV_CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%PDV_CSC%" (
 echo ERRO: Instale o .NET Framework 4.8 para compilar no Windows.
 pause
 exit /b 1
)
if not exist "build" mkdir "build"
"%PDV_CSC%" /nologo /codepage:65001 /target:winexe /platform:x86 /optimize+ /out:build\PaoCaixa.exe /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:System.Web.Extensions.dll /reference:System.Core.dll /resource:resources\seed.json,seed.json /resource:resources\catalog-extras.json,catalog-extras.json /resource:resources\catalog-photos.jpg,catalog-photos.jpg /resource:resources\owner-bootstrap.json,owner-bootstrap.json /resource:resources\icon.ico,icon.ico /win32manifest:resources\app.manifest /win32icon:resources\icon.ico src\*.cs
if errorlevel 1 (
 echo ERRO: Nao foi possivel compilar. Nenhuma instalacao foi modificada.
 pause
 exit /b 1
)
copy /y "resources\PaoCaixa.exe.config" "build\PaoCaixa.exe.config" >nul
copy /y "resources\remote-control.json" "build\remote-control.json" >nul
copy /y "vendor\sqlite\sqlite3.dll" "build\sqlite3.dll" >nul
copy /y "resources\icon.ico" "build\icon.ico" >nul
echo OK: Aplicativo compilado em build\PaoCaixa.exe
pause
