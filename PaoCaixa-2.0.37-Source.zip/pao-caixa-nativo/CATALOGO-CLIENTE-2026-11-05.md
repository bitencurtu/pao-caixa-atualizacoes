# Catálogo do cliente — atualizado em 05/11/2026

**117 produtos:** 93 da lista anterior + 24 novos itens de bebidas e manteigas.

A inicialização dos 117 produtos é **manual e exclusiva da instalação escolhida**, com confirmação de administrador; **a publicação no GitHub não apaga nada automaticamente**.

Se a instalação já executou a limpeza na 2.0.32, a atualização adiciona **apenas os 24 novos itens** automaticamente nessa instalação, sem alterar estoques, preços personalizados, custos, vendas ou caixas existentes.

Preços de produtos novos em reais; estoque e custo inicial = zero. Itens de 100 g usam preço equivalente por kg no PDV.

| Código | Produto | Unidade | Preço |
|---|---|---|---:|
| PXC-C2611-001 | Pão francês | un | R$ 0,50 |
| PXC-C2611-002 | Pão de banha | un | R$ 0,50 |
| PXC-C2611-003 | Batata frita (pacote) | un | R$ 28,00 |
| PXC-C2611-004 | Pão de queijo (pacote) | un | R$ 21,00 |
| PXC-C2611-005 | Palitinho parmesão (pacote) | un | R$ 35,00 |
| PXC-C2611-006 | Frango a passarinho / coxinha da asa (pacote) | un | R$ 21,00 |
| PXC-C2611-007 | Salsicha (pacote 500 g) | un | R$ 9,00 |
| PXC-C2611-008 | Linguiça Aurora (por kg) | kg | R$ 28,00 |
| PXC-C2611-009 | Linguiça Aurora (pacote fechado) | un | R$ 95,00 |
| PXC-C2611-010 | Hambúrguer (unidade) | un | R$ 2,00 |
| PXC-C2611-011 | Geladinho pequeno | un | R$ 0,50 |
| PXC-C2611-012 | Geladinho grande | un | R$ 1,00 |
| PXC-C2611-013 | Paçoca | un | R$ 0,50 |
| PXC-C2611-014 | Pirulito grande | un | R$ 1,00 |
| PXC-C2611-015 | Pirulito pequeno | un | R$ 0,35 |
| PXC-C2611-016 | Bala | un | R$ 0,20 |
| PXC-C2611-017 | Pé de moça | un | R$ 3,00 |
| PXC-C2611-018 | Bala de goma | un | R$ 1,00 |
| PXC-C2611-019 | Doce de leite | un | R$ 3,00 |
| PXC-C2611-020 | Pão de mel | un | R$ 6,00 |
| PXC-C2611-021 | Caixa de bombom | un | R$ 20,00 |
| PXC-C2611-022 | Suco em pó | un | R$ 1,50 |
| PXC-C2611-023 | Café (pacote 500 g) | un | R$ 22,00 |
| PXC-C2611-024 | Nescal | un | R$ 15,00 |
| PXC-C2611-025 | Fósforo | un | R$ 1,00 |
| PXC-C2611-026 | Gelatina | un | R$ 2,50 |
| PXC-C2611-027 | Salgadinho | un | R$ 3,00 |
| PXC-C2611-028 | Miojo | un | R$ 3,00 |
| PXC-C2611-029 | Extrato de tomate | un | R$ 3,50 |
| PXC-C2611-030 | Melitta | un | R$ 5,50 |
| PXC-C2611-031 | Guardanapo | un | R$ 3,50 |
| PXC-C2611-032 | Farinha de trigo | un | R$ 4,00 |
| PXC-C2611-033 | Tapioca | un | R$ 6,00 |
| PXC-C2611-034 | Óleo | un | R$ 10,00 |
| PXC-C2611-035 | Leite | un | R$ 7,50 |
| PXC-C2611-036 | Arroz (pacote 5 kg) | un | R$ 24,00 |
| PXC-C2611-037 | Feijão (pacote 1 kg) | un | R$ 10,00 |
| PXC-C2611-038 | Vinagre | un | R$ 3,50 |
| PXC-C2611-039 | Pimenta | un | R$ 5,50 |
| PXC-C2611-040 | Macarrão | un | R$ 4,50 |
| PXC-C2611-041 | Açúcar | un | R$ 6,00 |
| PXC-C2611-042 | Bolacha coquinho | un | R$ 7,00 |
| PXC-C2611-043 | Bolacha maizena | un | R$ 7,00 |
| PXC-C2611-044 | Bolacha recheada | un | R$ 3,00 |
| PXC-C2611-045 | Sal | un | R$ 4,00 |
| PXC-C2611-046 | Pipoca de micro-ondas | un | R$ 5,00 |
| PXC-C2611-047 | Pipoca (pacote) | un | R$ 5,00 |
| PXC-C2611-048 | Sardinha | un | R$ 10,00 |
| PXC-C2611-049 | Creme de leite | un | R$ 4,50 |
| PXC-C2611-050 | Leite condensado | un | R$ 6,50 |
| PXC-C2611-051 | Fermento | un | R$ 4,50 |
| PXC-C2611-052 | Detergente | un | R$ 3,50 |
| PXC-C2611-053 | Sabonete | un | R$ 3,00 |
| PXC-C2611-054 | Pasta de dente | un | R$ 5,50 |
| PXC-C2611-055 | Desinfetante pequeno | un | R$ 5,00 |
| PXC-C2611-056 | Desinfetante grande | un | R$ 8,00 |
| PXC-C2611-057 | Amaciante grande | un | R$ 12,00 |
| PXC-C2611-058 | Amaciante pequeno | un | R$ 6,50 |
| PXC-C2611-059 | Cloro | un | R$ 9,00 |
| PXC-C2611-060 | Sabão em pó grande | un | R$ 24,00 |
| PXC-C2611-061 | Sabão em pó pequeno | un | R$ 12,00 |
| PXC-C2611-062 | Veja | un | R$ 5,00 |
| PXC-C2611-063 | Papel higiênico (12 rolos) | un | R$ 24,00 |
| PXC-C2611-064 | Papel higiênico (4 rolos) | un | R$ 9,00 |
| PXC-C2611-065 | Papel-toalha | un | R$ 9,00 |
| PXC-C2611-066 | Pão carteira | un | R$ 0,50 |
| PXC-C2611-067 | Pão coco queimado | un | R$ 0,50 |
| PXC-C2611-068 | Pão de milho | un | R$ 0,70 |
| PXC-C2611-069 | Pão de creme | un | R$ 1,50 |
| PXC-C2611-070 | Rosquinha | un | R$ 0,75 |
| PXC-C2611-071 | Rosquinha de leite | un | R$ 0,50 |
| PXC-C2611-072 | Broa de milho | un | R$ 1,50 |
| PXC-C2611-073 | Croissant | un | R$ 6,00 |
| PXC-C2611-074 | Empada | un | R$ 5,00 |
| PXC-C2611-075 | Palitinho parmesão (unidade) | un | R$ 3,00 |
| PXC-C2611-076 | Baguete | un | R$ 1,00 |
| PXC-C2611-077 | Língua de sogra | un | R$ 3,00 |
| PXC-C2611-078 | Sonho | un | R$ 5,00 |
| PXC-C2611-079 | Lua de mel | un | R$ 1,50 |
| PXC-C2611-080 | Pão de queijo (100 g) | kg | R$ 35,00 |
| PXC-C2611-081 | Chipa (100 g) | kg | R$ 45,00 |
| PXC-C2611-082 | Mortadela tradicional (100 g) | kg | R$ 35,00 |
| PXC-C2611-083 | Mortadela defumada (100 g) | kg | R$ 40,00 |
| PXC-C2611-084 | Presunto (100 g) | kg | R$ 40,00 |
| PXC-C2611-085 | Mussarela (100 g) | kg | R$ 60,00 |
| PXC-C2611-086 | Pão de frios | un | R$ 3,00 |
| PXC-C2611-087 | Pão com manteiga | un | R$ 1,50 |
| PXC-C2611-088 | Pão com 2 fatias de frios | un | R$ 5,00 |
| PXC-C2611-089 | Café puro pequeno | un | R$ 1,00 |
| PXC-C2611-090 | Café puro grande | un | R$ 3,00 |
| PXC-C2611-091 | Café com leite | un | R$ 3,50 |
| PXC-C2611-092 | Chocolate quente | un | R$ 3,00 |
| PXC-C2611-093 | Leite puro | un | R$ 3,00 |
| PXC-C2611-094 | Manteiga Qualy (500 g) | un | R$ 12,00 |
| PXC-C2611-095 | Manteiga outras marcas (500 g) | un | R$ 10,00 |
| PXC-C2611-096 | Manteiga pequena | un | R$ 7,50 |
| PXC-C2611-097 | Água | un | R$ 3,00 |
| PXC-C2611-098 | Água com gás | un | R$ 4,00 |
| PXC-C2611-099 | Água (1,5 L) | un | R$ 5,00 |
| PXC-C2611-100 | Toddy | un | R$ 3,00 |
| PXC-C2611-101 | Suco de caixa grande | un | R$ 8,00 |
| PXC-C2611-102 | Suco de caixa pequeno | un | R$ 3,00 |
| PXC-C2611-103 | Refrigerante pequeno | un | R$ 3,00 |
| PXC-C2611-104 | Refrigerante lata | un | R$ 4,50 |
| PXC-C2611-105 | Suco de garrafinha | un | R$ 5,00 |
| PXC-C2611-106 | Dolly (2 L) | un | R$ 8,00 |
| PXC-C2611-107 | Tiss (2 L) | un | R$ 6,00 |
| PXC-C2611-108 | Itubaína (2 L) | un | R$ 8,00 |
| PXC-C2611-109 | Cruzeiro (2 L) | un | R$ 7,00 |
| PXC-C2611-110 | Sukita (2 L) | un | R$ 8,00 |
| PXC-C2611-111 | Guaraná (2,5 L) | un | R$ 12,00 |
| PXC-C2611-112 | Kuat (2 L) | un | R$ 7,00 |
| PXC-C2611-113 | Coca-Cola (2,5 L) | un | R$ 14,00 |
| PXC-C2611-114 | Pepsi (2,5 L) | un | R$ 12,00 |
| PXC-C2611-115 | Frutuba (2 L) | un | R$ 6,00 |
| PXC-C2611-116 | Água de coco (caixa pequena) | un | R$ 3,50 |
| PXC-C2611-117 | H2O | un | R$ 8,00 |
