# Pão & Caixa 2.0.4 — validação

Base: ZIP publicado no commit 81cc1732c54b380c24c0a705ca265d8d39fab275, blob Git 303aa4592cce7d1be95b888c1e1bd50e08958acc. A release 2.0.3 e seu manifesto foram obtidos diretamente do repositório; o ZIP teve SHA e CRC conferidos.

## Causa e transição

O latest.yml da 2.0.3 contém CRLF. O leitor original não reconhece os campos de topo porque sua expressão regular exclui CR e ancora no fim da linha. O teste usa o arquivo publicado e o leitor original sem mudanças para reproduzir a falha. Normalizar o mesmo arquivo para LF elimina a falha. O manifesto 2.0.4 com LF também é aceito e permite comparar versão e verificar o instalador no leitor 2.0.3.

## Verificações locais

- Compilação C# 5/x86 e NSIS concluídas em Linux/Mono.
- 55 verificações funcionais com SQLite real e fixture criada pelas rotinas antigas.
- 43 verificações de atualização, incluindo parser antigo, CRLF/LF/BOM, hashes, falhas, backup, cancelamento, timeout, cache, antirregressão e proteção contra reinícios repetidos.
- 12 verificações de licença remota: prazo offline, bloqueio explícito, UUID em fallback e preservação do pedido sem liberar comandos comerciais.
- Testes do Worker com KV simulado: cadastro, autenticação, apelido, bloqueio e desbloqueio.
- Instalador local e metadados consistentes; parser 2.0.3 verifica o mesmo arquivo final. Não foram usadas contas ou bancos de clientes.

## Verificações obrigatórias no GitHub Actions

O workflow compila com o .NET Framework do runner Windows, repete testes funcionais/de atualização/licença, consulta o canal HTTPS real e valida o instalador NSIS em pasta temporária. Confere a espera pelo mutex do aplicativo, versão do EXE, SQLite, configurações e ausência de banco incluído. Pull requests validam sem publicar; somente main publica após esses passos. O log do Actions é a evidência da execução, não este documento.

## Preservação

Models, Sqlite, Passwords, Reports, controles de catálogo/tema/datas/rolagem e páginas comerciais comparados com a base publicada. Recursos proprietário/seed/logo/configuração CLR/URL Cloudflare também preservados. Nenhuma mudança de esquema ou cálculo financeiro. Store recebe apenas guardas de manutenção e preservação do rascunho durante suspensão; permissões comerciais permanecem.

## Limites

Instalação e comportamento em Windows 7/8/8.1, Celeron/4 GB, DPI, impressão e falha elétrica precisam de teste em equipamento real. O instalador é sem assinatura digital de editor; SHA-512 e HTTPS não substituem Authenticode. O segredo ADMIN_TOKEN não foi alterado no servidor nesta mudança e precisa de rotação na Cloudflare antes de distribuição comercial.
