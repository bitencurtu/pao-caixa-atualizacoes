using System;
using System.Drawing;
using System.Windows.Forms;
namespace PaoCaixa {
 // Paint visible rows in one control instead of creating a window per card.
 public class CanvasView:Panel {
  public readonly VScrollBar ScrollBar=new VScrollBar{Dock=DockStyle.Right,Width=16,Visible=false};
  Size virtualSize;
  readonly Timer wheel=new Timer{Interval=16};int start,target;DateTime began;bool moving,animating;
  public CanvasView(){DoubleBuffered=true;ResizeRedraw=true;Controls.Add(ScrollBar);ScrollBar.ValueChanged+=(sender,e)=>{if(!animating){wheel.Stop();moving=false;}Invalidate();};AutoScroll=false;wheel.Tick+=(sender,e)=>{double t=Math.Min(1,(DateTime.UtcNow-began).TotalMilliseconds/150),ease=1-Math.Pow(1-t,3);animating=true;ScrollBar.Value=Math.Max(0,Math.Min(MaximumOffset,(int)Math.Round(start+(target-start)*ease)));animating=false;if(t>=1){wheel.Stop();moving=false;}};}
  public Size VirtualSize {get{return virtualSize;}set{virtualSize=value;UpdateRange();}}
  public Point ScrollOffset {get{return new Point(0,-ScrollBar.Value);}set{ScrollBar.Value=Math.Max(0,Math.Min(Math.Abs(value.Y),MaximumOffset));Invalidate();}}
  int MaximumOffset {get{return Math.Max(0,virtualSize.Height-Math.Max(1,ClientSize.Height));}}
  void UpdateRange(){if(ScrollBar==null)return;wheel.Stop();moving=false;int height=Math.Max(1,ClientSize.Height),value=Math.Min(ScrollBar.Value,MaximumOffset);ScrollBar.Minimum=0;ScrollBar.Value=0;ScrollBar.LargeChange=height;ScrollBar.SmallChange=32;ScrollBar.Maximum=Math.Max(height,virtualSize.Height)-1;ScrollBar.Value=value;ScrollBar.Visible=virtualSize.Height>height;Invalidate();}
  protected override void OnSizeChanged(EventArgs e){base.OnSizeChanged(e);UpdateRange();}
  protected override void OnMouseWheel(MouseEventArgs e){if(!ScrollBar.Visible){base.OnMouseWheel(e);return;}var handled=e as HandledMouseEventArgs;if(handled!=null)handled.Handled=true;start=ScrollBar.Value;target=Math.Max(0,Math.Min(MaximumOffset,(moving?target:start)-(int)Math.Round(e.Delta*72d/120)));began=DateTime.UtcNow;moving=true;wheel.Start();}
  protected override void Dispose(bool disposing){if(disposing)wheel.Dispose();base.Dispose(disposing);}
 }
}
