> **Novidade 2.0.4:** veja `COMO-ATIVAR-BLOQUEIO-REMOTO.md` para configurar o painel Cloudflare, compilar e publicar a nova versão. O restante deste guia documenta o procedimento histórico da 2.0.4; NÃO use nomes/tags da 2.0.4 para publicar a 2.0.4.

> **Nota da correcao 2.0.4 para Windows:** o executavel 2.0.4 compilado no Mono do ZIP original foi retirado por incompatibilidade com .NET Framework (TrimEnd(Char)). Para instalar a correcao, siga `LEIA-PRIMEIRO-ATUALIZACAO-2.0.4.md`. Os testes Linux/Mono descritos abaixo sao de uma compilacao anterior e nao validam o binario recompilado no Windows.

# Pão & Caixa 2.0.4 — versão leve para Windows

## O que mudou na 2.0.4

O manifesto da release 2.0.3 usava quebras de linha CRLF. O leitor antigo não reconhecia versão, arquivo e hash nesse formato e mostrava uma mensagem genérica de falta de conexão. A 2.0.4 aceita LF, CRLF e BOM, e informa se houve erro de manifesto, HTTP, TLS/certificado, DNS ou conexão. A automação gera sempre UTF-8 sem BOM com LF, permitindo que a própria 2.0.3 encontre a atualização sem alterar o banco.

Ao iniciar, o programa verifica e instala versões novas antes de liberar o login. A busca tem um limite de oito segundos; o download tem limite de três minutos e pode ser interrompido com **Continuar sem atualizar**. Se não houver atualização ou a conexão falhar, o login é liberado conforme a autorização remota da instalação. Caixa aberto ou pedido pendente de qualquer conta adia a instalação. Antes de instalar, o arquivo é verificado e um backup completo é criado. O instalador trabalha na mesma pasta e reabre o programa. Uma tentativa não concluída não entra em ciclo de reinícios; o administrador pode tentar novamente em Configurações.

**Alterar canal** confirma o endereço salvo na própria página e inicia a verificação. Os temas, controles de data, paginação com setas, logo, rolagem suave e resumo fixo da Venda Atual foram preservados. Não houve refatoração geral da navegação entre páginas.

O PDV continua nativo, em C# / Windows Forms / .NET Framework, com SQLite local e executável x86. A URL da Cloudflare, os perfis e a conta proprietária permanecem. O controle remoto continua consultando a cada 15 segundos; mudanças de bloqueio são aplicadas quando é seguro fechar a tela ou diálogo. O último pedido é guardado antes da suspensão. Nenhum dado de vendas ou finanças é enviado à Cloudflare.

## Instalar ou trocar a versão anterior

1. Na versão anterior, crie um backup completo. Conclua os pedidos e feche o caixa.
2. Feche o Pão & Caixa. Execute **PaoCaixa-Instalador-2.0.4-x86.exe** no mesmo usuário do Windows que usa o PDV.
3. O instalador procura a pasta da versão anterior. Mantenha essa pasta para substituir o programa e os atalhos.
4. Abra o programa e entre com sua conta existente. Confira produtos, estoque, contas, vendas e saldos antes de usar no balcão.

O banco continua em `%APPDATA%\PaoCaixa\padaria.sqlite`. Contas, senhas já alteradas, bloqueio da instalação e pedidos por usuário são preservados. Antes da primeira abertura nativa de um banco existente é criada uma cópia em `%APPDATA%\PaoCaixa\backups`. As tabelas comerciais permanecem no mesmo formato, e os índices novos não mudam os valores das vendas. Não instale deliberadamente uma versão mais antiga sobre a nova.

Se o banco estiver corrompido ou pertencer a uma versão de formato desconhecida, o programa para e preserva o arquivo original; ele não substitui os dados por exemplos.

### .NET Framework

O instalador exige .NET Framework 4.5 ou mais recente. Em computadores atuais ele normalmente já vem com o Windows. Para Windows 7 SP1 e 8.1, instale o [Runtime .NET Framework 4.8 da Microsoft](https://dotnet.microsoft.com/pt-br/download/dotnet-framework/net48). Windows 8 original tem o 4.5 integrado; se precisar reparar ou atualizar, o [instalador oficial 4.6.1](https://www.microsoft.com/pt-br/download/details.aspx?id=49982) lista Windows 8. O 4.8 não se aplica ao Windows 8 original. Windows e .NET antigos não recebem o mesmo suporte dos sistemas atuais.

O instalador do PDV não inclui nem baixa automaticamente o .NET. Você pode levar o instalador offline da Microsoft por pendrive e instalar esse pré-requisito uma vez. O funcionamento das vendas não precisa de internet, GPU dedicada, navegador ou Node.js.

## Atualização e publicação pelo GitHub

O canal padrão continua:

`https://github.com/bitencurtu/pao-caixa-atualizacoes/releases/latest/download/`

O repositório é `bitencurtu/pao-caixa-atualizacoes`. O código fica no ZIP da raiz **PaoCaixa-2.0.4-Source.zip**, contendo a pasta `pao-caixa-nativo`. O workflow `.github/workflows/publicar.yml` seleciona a versão, compila em Windows, gera o instalador NSIS, gera `latest.yml` com LF e hashes, testa e publica uma release nova como Latest. As releases antigas nunca são substituídas.

Para uma alteração futura, revise o código e os números de versão, envie um ZIP novo à raiz do repositório e deixe o GitHub Actions compilar. Uma pull request executa a validação sem publicar; a publicação ocorre após integrar em `main`. Não é necessário executar arquivos BAT ou montar instaladores no computador do cliente. O instalador e os dois arquivos de metadados são gerados pela mesma compilação. Não envie arquivos de banco à release.

A 2.0.3 ainda utiliza a atualização manual em **Configurações → Procurar atualização → Baixar atualização → Instalar e reiniciar**. O manifesto LF da 2.0.4 é compatível com esse leitor. Conclua os pedidos e feche o caixa para instalar. Após instalar a 2.0.4 uma vez, as próximas versões passam a ser procuradas e instaladas automaticamente na abertura. Computadores que ainda tenham problemas de certificados/TLS ou .NET podem receber o instalador normal diretamente da release, mantendo os dados existentes.

O download verifica tamanho e SHA-512, mantém arquivos incompletos separados e não instala versões antigas. HTTPS valida o servidor do canal configurado pelo proprietário. O instalador não possui assinatura digital de editor: hash e HTTPS verificam integridade e confiança no canal, mas não equivalem a assinatura Authenticode. O Windows ou antivírus pode mostrar aviso de editor desconhecido.

## Política de bloqueio remoto e uso offline

A URL permanece `https://paocaixa-controle.biel-bitencourt01.workers.dev/`. Somente dados de identificação do computador e versão são enviados ao Worker; o SQLite comercial continua local. O aplicativo nunca recebe `ADMIN_TOKEN`.

Uma instalação nova mantém a tolerância existente de três dias sem primeira validação. Depois de uma autorização válida, a tolerância offline é de sete dias. Uma instalação explicitamente bloqueada permanece bloqueada durante falhas de rede, até receber uma autorização válida do servidor. Bloqueio e desbloqueio são consultados em segundo plano a cada 15 segundos, sem recriar a página a cada consulta. A política não foi ampliada pela atualização automática.

Quando o Windows não fornece MachineGuid/SID, um UUID válido já salvo é reutilizado, para que o bloqueio e a tolerância não sejam reiniciados a cada abertura. O arquivo de estado deve ser preservado junto com a pasta de dados. Não é um DRM resistente a quem controla o Windows e modifica o aplicativo ou seus arquivos.

O segredo administrativo da Cloudflare deve ser substituído no painel da Cloudflare antes da distribuição comercial, pois foi compartilhado anteriormente. Ele não deve aparecer em código, commits ou aplicativo de cliente. A troca do segredo exige acesso autorizado à conta Cloudflare; o programa cliente não precisa ser recompilado por isso.

## Contas e caixa

Somente a conta proprietária de Biel, `biel.bitencourt01@gmail.com`, tem **Meu painel** (painel de Biel), cria contas, redefine senhas das outras contas e bloqueia/desbloqueia a instalação localmente. Essa conta não pode ser removida, rebaixada ou desativada. Para mudar a própria senha, use **Meu perfil**. A senha inicial não está escrita neste guia nem no código; o programa guarda uma derivação com salt. Senhas existentes continuam válidas na migração.

| Perfil | Acesso |
| --- | --- |
| Operador | Pedidos, abertura e movimentos do próprio caixa atual; consulta às vendas desse caixa. Não vê custo, períodos fechados ou o caixa de outra pessoa. |
| Financeiro | Consulta de vendas e finanças, relatórios e CSV. Não faz pedidos nem opera caixa. |
| Administrador | Operações da padaria, cadastros, estoque, relatórios, backups e atualização. |
| Proprietário | Tudo do administrador, além do painel de contas e bloqueio local. |

Você pode montar o pedido antes de abrir o caixa. **Abrir caixa** informa o fundo de troco e mantém os itens. Ao finalizar uma venda em dinheiro, o valor da venda entra no caixa automaticamente; o troco é descontado do valor recebido. Suprimento é dinheiro extra colocado no caixa, e sangria é retirada. Não registre a venda novamente como suprimento.

O pagamento permite dinheiro, Pix, débito, crédito ou divisão entre esses meios. A confirmação é manual: não há integração com maquininha ou banco nesta versão. Leituras de código via equipamento que digita como teclado podem preencher a busca de pedidos; o código precisa estar cadastrado. Peso é informado em kg. Balanças e etiquetas com peso codificado continuam dependendo de integração específica.

**Produtos mais vendidos** é ordenado pela quantidade, com grupos separados para unidades e kg. Vendas canceladas não entram no faturamento nem no ranking. A margem bruta é o total das vendas após descontos menos o custo dos produtos vendidos; ela não inclui outras despesas.

## Backups e recuperação

- **Backup completo**: cópia SQLite consistente, incluindo contas, senhas derivadas, pedidos em andamento e bloqueio. Guarde cópias fora deste computador.
- **Backup comercial JSON**: produtos, vendas, caixas e movimentos. Não inclui contas, senhas, bloqueio ou pedidos privados.
- **Restaurar JSON**: valida os dados, cria um backup completo anterior, substitui o conteúdo comercial e mantém as contas. Pedidos anteriores são limpos. Um caixa importado aberto fica vinculado ao administrador que fez a restauração.
- Backup diário: uma cópia ao abrir o programa, com retenção das últimas 30 cópias diárias. Cópias manuais e de migração/restauração/atualização ficam preservadas.

Para recuperar um **backup completo**, feche o programa, guarde uma cópia da pasta inteira `%APPDATA%\PaoCaixa` e recupere o arquivo `.sqlite` como `padaria.sqlite`. Faça isso com ajuda técnica: arquivos antigos `padaria.sqlite-wal` e `padaria.sqlite-shm` não podem ser reaproveitados junto a outro banco. Nenhuma atualização usa esse procedimento; atualizações preservam o banco existente.

## Desenvolvimento e próxima versão

O ZIP contém C#, recursos, testes e a DLL oficial SQLite. Os números em `version.json`, `src/Updates.cs`, `src/Program.cs`, `resources/app.manifest` e `installer.nsi` precisam concordar. O GitHub Actions é o caminho de distribuição. `GERAR-INSTALADOR.bat` continua apenas como alternativa para desenvolvimento local; os clientes recebem o instalador, sem ferramentas de compilação.

Os testes verificam que o manifesto gerado seja aceito tanto pelo leitor novo quanto pelo leitor original da 2.0.3. O build Windows usa o compilador do .NET Framework e C# 5; chamadas como TrimEnd e Split utilizam arrays de caracteres compatíveis. Os testes de integração instalam o pacote silenciosamente em uma pasta temporária, verificando a espera pelo fechamento do programa e as dependências, sem abrir o PDV nem registrar computadores de teste na Cloudflare.

## Validação e limites

A entrega é verificada com dados fictícios. Os testes locais incluem vendas, caixa, estoque, permissões, contas, backup, parser antigo/novo, cancelamento, falhas e política de bloqueio. Antes de publicar, o GitHub Actions deve passar na compilação e nos mesmos testes no Windows, consultar o canal real e verificar o instalador final. O resultado de cada execução fica no Actions do repositório.

Windows 7/8/8.1, computadores Celeron com 4 GB, DPI, impressão e interrupção de energia continuam exigindo conferência em equipamentos reais. O ambiente de compilação e teste Windows do Actions não substitui essas verificações de campo.
