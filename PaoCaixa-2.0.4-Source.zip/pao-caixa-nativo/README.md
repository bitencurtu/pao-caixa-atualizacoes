# Pão & Caixa 2.0.3 — controle remoto

A versão 2.0.3 adiciona uma consulta remota por instalação e um painel Cloudflare Worker + KV. **Comece por `COMO-ATIVAR-BLOQUEIO-REMOTO.md`.** Instalações 2.0.1/2.0.4 não têm suporte a essa consulta.

O projeto não inclui um instalador 2.0.3 pré-compilado. Não distribua binários da 2.0.4 como se fossem 2.0.3. Os testes Windows do cliente ainda devem ser executados antes da publicação.

Nota: a correção de compatibilidade com .NET Framework 2.0.4 foi preservada. A validação antiga da versão 2.0.4 não equivale a uma validação compilada desta 2.0.3.

# Pão & Caixa — Windows nativo 2.0.3

PDV local em C# 5, Windows Forms, .NET Framework 4.5+ e SQLite 3.54.0 x86. Não usa Electron, Chromium, WebView, React nem Node na execução do caixa. Node é usado no desenvolvimento e na automação para testes e geração dos metadados de atualização; não é dependência do caixa.

Leia [GUIA-PaoCaixa-Windows.md](GUIA-PaoCaixa-Windows.md) para instalação, migração, uso, backups e publicação. O arquivo `GERAR-INSTALADOR.bat` gera a distribuição Windows. `version.json`, `src/Program.cs`, `src/Updates.cs`, `installer.nsi` e o manifesto precisam usar o mesmo número da versão.

## Estrutura

- `src`: interface nativa e operações protegidas por perfil, incluindo login e proprietário imutável.
- `resources`: exemplos para primeira instalação, derivação scrypt da conta proprietária, ícone, manifesto e configuração CLR.
- `vendor/sqlite`: DLL oficial x86, sem outras bibliotecas de runtime C; origem e hash documentados em `SQLITE-ORIGEM.md`.
- `tests`: testes funcionais/migração, varredura das telas e benchmark.
- `scripts/release-feed.mjs`: cria SHA-256 e `latest.yml` com SHA-512, UTF-8 sem BOM e LF compatível com a 2.0.3.
- `build/PaoCaixa.exe`: executável compilado da entrega; não substitui o instalador para distribuição.

## Banco e desempenho

Usa `%APPDATA%\PaoCaixa\padaria.sqlite`, mantendo o esquema SQLite 2 e JSON comercial 1 da versão 1.2.1. Escreve somente linhas alteradas, dentro de `BEGIN IMMEDIATE` com `synchronous=FULL`; finalização de venda, baixa de estoque, número de venda e limpeza do próprio pedido são atômicos. Acrescenta índices JSON em datas, sessões e produto. Não substitui banco inválido por dados de exemplo.

Antes da primeira migração há validação comercial completa e backup consistente. Nas aberturas seguintes usa `quick_check` e consultas pequenas. O instalador mantém os dados em outra pasta e usa o mesmo GUID e pasta da instalação anterior. A senha usa scrypt N=131072/r=8/p=1, compatível com os registros anteriores; a derivação consome temporariamente cerca de 128 MiB e roda no worker. A escolha de tema fica nas preferências locais.

Todos os comandos verificam a conta e permissões no núcleo; ocultar uma aba não é a autorização. Operador só consulta o seu caixa aberto, financeiro não grava operações, somente proprietário gerencia contas e bloqueio. Backups comerciais não modificam contas. O acesso local não oferece proteção contra quem controla o sistema operacional e altera diretamente arquivos ou executáveis.

Downloads HTTPS com limites, timeout, hash SHA-512 e recusa de downgrade; verificação e download ficam fora da thread da interface. Instalação somente sem caixa aberto ou qualquer pedido, com backup completo criado antes. O executável é distribuído sem assinatura digital do editor; hash não substitui assinatura.

## Testes

Os testes usam senhas e dados fictícios. A senha real inicial não está escrita no projeto. Para criar a fixture antiga, execute `node tests/create-legacy-fixture.mjs CAMINHO_NOVO`. As três rotinas antigas usadas para criar a fixture estão em `tests/legacy` como referência de migração e não entram no instalador.

Compile `tests/CoreTests.cs` junto com `src/*.cs`, referências Windows Forms/Drawing/Web.Extensions/Core e os recursos JSON usando `/main:CoreTests`. Execute no diretório da fixture. `UiTests.cs` compila com todos os arquivos usando `/main:UiTests` e um diretório de screenshots. Em Linux/Mono use Xvfb e a configuração de mapeamento `sqlite3 -> libsqlite3.so.0`; a configuração de teste pode ser vazia quando o Mono foi extraído sem instalação. A configuração de produção é a destinada ao CLR Windows.

Veja `VALIDACAO.md` para resultados e limitações. Ainda é necessário testar instalação, atualização Electron → nativo e integração com impressora no Windows real antes de distribuir para produção.


## Ajustes de interface na 2.0.4

Menu lateral e identidade do projeto anterior, catálogo em cartões com categorias, carrinho à direita, indicadores e ranking em cartões. As regras de vendas, caixa, permissões e banco permanecem. F2 busca produtos; F4 e F12 abrem o pagamento. O catálogo pinta somente cartões visíveis em um controle, para limitar o custo de interface. A versão mantém temas claro e escuro.

Campos de data desenhados com a paleta do programa e calendário nativo em popup; escolha de tema segmentada; paginação separada com setas; logo proveniente do mesmo icon.ico. Venda atual sem rolagem externa, com resumo fixo e linhas compactas quando necessário. CanvasView e SmoothPanel interpolam somente a rolagem por roda (150 ms), sem timer ativo em repouso. Root, Run e LoadPage mantêm o fluxo anterior; a troca de guias não recebeu correção de piscadas.

## Distribuição automática

O workflow compila e testa no Windows antes de publicar. A 2.0.4 consulta e instala atualizações ao iniciar, com backup e bloqueio de instalação se houver caixa ou pedido aberto. A 2.0.3 consegue fazer a transição pelo manifesto LF. Controle remoto Cloudflare permanece em consultas de 15 segundos, com tolerância offline de 3 dias na primeira instalação e 7 dias após autorização; bloqueio explícito não é revogado por falha de conexão.

O parser aceita LF/CRLF/BOM; erros de formato, HTTP, TLS e DNS são distinguidos. Alterar canal confirma o endereço salvo e testa o novo canal. UUID em fallback e preservação do último pedido em suspensão remota foram corrigidos. O esquema SQLite e os cálculos comerciais permanecem.
