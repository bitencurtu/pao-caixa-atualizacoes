> **Novidade 2.0.3:** veja `COMO-ATIVAR-BLOQUEIO-REMOTO.md` para configurar o painel Cloudflare, compilar e publicar a nova versão. O restante deste guia documenta o procedimento histórico da 2.0.2; NÃO use nomes/tags da 2.0.2 para publicar a 2.0.3.

> **Nota da correcao 2.0.2 para Windows:** o executavel 2.0.2 compilado no Mono do ZIP original foi retirado por incompatibilidade com .NET Framework (TrimEnd(Char)). Para instalar a correcao, siga `LEIA-PRIMEIRO-ATUALIZACAO-2.0.2.md`. Os testes Linux/Mono descritos abaixo sao de uma compilacao anterior e nao validam o binario recompilado no Windows.

# Pão & Caixa 2.0.2 — versão leve para Windows

## O que mudou

A versão 2.0.2 mantém a interface restaurada da 2.0.1 e refina os controles: campos de data arredondados com calendário, seletor Claro/Escuro com sol e lua, paginação separada com setas e a mesma logo de pão do ícone da janela no menu lateral. A Frente de caixa deixa de rolar como página inteira: desconto, observação, total e pagamento ficam sempre acessíveis. Em janela menor, o cabeçalho e o resumo ficam compactos; só a lista de produtos e, em pedidos maiores, a lista de itens têm rolagem. Catálogo e painéis passam a ter rolagem suave, acionada apenas ao usar a roda do mouse. As piscadas na troca de guias foram analisadas, mas esse fluxo não foi alterado.

O programa mantém a base nativa do Windows (Windows Forms / .NET Framework), sem abrir uma cópia do Chromium. Controles como calendário, barras de rolagem e moldura das janelas seguem o Windows instalado. O desenho foi reconstruído para manter a aparência e a organização anteriores; não depende de um navegador. O executável é de 32 bits e pode ser usado em Windows de 32 ou 64 bits. A interface e o instalador foram preparados para Windows 7 SP1, 8, 8.1, 10 e 11, mas a instalação nesses sistemas e o desempenho em Celeron com 4 GB ainda precisam de teste em computadores reais.

As vendas gravam apenas os registros alterados em transações SQLite. O histórico tem consultas com índices e páginas de 100 vendas; relatórios e CSV leem lotes de 500 registros. A tela de produtos exibe até 300 resultados por busca. Os cartões do catálogo são desenhados em um único controle, e apenas os que estão visíveis são pintados. Não há sombras pesadas nem animação contínua; a rolagem interpola por 150 ms e para quando termina. Relatórios e configurações usam rolagem quando necessário; a janela inicial respeita o espaço disponível na tela. Senhas, backups e consultas demoradas rodam fora da thread da interface. Não é possível prometer ausência absoluta de travamentos: disco, antivírus, sistema operacional e tamanho dos dados também influenciam.

No topo, clique em **Claro** (sol) ou **Escuro** (lua). A escolha muda imediatamente e fica salva neste usuário do Windows.

## Instalar ou trocar a versão anterior

1. Na versão anterior, crie um backup completo. Conclua os pedidos e feche o caixa.
2. Feche o Pão & Caixa. Execute **PaoCaixa-Instalador-2.0.2-x86.exe** no mesmo usuário do Windows que usa o PDV.
3. O instalador procura a pasta da versão anterior. Mantenha essa pasta para substituir o programa e os atalhos.
4. Abra o programa e entre com sua conta existente. Confira produtos, estoque, contas, vendas e saldos antes de usar no balcão.

O banco continua em `%APPDATA%\PaoCaixa\padaria.sqlite`. Contas, senhas já alteradas, bloqueio da instalação e pedidos por usuário são preservados. Antes da primeira abertura nativa de um banco existente é criada uma cópia em `%APPDATA%\PaoCaixa\backups`. As tabelas comerciais permanecem no mesmo formato, e os índices novos não mudam os valores das vendas. Não instale deliberadamente uma versão mais antiga sobre a nova.

Se o banco estiver corrompido ou pertencer a uma versão de formato desconhecida, o programa para e preserva o arquivo original; ele não substitui os dados por exemplos.

### .NET Framework

O instalador exige .NET Framework 4.5 ou mais recente. Em computadores atuais ele normalmente já vem com o Windows. Para Windows 7 SP1 e 8.1, instale o [Runtime .NET Framework 4.8 da Microsoft](https://dotnet.microsoft.com/pt-br/download/dotnet-framework/net48). Windows 8 original tem o 4.5 integrado; se precisar reparar ou atualizar, o [instalador oficial 4.6.1](https://www.microsoft.com/pt-br/download/details.aspx?id=49982) lista Windows 8. O 4.8 não se aplica ao Windows 8 original. Windows e .NET antigos não recebem o mesmo suporte dos sistemas atuais.

O instalador do PDV não inclui nem baixa automaticamente o .NET. Você pode levar o instalador offline da Microsoft por pendrive e instalar esse pré-requisito uma vez. O funcionamento das vendas não precisa de internet, GPU dedicada, navegador ou Node.js.

## Publicar uma atualização sem depender de mim

O canal padrão já é:

`https://github.com/bitencurtu/pao-caixa-atualizacoes/releases/latest/download/`

1. Extraia **PaoCaixa-Atualizacao-2.0.2.zip**.
2. Crie uma release no seu repositório público, com tag **v2.0.2** e título **Pão & Caixa 2.0.2**.
3. Anexe os quatro arquivos: instalador `.exe`, `.exe.blockmap`, `latest.yml` e `SHA256.txt`. Não renomeie os arquivos.
4. Para liberar esta atualização ao canal do programa, selecione **Latest** e publique. Confira que os quatro anexos aparecem. Se quiser publicar somente para teste antes, pode usar **Pre-release** e depois mudar para **Latest**. A instalação e o desempenho precisam ser conferidos no Windows antes de distribuir aos caixas.

   Crie uma nova release **v2.0.2**, mesmo que já tenha publicado a 2.0.1. Não misture o instalador novo com os metadados da versão anterior; é possível atualizar diretamente da 1.2.1 para a 2.0.2.
5. Nos computadores, use **Configurações → Procurar atualização → Baixar atualização**. Depois feche o caixa e conclua/limpe os pedidos de todas as contas. Clique em **Instalar e reiniciar**.

O download roda em segundo plano e verifica tamanho e SHA-512 antes da instalação. Se a internet falhar, as vendas locais continuam. Antes de instalar, o programa cria um backup; se esse backup falhar, a instalação é impedida. O instalador nunca inclui banco da padaria nem sobrescreve a pasta de dados.

Os computadores na versão **1.2.1**, que ainda estavam com o canal vazio, precisam configurar o endereço acima ou receber este instalador manualmente uma vez. A partir da versão 2.0.0, o endereço já vem definido; canais personalizados válidos existentes são mantidos. Em Windows muito antigo, certificados e TLS precisam estar atualizados para acessar o GitHub.

O instalador não tem assinatura digital de editor. O Windows pode mostrar aviso de editor desconhecido. A verificação por hash e HTTPS não equivale a uma assinatura de autoria.

## Contas e caixa

Somente a conta proprietária de Biel, `biel.bitencourt01@gmail.com`, tem **Meu painel** (painel de Biel), cria contas, redefine senhas das outras contas e bloqueia/desbloqueia a instalação localmente. Essa conta não pode ser removida, rebaixada ou desativada. Para mudar a própria senha, use **Meu perfil**. A senha inicial não está escrita neste guia nem no código; o programa guarda uma derivação com salt. Senhas existentes continuam válidas na migração.

| Perfil | Acesso |
| --- | --- |
| Operador | Pedidos, abertura e movimentos do próprio caixa atual; consulta às vendas desse caixa. Não vê custo, períodos fechados ou o caixa de outra pessoa. |
| Financeiro | Consulta de vendas e finanças, relatórios e CSV. Não faz pedidos nem opera caixa. |
| Administrador | Operações da padaria, cadastros, estoque, relatórios, backups e atualização. |
| Proprietário | Tudo do administrador, além do painel de contas e bloqueio local. |

Você pode montar o pedido antes de abrir o caixa. **Abrir caixa** informa o fundo de troco e mantém os itens. Ao finalizar uma venda em dinheiro, o valor da venda entra no caixa automaticamente; o troco é descontado do valor recebido. Suprimento é dinheiro extra colocado no caixa, e sangria é retirada. Não registre a venda novamente como suprimento.

O pagamento permite dinheiro, Pix, débito, crédito ou divisão entre esses meios. A confirmação é manual: não há integração com maquininha ou banco nesta versão. Leituras de código via equipamento que digita como teclado podem preencher a busca de pedidos; o código precisa estar cadastrado. Peso é informado em kg. Balanças e etiquetas com peso codificado continuam dependendo de integração específica.

**Produtos mais vendidos** é ordenado pela quantidade, com grupos separados para unidades e kg. Vendas canceladas não entram no faturamento nem no ranking. A margem bruta é o total das vendas após descontos menos o custo dos produtos vendidos; ela não inclui outras despesas.

## Backups e recuperação

- **Backup completo**: cópia SQLite consistente, incluindo contas, senhas derivadas, pedidos em andamento e bloqueio. Guarde cópias fora deste computador.
- **Backup comercial JSON**: produtos, vendas, caixas e movimentos. Não inclui contas, senhas, bloqueio ou pedidos privados.
- **Restaurar JSON**: valida os dados, cria um backup completo anterior, substitui o conteúdo comercial e mantém as contas. Pedidos anteriores são limpos. Um caixa importado aberto fica vinculado ao administrador que fez a restauração.
- Backup diário: uma cópia ao abrir o programa, com retenção das últimas 30 cópias diárias. Cópias manuais e de migração/restauração/atualização ficam preservadas.

Para recuperar um **backup completo**, feche o programa, guarde uma cópia da pasta inteira `%APPDATA%\PaoCaixa` e recupere o arquivo `.sqlite` como `padaria.sqlite`. Faça isso com ajuda técnica: arquivos antigos `padaria.sqlite-wal` e `padaria.sqlite-shm` não podem ser reaproveitados junto a outro banco. Nenhuma atualização usa esse procedimento; atualizações preservam o banco existente.

## Gerar a próxima versão a partir do projeto

O ZIP de projeto contém o código C#, recursos, DLL SQLite oficial, scripts, testes e uma cópia do executável compilado. Para alterar o sistema, alguém precisa modificar o código; para apenas publicar os arquivos compilados que você recebeu, não precisa instalar ferramentas de desenvolvimento.

Em um computador de desenvolvimento Windows, instale o compilador C# / .NET Framework e [NSIS](https://nsis.sourceforge.io/Download), além de Node.js somente para gerar o blockmap de compatibilidade com o atualizador antigo. Execute **GERAR-INSTALADOR.bat**. O script gera o instalador, blockmap, `latest.yml` e `SHA256.txt` em `release`.

Ao criar uma versão nova, atualize o número em `src/Program.cs`, `src/Updates.cs`, `installer.nsi` e `version.json`, atualize este guia e recompile. Publique todos os anexos da mesma compilação. Não reutilize `latest.yml` nem blockmap de outra versão. O código-fonte e arquivos de banco não devem ser anexados à release pública.

## Validação desta entrega

Testes de migração, senha scrypt compatível com Node, isolamento dos perfis, vendas, caixa, estoque, cancelamento, backups, tema e validação de atualização foram executados em Linux/Mono com SQLite real. A interface também é verificada nesse ambiente. Esses testes não substituem a instalação no Windows, a atualização da versão Electron no Windows nem teste em Celeron com 4 GB. Comece com uma cópia do banco e um computador de teste antes de distribuir para caixas em operação.
