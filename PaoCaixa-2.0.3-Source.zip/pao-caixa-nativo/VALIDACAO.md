> **Validação 2.0.3:** os testes do Worker foram executados com Node.js (arquivo `tests/RemoteServerTests.mjs`). O executável C# 2.0.3 e o instalador NSIS NÃO foram compilados/testados no Windows neste ambiente. O restante relata os testes históricos anteriores, não comprova a versão 2.0.3.

> **Nota da correcao 2.0.2 para Windows:** o executavel 2.0.2 compilado no Mono do ZIP original foi retirado por incompatibilidade com .NET Framework (TrimEnd(Char)). Para instalar a correcao, siga `LEIA-PRIMEIRO-ATUALIZACAO-2.0.2.md`. Os testes Linux/Mono descritos abaixo sao de uma compilacao anterior e nao validam o binario recompilado no Windows.

# Validação — Pão & Caixa 2.0.2

## Resultado

- Compilação C# 5 para executável Windows x86, CLR v4; instalador NSIS compilado sem avisos.
- **55 verificações funcionais passaram** com SQLite real e fixture criada pelas rotinas da versão 1.2.1.
- **3 verificações adicionais passaram**: migração do esquema SQLite 1 para 2 com pedido compartilhado preservado, hash do instalador real, rejeição de instalador adulterado.
- **26 capturas da interface**: login nos dois temas, nove páginas em tema claro, nove em tema escuro, pedidos em janelas de 820×590 e 820×551 pixels, calendário aberto, venda vazia, pedido grande e diálogo de pagamento. Navegação executada em Windows Forms no Mono/Xvfb, capturas revisadas; não é teste de Windows real.
- Bootstrap da conta proprietária copiado sem alterações do projeto 1.2.1. Não há senha real em texto simples no projeto.
- DLL SQLite oficial x86 com SHA3-256 conferido, importando somente KERNEL32.dll. Executável nativo usa CLR/.NET Framework.
- `latest.yml`, SHA-512, SHA-256 e blockmap foram gerados a partir do mesmo instalador final. ZIPs com integridade CRC conferida; nenhum inclui banco da padaria.

## Cobertura funcional

Migração mantém produtos, vendas, caixas, movimentos, hashes/salts, versões das credenciais e pedidos privados. O proprietário continua protegido por triggers SQLite. Os testes cobrem bloqueio/desbloqueio, consulta financeira, restrições de operador e administrador comum, atualização impedida com caixa ou qualquer pedido aberto, pagamento misto, desconto, troco, baixa e estorno de estoque, estorno de caixa sem repetição, sangria acima do saldo, restauração comercial mantendo contas e rejeição de backup inconsistente. Ranking continua por quantidade e separa unidade e peso.

## Preservação das regras nesta correção

Models.cs, Store.cs, Sqlite.cs, Passwords.cs, Preferences.cs e Reports.cs foram comparados byte a byte com o projeto 2.0.1 salvo: todos permanecem idênticos. Bootstrap proprietário e dados iniciais também ficam intactos. As alterações estão nos controles e na apresentação; datas conservam valores DateTime e os mesmos limites do período, com validação explícita de datas impossíveis. Não há alteração de esquema, cálculo de venda, saldo, senha ou permissões.

Root, Run e LoadPage foram comparados com a 2.0.1 e continuam sem alterações. Não foi aplicada correção das piscadas ao trocar de guia, a pedido do usuário.

Testes de interface conferem clique no produto, +/−, escolha de tema por clique e teclado sem perda do pedido, campos preenchidos, campos de data e rejeição de dia inválido, calendário em popup, setas e separação da paginação, ausência de rolagem externa na Frente de caixa e posição visível de desconto/observação/total/pagamento em janelas menores. A rolagem do catálogo interpola em vez de saltar; o timer para depois do movimento. Pedidos maiores mantêm rolagem somente na lista de itens, com resumo e pagamento fixos.

## Medição de desempenho

Medições abaixo realizadas na base 2.0.0, preservada nesta correção de interface; não são um novo benchmark da interface 2.0.2. Ambiente de medição: Linux x64, Mono 6.8, SQLite 3.45 do ambiente; a distribuição Windows usa SQLite 3.54.0 x86. Histórico sintético com 10.000 vendas e uma sessão. Valores são deste ambiente e não podem ser usados como promessa para Celeron, Windows ou discos antigos.

| Operação | Medição |
| --- | ---: |
| Primeira migração + validação completa | 2.026 ms |
| Derivação scrypt e login compatível | 2.549 ms |
| 20 novas vendas sobre 10.000 antigas | 57 ms no total |
| Uma página de histórico (101 registros, 100 exibidos) | 28 ms |
| Memória gerenciada depois de coleta | 4 MiB |
| Reabertura do banco já nativo | 4 ms |

Memória gerenciada não é a memória total do programa. Login consome temporariamente aproximadamente 128 MiB para scrypt; sistema, interface, bibliotecas e buffers têm custos adicionais. Relatórios e CSV usam lotes, mas agregação de rankings ainda cresce com o número de produtos distintos.

O instalador final tem aproximadamente **1,2 MB**, contra cerca de 114,5 MB do instalador 1.2.1. O .NET Framework é um pré-requisito separado, normalmente já instalado em Windows atuais; seu tamanho não está contado no instalador do PDV.

## Conferências pendentes no equipamento real

Instalação no Windows 7 SP1, 8, 8.1, 10 e 11; execução em Celeron/4 GB, DPI e fontes Windows; atualização automática da versão Electron para a nativa; bloqueio de arquivo pelo antivírus; impressão e integração futura com periféricos. GitHub/TLS e certificados em sistemas antigos também dependem da configuração do Windows. Testar com uma cópia do banco antes de trocar um caixa em produção.

Não houve teste físico de interrupção de energia. SQLite usa transações, WAL e synchronous=FULL, mas o resultado diante de falha elétrica também depende do sistema de arquivos e do equipamento.
