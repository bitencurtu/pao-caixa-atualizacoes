﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;

namespace PaoCaixa {
 class CatalogPhotoTests {
  static int count;
  static void Check(bool pass,string label){if(!pass)throw new Exception("CATALOG_FAILED "+label);count++;Console.WriteLine("CATALOG_PASS "+label);}
  [STAThread]static void Main(string[] args){
   var data=J.Read<State>(Store.Resource("seed.json"));
   var sample=J.Read<List<Product>>(Store.Resource("catalog-extras.json"));
   Check(data.products.Count==46,"46 bakery products on first installation");
   Check(sample.Count==30,"30 supplementary products");
   Check(data.products.Select(x=>x.code).Distinct(StringComparer.OrdinalIgnoreCase).Count()==46,"unique product codes");
   Check(data.products.Select(x=>x.photoKey).Distinct().Count()==46,"each standard product has own photo");
   Check(sample.All(x=>x.stock==0&&x.cost==0),"new products never create imaginary inventory or costs");
   foreach(var item in data.products){
    Check(ProductPhotos.HasPhoto(item),"photo mapped for "+item.name);
    using(var img=new Bitmap(180,126))
    using(var g=Graphics.FromImage(img)){
     g.Clear(Color.White);
     Check(ProductPhotos.Draw(g,item,new Rectangle(0,0,180,126)),"offline image renders for "+item.name);
     var color=img.GetPixel(80,45);
     Check(color.R!=255||color.G!=255||color.B!=255,"photo resource paints pixels for "+item.name);
    }
   }
   using(var db=new Store(args[0])){
    db.Login(Store.OwnerEmail,"Teste-Pdv-2026");
    var before=db.Products();
    Check(before.Count==16,"existing store initially has legacy catalog");
    var previous=before.First();
    long previousPrice=previous.price;
    int added=db.ImportExampleProducts();
    Check(added==30,"imports only missing 30 items");
    Check(db.Products().Count==46,"legacy store now has 46 products");
    Check(db.ImportExampleProducts()==0,"second import never duplicates products");
    var after=db.Products();
    Check(after.First(x=>x.id==previous.id).price==previousPrice,"original price untouched");
    Check(after.Where(x=>x.code.StartsWith("PXC")).All(x=>x.stock==0),"new products have zero stock");
    var chosen=after.First(x=>x.code=="PXC101");
    Check(chosen.photoKey=="ex-101","added product retains corresponding photo association");
    chosen.name="Pão de forma da casa";
    db.SaveProduct(chosen);
    Check(db.Products().First(x=>x.id==chosen.id).photoKey=="ex-101","photo association persists after rename");

    // A custom image is stored as JPEG inside SQLite, never as a mutable external file.
    string selected=Path.Combine(args[0],"imagem-cliente.png");
    using(var bitmap=new Bitmap(600,400)){
     using(var paint=Graphics.FromImage(bitmap))paint.Clear(Color.MediumVioletRed);
     bitmap.Save(selected,System.Drawing.Imaging.ImageFormat.Png);
    }
    var compressed=ProductPhotos.PreparePhoto(selected);
    Check(ProductPhotos.IsJpeg(compressed)&&compressed.Length<=ProductPhotos.MaxPhotoBytes,"customer PNG is resized and converted to bounded JPEG");
    db.SaveProduct(chosen,compressed);
    Check(db.ProductPhoto(chosen.id).SequenceEqual(compressed),"customer photo stored inside SQLite");
    ProductPhotos.SetCustomPhotos(db.ProductImages());
    using(var image=new Bitmap(180,126))using(var gfx=Graphics.FromImage(image)){
     gfx.Clear(Color.White);
     Check(ProductPhotos.Draw(gfx,chosen,new Rectangle(0,0,180,126)),"custom picture is painted in the product catalog");
     Check(image.GetPixel(80,45).R>80,"custom photo visibly replaces built-in atlas");
    }
    chosen.name="Pão da casa com foto";
    db.SaveProduct(chosen);
    Check(db.ProductPhoto(chosen.id).SequenceEqual(compressed),"editing product without photo change preserves original");
    var fullBackup=db.Backup("manual");
    using(var backupDb=new Sqlite(fullBackup)){
     Check(((byte[])backupDb.Scalar("SELECT image FROM product_photos WHERE product_id=?",chosen.id)).SequenceEqual(compressed),"full SQLite backup contains custom photos");
    }
    var commercial=db.Export();
    Check(commercial.productPhotos.ContainsKey(chosen.id),"commercial JSON contains custom photos");
    Check(D.Validate(commercial)!=null,"photo-bearing commercial data passes validation");
    db.SaveProduct(chosen,null,true);
    Check(db.ProductPhoto(chosen.id)==null,"remove photo deletes only custom picture");
    db.Restore(commercial,db.Revision());
    Check(db.ProductPhoto(chosen.id).SequenceEqual(compressed),"commercial restore returns customer photo");
    db.SaveProduct(chosen,null,true);
    Check(db.ProductPhoto(chosen.id)==null,"photo removal works after backup restore");

    // Product units can be fixed in a real establishment without rewriting old stock history.
    db.SaveProduct(new Product{name="Pão avulso (teste)",code="PXC-UNIT24",category="Pães",unit="kg",price=1600,cost=700,stock=2750,minStock=500,active=true,icon="bread"});
    var bread=db.Products().First(x=>x.code=="PXC-UNIT24");
    var originalBreadId=bread.id;
    Check(bread.unit=="kg"&&bread.stock==2750,"fixture uses decimal kg stock");
    bread.unit="un";bread.price=100;bread.cost=35;bread.stock=35000;bread.minStock=5000;
    db.SaveProduct(bread);
    var individual=db.Products().First(x=>x.id==originalBreadId);
    Check(individual.unit=="un"&&individual.stock==35000&&individual.minStock==5000,"kg to un change uses explicitly provided whole pieces");
    Check(individual.price==100&&individual.cost==35,"price and cost adjusted per piece");
    var movements=db.StockHistory(individual.id);
    Check(movements.Any(move=>move.quantity==-2750&&move.unit=="kg")&&movements.Any(move=>move.quantity==35000&&move.unit=="un"),"stock records distinguish original kg from new pieces");
    Check(movements.Any(move=>move.reason=="Estoque inicial"&&move.unit=="kg"),"old stock record is annotated with its original kg unit");
    var validState=db.Export();
    Check(D.Validate(validState)!=null,"commercial export validates mixed historical stock units");
    // A failed unit change must roll back without losing the current product or ledger.
    var invalid=db.Products().First(x=>x.id==individual.id);invalid.unit="kg";invalid.stock=1250;invalid.minStock=250;
    db.SetDraft(new Draft{cart=new List<Line>{new Line{productId=individual.id,quantity=1000}}});
    bool rejectedDraft=false;try{db.SaveProduct(invalid);}catch(Exception){rejectedDraft=true;}
    Check(rejectedDraft&&db.Products().First(x=>x.id==individual.id).unit=="un","unit change blocked while pending cart references this product");
    db.SetDraft(new Draft());
    var fractional=db.Products().First(x=>x.id==individual.id);fractional.minStock=1500;
    bool rejectedFractional=false;try{db.SaveProduct(fractional);}catch(Exception){rejectedFractional=true;}
    Check(rejectedFractional&&db.Products().First(x=>x.id==individual.id).stock==35000,"fractional quantities invalid for pieces, transaction rolls back");

    // Catalogo comercial de 05/11/2026: sem acesso remoto ao banco do cliente.
    var beforeClient=db.Export();
    var oldFrench=beforeClient.products.First(x=>x.code=="001");
    long frenchStock=oldFrench.stock, frenchPrice=oldFrench.price;
    var coffee=beforeClient.products.First(x=>x.name=="Café com leite");
    long coffeeStock=coffee.stock, coffeeCost=coffee.cost;
    Check(ClientCatalog.Items.Length==117,"117 entries of client price list");
    int imported=db.ApplyClientCatalogOnce();
    Check(imported==115,"115 new items, 2 existing items have their price updated");
    var clientItems=db.Products();
    Check(clientItems.Count==beforeClient.products.Count+imported,"catalog import counts are exact");
    Check(clientItems.First(x=>x.code=="001").unit=="kg"&&clientItems.First(x=>x.code=="001").price==frenchPrice&&clientItems.First(x=>x.code=="001").stock==frenchStock,
     "French bread original kg entry and stock stay unchanged");
    Check(clientItems.Any(x=>x.name=="Pão francês (unidade)"&&x.unit=="un"&&x.price==50&&x.stock==0&&x.cost==0),
     "new bread by unit never converts existing kilograms or invents inventory");
    var newCoffee=clientItems.First(x=>x.id==coffee.id);
    Check(newCoffee.price==350&&newCoffee.stock==coffeeStock&&newCoffee.cost==coffeeCost,"existing cafe price changed without rewriting stock or cost");
    Check(clientItems.Any(x=>x.name=="Pão de queijo (pacote)"&&x.unit=="un"&&x.price==2100),"pack is sold as an individual package");
    Check(clientItems.Any(x=>x.name=="Pão de queijo (100 g)"&&x.unit=="kg"&&x.price==3500),"100g portions are correctly converted to price per kg");
    Check(clientItems.Any(x=>x.name=="Linguiça Aurora (por kg)"&&x.unit=="kg"&&x.price==2800),"sausage by kg");
    Check(clientItems.Any(x=>x.name=="Linguiça Aurora (pacote fechado)"&&x.unit=="un"&&x.price==9500),"sausage closed package");
    Check(clientItems.Any(x=>x.name=="Palitinho parmesão (pacote)"&&x.price==3500)
     &&clientItems.Any(x=>x.name=="Palitinho parmesão (unidade)"&&x.price==300),"package and individual palitinho stay separate");
    Check(Directory.GetFiles(db.Backups,"*-antes-catalogo-cliente-*.sqlite").Length==1,"backup created before importing customer catalog");
    Check(db.ApplyClientCatalogOnce()==0,"catalog import only applies once");
    Check(db.Products().Count==clientItems.Count,"reopening import never duplicates items");
    Check(J.Write(db.Export().sales)==J.Write(beforeClient.sales)&&J.Write(db.Export().sessions)==J.Write(beforeClient.sessions),
     "historical sales and registers survive catalog import byte-for-byte");
    Check(D.Validate(db.Export())!=null,"commercial export remains valid after importing 117 prices");



   }
   using(var reopened=new Store(args[0])){
    Check(reopened.ApplyClientCatalogOnce()==0,"restart does not repeat migration");
    reopened.Login(Store.OwnerEmail,"Teste-Pdv-2026");
    Check(reopened.Products().Count>100,"imported products remain in SQLite after restart");
   }
   Console.WriteLine("CATALOG_PHOTOS_TESTS_DONE "+count);
  }
 }
}
