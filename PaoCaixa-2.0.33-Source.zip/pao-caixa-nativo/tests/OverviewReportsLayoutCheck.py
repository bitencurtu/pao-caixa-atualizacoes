"""Static guard for 2.0.24 dashboard and reports layout, run with Python 3."""
from pathlib import Path
root=Path(__file__).resolve().parent.parent
source=(root/'src/PresentationPages.cs').read_text(encoding='utf-8-sig')
head=source[source.index('void BuildClassicReport(bool today)'):source.index('class ReportView')]
assert 'new StatCard("Vendas realizadas"' in head
assert 'new StatCard("Situação do caixa"' in head
assert 'new StatCard("Lucro bruto"' in head
assert 'new StatCard("Margem bruta"' not in head
assert head.count('new StatCard(') == 8  # 4 Visão geral + 4 Relatórios
assert 'cards.Cards[4]' not in head
assert 'cards.Cards[3].Value=D.Money((long)Math.Round(r.revenue/(decimal)Math.Max(1,(b-a).TotalDays)))' in head
assert 'view.openRegister?' in head
assert 'latestCount==0?184' in head
assert 'dailyCount==0?156' in head
assert 'if(!today){' in head and 'toolbar.Controls.Add(Ui.Button("Exportar período"' in head
assert 'if(today){' in head and 'toolbar.Controls.Add(Ui.Link("Ver todas as vendas"' in head
assert 'var result=ReportResult.Build(db.Report(a,b));' in head
cash=source[source.index('void BuildClassicCash()'):]
assert 'int movesHeight=view.moves.Count==0?188:325' in cash
assert 'int historyHeight=view.history.Count==0?188:350' in cash
assert 'GridSection("Histórico de caixas"' in cash
assert 'GridSection("Movimentações"' in cash
main=(root/'src/MainForm.cs').read_text(encoding='utf-8-sig')
assert 'openRegister=wanted=="Visão geral"&&db.Open()!=null' in main
assert 'cashOccupied=wanted=="Visão geral"&&db.Occupied()' in main
assert '2.0.33' in (root/'version.json').read_text(encoding='utf-8')
print('PASS: dashboard, cash and reports layout checks')
