# Pão & Caixa 2.0.26

PDV Windows nativo em C# 5, Windows Forms, .NET Framework 4.5+ e SQLite x86. O cliente não precisa de Node, navegador ou GPU dedicada.

## Mudanças desta versão

- Rolagem de catálogo, carrinho e páginas com desaceleração gradual, relógio monotônico e timer ativo somente durante o movimento. O ponteiro direciona a roda para o painel sob o mouse, inclusive sobre seus textos. Grades nativas, listas suspensas e textos multilinha mantêm o comportamento próprio.
- Calendário desenhado com as cores dos temas claro e escuro, setas separadas, destaque da seleção e de hoje. Aceita teclado, anos bissextos, limites de data e abre dentro da área visível da tela. Escape cancela sem mudar o filtro.
- A barra manual e reposicionamentos explícitos interrompem animações pendentes. Redimensionar ou reduzir o conteúdo mantém a posição dentro dos limites.
- O calendário é descartado depois de concluir o fechamento no Windows, para evitar erro de objeto já encerrado ao confirmar a data.
- As tabelas reutilizam a fonte dos cabeçalhos ao trocar tema. Retornos do download não tentam atualizar janelas encerradas. Desconto inválido desabilita o botão de pagamento até a correção.

A estrutura geral da interface, as regras de vendas e caixa, o esquema SQLite, as contas e os perfis foram preservados. A atualização automática da 2.0.4 continua antes do login, com verificação do instalador, backup e adiamento caso haja caixa aberto ou pedido salvo em qualquer conta. O controle Cloudflare continua em consultas de 15 segundos e com a mesma política offline.

Leia `GUIA-PaoCaixa-Windows.md` para instalação, uso, contas, backup e atualização; `VALIDACAO.md` registra o escopo das verificações. Documentos de testes da 2.0.3 são referências históricas, não o procedimento de publicação atual.

## Estrutura e distribuição

`src` contém o aplicativo; `resources` contém a configuração, exemplos e ícone; `vendor/sqlite` contém a DLL oficial x86; `tests` usa somente dados e senhas fictícios. Os dados reais permanecem em `%APPDATA%\PaoCaixa`, separados da pasta de instalação. O instalador não inclui banco de clientes.

O ZIP `PaoCaixa-2.0.26-Source.zip` é compilado e testado pelo workflow `.github/workflows/publicar.yml`. Pull requests validam sem publicar; main publica como Latest somente após sucesso dos testes. A distribuição tem instalador EXE, `latest.yml` em UTF-8 sem BOM com LF e `SHA256.txt`, todos gerados pela mesma compilação. Não é necessário compilar no computador do cliente.

Os números de versão em `version.json`, `src/Updates.cs`, `src/Program.cs`, `resources/app.manifest` e `installer.nsi` precisam concordar. Para desenvolvimento local, `GERAR-INSTALADOR.bat` é uma alternativa à automação.

## Validação

CoreTests verifica vendas, dinheiro/troco, estoque, caixa, permissões, migração e backups. UpdateTests verifica canal, arquivo, cancelamento, prazos, guardas e instalação automática; a versão futura de teste deriva da versão atual, para não ficar desatualizada a cada release. RemotePolicyTests verifica bloqueio e autorização offline. VisualBehaviorTests verifica calendário, rolagem, roteamento da roda e recursos de interface. UiTests e StartupUiTests percorrem a interface com dados fictícios e geram imagens locais.

O GitHub Actions usa o compilador C# do .NET Framework no Windows, executa os testes, consulta o canal HTTPS real e instala silenciosamente o pacote em uma pasta temporária sem abrir o PDV nem cadastrar PCs de teste na Cloudflare. Windows 7/8, Celeron com 4 GB, DPI e periféricos ainda exigem verificação em equipamento real. O instalador não possui assinatura Authenticode.


## Interface de produtos (2.0.21)

Removidos os botões **Adicionar 30 produtos de exemplo** e **Ver movimentações** da barra de ações da tela de produtos e estoque. **Novo produto**, **Editar produto**, **Ajustar estoque** e pesquisa continuam disponíveis. Nenhum produto, fotografia ou registro de movimentação de estoque existente é excluído pela atualização. A lógica de importação de exemplos e o histórico de movimentações foram mantidos internamente para preservar a compatibilidade.

## Fotos próprias nos produtos (2.0.20)

Na tela **Produtos e estoque** > **Novo produto** ou **Editar produto**, use **Escolher foto** para selecionar JPG, PNG, BMP ou GIF. A imagem é reduzida para 360×252 pixels e convertida para JPEG, permitindo funcionamento offline com consumo menor de memória. **Remover** exclui a foto personalizada e volta à imagem do catálogo padrão, quando houver.

As fotos personalizadas ficam dentro do banco `padaria.sqlite` (tabela `product_photos`), junto com os dados do estabelecimento. São incluídas no **Backup completo** (.sqlite), nos backups antes de atualização e no **Backup comercial JSON**. A inclusão, edição ou remoção da foto acontece dentro da mesma transação do cadastro do produto.

Teste no Windows antes de publicar: criar um produto com foto, editar a foto, fechar/reabrir, restaurar backups, e conferir a imagem nos cartões do PDV. Os testes em `tests/CatalogPhotoTests.cs` foram ampliados para cobrir essas operações.

## Organização do painel (2.0.22)

- **Visão geral:** Vendido hoje, Vendas realizadas, Situação do caixa e Estoque para revisar. Atalhos de consultar período e exportar foram removidos somente desta tela; permanecem disponíveis em Relatórios.
- **Meu caixa:** operações de caixa, sangrias, suprimentos, movimentações e histórico mantidos. Se não houver registros, os painéis usam altura reduzida.
- **Relatórios:** Faturamento, Lucro bruto (R$), Margem bruta (%), Tíquete médio e Média diária. Mantidos produtos mais vendidos, formas de pagamento e vendas por dia, com quadro diário compacto em períodos sem vendas.
- **Últimas vendas:** quadro menor quando não há vendas; histórico continua acessível pela aba Vendas.
- Mudanças somente de apresentação, sem alterações no esquema SQLite nem nas operações de vendas.

## Simplificação de Relatórios (2.0.23)

- Removido o cartão **Margem bruta (%)** da tela de Relatórios a pedido do usuário.
- Os quatro indicadores permanecem: **Faturamento**, **Lucro bruto (R$)**, **Tíquete médio**, **Média diária**.
- Ajustados os índices das informações apresentadas e o layout responsivo usa a quantidade real de cartões.
- Sem mudanças nos registros de venda, regras de caixa, SQLite, backups ou exportação.

## Troca de unidade kg ↔ un (2.0.24)

- Campo Unidade habilitado ao editar produtos existentes.
- Ao trocar, os campos de preço, custo, estoque e mínimo são reiniciados para evitar interpretar kg como unidades; o administrador informa os novos valores e confirma a alteração.
- Histórico de movimentações de estoque passa a registrar a unidade da movimentação. Movimentos antigos são anotados na unidade original durante a troca.
- Nova unidade/estoque gravados na mesma transação SQLite; vendas anteriores guardam a unidade original no comprovante.
- Não é permitida troca se o produto estiver em carrinhos não finalizados ou em vendas canceláveis de caixa aberto.
- Não foram alterados os valores dos pedidos concluídos, nem o cálculo de vendas e troco.

## Campo de senha com altura padronizada (2.0.25)

A janela Criar/Editar conta usa um campo de senha de uma única linha (42px, mesma altura dos outros campos) mesmo quando houver espaço sobrando no formulário. A máscara e as regras de senha não mudaram. Há testes de regressão no VisualBehaviorTests.cs.

## Operadores e comprovantes (2.0.26)

- Operador agora vê **Produtos** no menu e pode consultar e ajustar o estoque (entrada/saída com motivo), inclusive sem caixa aberto. Ajustes têm trilha de auditoria com nome da conta.
- Operador continua sem criar/editar produtos, preços, custos e fotos. Perfil Financeiro continua sem permissão de ajuste. Validação ocorre no banco em `Store.AdjustStock`, não apenas na interface.
- Após a conclusão da venda, é oferecida a abertura do comprovante. Se o operador aceitar, uma prévia com **Imprimir** (diálogo de impressoras do Windows) e **Guardar TXT** é exibida. Não imprime automaticamente. Comprovantes também continuam acessíveis em **Vendas**.
- Falhas da impressora não desfazem uma venda já concluída.
- Testar no Windows: operador acessa Produtos, ajusta estoque e não consegue alterar preços; financeiro não ajusta; venda concluída oferece comprovante; imprimir, cancelar impressão e sem impressora.
