"""Quick static regression guard: run from repository root with Python 3."""
from pathlib import Path
src = (Path(__file__).resolve().parent.parent / 'src' / 'MainForm.cs').read_text(encoding='utf-8-sig')
start = src.index('void BuildProducts(bool stock)')
end = src.index('void EditProduct(Product old)', start)
toolbar = src[start:end]
for removed in ('Ui.Button("Ver movimentações"', 'Ui.Button("Adicionar 30 produtos de exemplo"'):
    assert removed not in toolbar, f'Unexpected button: {removed}'
for kept in ('Ui.Primary("Novo produto"', 'Ui.Button("Editar produto"', 'Ui.Button("Ajustar estoque"'):
    assert kept in toolbar, f'Missing button: {kept}'
assert 'void StockLedger(Product p)' in src, 'Historical data UI implementation removed by mistake'
print('PASS: removed buttons absent; remaining product actions and stock history implementation preserved.')
