#!/usr/bin/env python3
"""Source-level guardrails run without C# compiler; Windows CI runs CoreTests."""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
main=(root/'src/MainForm.cs').read_text(encoding='utf-8')
store=(root/'src/Store.cs').read_text(encoding='utf-8')
assert 'new[]{"Pedidos","Produtos","Meu caixa","Vendas","Meu perfil"}' in main
assert 'if(!stock&&user.role=="admin")' in main, 'Operators must not edit product/price fields'
assert 'bar.Controls.Add(Ui.Button("Ajustar estoque"' in main
assert 'User StockEditor()' in store and 'u.role!="admin"&&u.role!="operator"' in store
assert re.search(r'public void AdjustStock\([^)]*\)\{var editor=StockEditor\(\)', store)
assert 'public void SaveProduct(Product p,byte[] customPhoto=null,bool removePhoto=false){Admin();' in store
assert 'public void StockHistory' not in store or 'public List<StockMove> StockHistory(string id,int offset=0){Admin();' in store
checkout=main.split('void Checkout(){',1)[1].split('void OpenCash()',1)[0]
assert checkout.index('db.Finish(')<checkout.index('Deseja abrir o comprovante para imprimir?')
assert 'MessageBoxButtons.YesNo' in checkout and 'Receipt(sale)' in checkout
assert 'A venda foi salva, mas não foi possível abrir o comprovante' in checkout
assert 'Não foi possível imprimir:' in main
assert '2.0.26' in (root/'version.json').read_text(encoding='utf-8')
print('PASS operator inventory permission and post-sale receipt source checks')
