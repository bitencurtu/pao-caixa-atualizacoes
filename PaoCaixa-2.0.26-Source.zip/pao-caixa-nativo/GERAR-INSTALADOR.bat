@echo off
setlocal
cd /d "%~dp0"
node scripts\check-remote-config.mjs
if errorlevel 1 exit /b 1
if not exist build mkdir build
if not exist release mkdir release
set "PDV_CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%PDV_CSC%" (
 echo Instale o .NET Framework 4.8 no computador de desenvolvimento.
 exit /b 1
)
"%PDV_CSC%" /nologo /codepage:65001 /target:winexe /platform:x86 /optimize+ /out:build\PaoCaixa.exe /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:System.Web.Extensions.dll /reference:System.Core.dll /resource:resources\seed.json,seed.json /resource:resources\catalog-extras.json,catalog-extras.json /resource:resources\catalog-photos.jpg,catalog-photos.jpg /resource:resources\owner-bootstrap.json,owner-bootstrap.json /resource:resources\icon.ico,icon.ico /win32manifest:resources\app.manifest /win32icon:resources\icon.ico src\*.cs
if errorlevel 1 exit /b 1
copy /y resources\PaoCaixa.exe.config build\PaoCaixa.exe.config >nul
set "PDV_NSIS=%ProgramFiles(x86)%\NSIS\makensis.exe"
if not exist "%PDV_NSIS%" set "PDV_NSIS=%ProgramFiles%\NSIS\makensis.exe"
if not exist "%PDV_NSIS%" (
 echo Instale o NSIS em https://nsis.sourceforge.io/Download
 exit /b 1
)
"%PDV_NSIS%" installer.nsi
if errorlevel 1 exit /b 1
node scripts\release-feed.mjs
if errorlevel 1 exit /b 1
echo.
echo Pronto. Publique os tres arquivos da pasta release juntos.
pause
