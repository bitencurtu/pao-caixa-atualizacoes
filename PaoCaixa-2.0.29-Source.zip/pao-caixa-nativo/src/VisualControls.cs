using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;
namespace PaoCaixa {
 public class SideNavigation:Control,IThemed {
  public readonly List<string> Pages=new List<string>();public event EventHandler SelectedIndexChanged;
  public string ShopName="Minha padaria",UserName="",Role="";public Action Logout,Profile;int selected=-1;
  readonly List<Rectangle> hit=new List<Rectangle>();Rectangle logoutHit,profileHit;readonly Bitmap brand;
  public int SelectedIndex {get{return selected;}set{if(value<0||value>=Pages.Count||selected==value)return;selected=value;Invalidate();if(SelectedIndexChanged!=null)SelectedIndexChanged(this,EventArgs.Empty);}}
  public string SelectedPage {get{return selected>=0&&selected<Pages.Count?Pages[selected]:null;}}
  public SideNavigation(){using(var stream=System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("icon.ico"))using(var icon=new Icon(stream,new Size(48,48)))brand=icon.ToBitmap();Dock=DockStyle.Left;Width=232;Cursor=Cursors.Hand;SetStyle(ControlStyles.OptimizedDoubleBuffer|ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.ResizeRedraw,true);}
  public static string Title(string page){switch(page){case "Pedidos":return "Frente de caixa";case "Produtos":return "Produtos e estoque";case "Vendas":return "Histórico de vendas";case "Relatórios":return "Relatórios da padaria";case "Visão geral":return "Um olhar sobre a padaria";case "Painel Biel":return "Meu painel";default:return page;}}
  public static string IconFor(string page){switch(page){case "Pedidos":return "basket";case "Visão geral":return "dashboard";case "Produtos":case "Estoque":return "package";case "Meu caixa":return "wallet";case "Vendas":return "receipt";case "Relatórios":return "chart";case "Configurações":return "settings";case "Painel Biel":return "lock";default:return "user";}}
  public void Reset(IEnumerable<string> pages){Pages.Clear();Pages.AddRange(pages);selected=0;Invalidate();}
  protected override void OnPaint(PaintEventArgs e){var g=e.Graphics;bool shortWindow=Height<675,tinyWindow=Height<640,verySmall=Height<480;g.Clear(Ui.Side);g.SmoothingMode=SmoothingMode.AntiAlias;using(var p=new Pen(Ui.Line))g.DrawLine(p,Width-1,0,Width-1,Height);
   g.InterpolationMode=InterpolationMode.HighQualityBicubic;g.DrawImage(brand,new Rectangle(21,25,42,42));
   using(var f=new Font("Georgia",16.5f,FontStyle.Bold))using(var b=new SolidBrush(Ui.Green))g.DrawString("Pão & Caixa",f,b,new PointF(73,24));Ui.Text(g,"GESTÃO DA PADARIA",new Rectangle(74,54,Width-84,17),6.5f,Ui.Muted);
   using(var p=new Pen(Ui.Line)){g.DrawLine(p,18,tinyWindow?79:90,Width-18,tinyWindow?79:90);if(!tinyWindow)g.DrawLine(p,18,shortWindow?132:150,Width-18,shortWindow?132:150);}
   if(!tinyWindow){
   Ui.Box(g,new Rectangle(24,shortWindow?94:105,31,31),Ui.Soft,Ui.Line,8);Ui.Text(g,string.IsNullOrEmpty(ShopName)?"P":ShopName.Substring(0,1).ToUpper(),new Rectangle(24,shortWindow?94:105,31,31),12,Ui.Green,FontStyle.Bold,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter);
   Ui.Text(g,ShopName,new Rectangle(66,shortWindow?91:102,Width-80,20),9,Ui.Ink,FontStyle.Bold);Ui.Text(g,"Seu balcão, organizado.",new Rectangle(66,shortWindow?111:123,Width-80,16),8,Ui.Muted);
   }
   hit.Clear();bool compact=Height<675;int y=verySmall?82:tinyWindow?103:compact?156:171;bool management=false;int row=verySmall?21:tinyWindow?24:Height<640?29:Height<740?34:42;Ui.Text(g,"OPERAÇÃO",new Rectangle(27,verySmall?66:tinyWindow?85:compact?135:156,Width-40,18),7,Ui.Muted);
   foreach(string page in Pages){bool isManagement=page=="Relatórios"||page=="Configurações"||page=="Meu perfil"||page=="Painel Biel";if(isManagement&&!management){Ui.Text(g,"GESTÃO",new Rectangle(27,y+(compact?1:6),Width-40,18),7,Ui.Muted);y+=verySmall?13:tinyWindow?16:compact?21:30;management=true;}var r=new Rectangle(16,y,Width-32,row);hit.Add(r);int i=hit.Count-1;bool active=i==selected;Ui.Box(g,r,active?Ui.Accent:Ui.Side,Color.Empty,8);Color c=active?Color.White:Ui.Muted;SidebarIcons.Draw(g,IconFor(page),new Rectangle(28,y+(row-19)/2,19,19),c);string label=page=="Visão geral"?"Visão geral":page=="Relatórios"?"Relatórios":Title(page);Ui.Text(g,label,new Rectangle(59,y,Width-74,row),8.6f,c);y+=row+2;}
   int bottom=Math.Max(y+(tinyWindow?5:12),Height-(tinyWindow?120:137));using(var p=new Pen(Ui.Line))g.DrawLine(p,18,bottom,Width-18,bottom);Icons.Draw(g,"storage",new Rectangle(24,bottom+14,15,15),Ui.Muted);Ui.Text(g,"Banco offline neste PC",new Rectangle(46,bottom+10,Width-60,24),7.6f,Ui.Muted);using(var b=new SolidBrush(Ui.Green))g.FillEllipse(b,Width-32,bottom+18,6,6);
   profileHit=new Rectangle(18,bottom+(tinyWindow?31:42),Width-36,tinyWindow?38:46);Ui.Box(g,new Rectangle(25,bottom+(tinyWindow?34:48),32,32),Ui.Soft,Color.Empty,9);Ui.Text(g,UserName.Length>1?UserName.Substring(0,2).ToUpper():UserName,new Rectangle(25,bottom+(tinyWindow?34:48),32,32),9,Ui.Green,FontStyle.Bold,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter);Ui.Text(g,UserName,new Rectangle(67,bottom+(tinyWindow?33:47),Width-82,20),9,Ui.Ink,FontStyle.Bold);Ui.Text(g,Role,new Rectangle(67,bottom+(tinyWindow?53:68),Width-82,17),7.5f,Ui.Muted);
   logoutHit=new Rectangle(20,bottom+(tinyWindow?78:94),Width-40,tinyWindow?27:32);Icons.Draw(g,"logout",new Rectangle(27,bottom+(tinyWindow?84:101),16,16),Ui.Muted);Ui.Text(g,"Sair da conta",new Rectangle(54,bottom+(tinyWindow?78:94),Width-68,tinyWindow?27:32),9,Ui.Muted);
  }
  protected override void OnMouseClick(MouseEventArgs e){base.OnMouseClick(e);if(!Enabled)return;for(int i=0;i<hit.Count;i++)if(hit[i].Contains(e.Location)){SelectedIndex=i;return;}if(logoutHit.Contains(e.Location)&&Logout!=null)Logout();if(profileHit.Contains(e.Location)&&Profile!=null)Profile();}
  public void ThemeChanged(){BackColor=Ui.Side;Invalidate();}
  protected override void Dispose(bool disposing){if(disposing&&brand!=null)brand.Dispose();base.Dispose(disposing);}
 }
 public class TopBar:Panel,IThemed {
  public string Page="",CashText="Caixa fechado";public bool CashOpen,ShowCashAction,CanOpenCash;public Action CashAction;public readonly ThemeSwitch Theme=new ThemeSwitch();Rectangle cashHit;
  public TopBar(){Dock=DockStyle.Top;Height=70;DoubleBuffered=true;ResizeRedraw=true;Controls.Add(Theme);}
  protected override void OnLayout(LayoutEventArgs e){base.OnLayout(e);if(Theme==null)return;Theme.SetBounds(Math.Max(0,Width-(Width<680?172:202)),16,Width<680?154:178,38);}
  protected override void OnPaintBackground(PaintEventArgs e){e.Graphics.Clear(Ui.Card);using(var p=new Pen(Ui.Line))e.Graphics.DrawLine(p,0,Height-1,Width,Height-1);}
  protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;bool narrow=Width<710;int pageStart=narrow?18:113;if(!narrow){Ui.Text(g,"Padaria",new Rectangle(28,0,62,Height),9,Ui.Muted);Icons.Draw(g,"chevron",new Rectangle(90,28,13,13),Ui.Muted);}bool canOpen=ShowCashAction&&CanOpenCash;
   int chipWidth=canOpen?(narrow?145:174):(narrow?127:153);
   // Usa a posicao real do seletor de tema (que muda a 680px), evitando sobreposicao.
   int themeLeft=Math.Max(0,Width-(Width<680?172:202));
   int x=Math.Max(pageStart+76,themeLeft-chipWidth-12);
   Ui.Text(g,Page,new Rectangle(pageStart,0,Math.Max(30,x-pageStart-10),Height),9,Ui.Ink,FontStyle.Bold,TextFormatFlags.SingleLine|TextFormatFlags.Left|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis);
   cashHit=ShowCashAction?new Rectangle(x,canOpen?15:20,chipWidth,canOpen?40:30):Rectangle.Empty;
   if(ShowCashAction){
    Ui.Box(g,cashHit,canOpen?Ui.Accent:CashOpen?Ui.Soft:Ui.Bg,canOpen?Color.Empty:Ui.Line,canOpen?10:16);
    if(canOpen){
     Icons.Draw(g,"wallet",new Rectangle(x+12,25,19,19),Color.White);
     Ui.Text(g,"Abrir caixa",new Rectangle(x+36,15,chipWidth-43,40),9,Color.White,FontStyle.Bold);
    }else{
     using(var b=new SolidBrush(CashOpen?Ui.Green:Ui.Muted))g.FillEllipse(b,x+12,32,6,6);
     Ui.Text(g,CashText,new Rectangle(x+25,20,chipWidth-33,30),8.5f,CashOpen?Ui.Green:Ui.Muted);
    }
   }
   if(Width>900)Ui.Text(g,DateTime.Today.ToString("dd 'de' MMMM",D.BR),new Rectangle(x-132,0,120,Height),8.5f,Ui.Muted,FontStyle.Regular,TextFormatFlags.Right|TextFormatFlags.VerticalCenter);}
  protected override void OnMouseClick(MouseEventArgs e){base.OnMouseClick(e);if(ShowCashAction&&cashHit.Contains(e.Location)&&CashAction!=null)CashAction();}
  protected override void OnMouseMove(MouseEventArgs e){base.OnMouseMove(e);Cursor=ShowCashAction&&cashHit.Contains(e.Location)?Cursors.Hand:Cursors.Default;}
  protected override void OnMouseLeave(EventArgs e){base.OnMouseLeave(e);Cursor=Cursors.Default;}
  public void ThemeChanged(){BackColor=Ui.Card;Theme.BackColor=Ui.Card;Theme.ForeColor=Ui.Ink;Invalidate();}
 }
 public class PageHeading:Control,IThemed {
  public string Title,Description,Eyebrow;
  public PageHeading(string title,string description,string eyebrow=null){Title=title;Description=description;Eyebrow=eyebrow;Height=eyebrow==null?81:96;Dock=DockStyle.Top;SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.ResizeRedraw,true);}
  protected override void OnPaint(PaintEventArgs e){e.Graphics.Clear(Ui.Bg);int y=0;if(Eyebrow!=null&&Height>=80){Ui.Text(e.Graphics,Eyebrow,new Rectangle(0,0,Width,20),7,Ui.Muted,FontStyle.Bold);y=24;}Ui.Text(e.Graphics,Title,new Rectangle(0,y,Width,34),21,Ui.Ink,FontStyle.Bold);Ui.Text(e.Graphics,Description,new Rectangle(0,y+40,Width,24),9.5f,Ui.Muted);}
  public void ThemeChanged(){Invalidate();}
 }
 public class ProductCatalog:CanvasView,IThemed {
  public List<Product> Items=new List<Product>();public Draft Draft;public event Action<Product> Chosen;public Product SelectedProduct;readonly List<KeyValuePair<Rectangle,Product>> hits=new List<KeyValuePair<Rectangle,Product>>();
  public ProductCatalog(){Dock=DockStyle.Fill;TabStop=true;Cursor=Cursors.Hand;SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.ResizeRedraw,true);}
  public void Bind(IEnumerable<Product> items,Draft draft){Items=items.ToList();Draft=draft;ScrollOffset=Point.Empty;SelectedProduct=Items.FirstOrDefault();Arrange();Invalidate();}
  void Arrange(){if(Items==null)return;int cols=Columns();VirtualSize=new Size(0,Items.Count==0?200:((Items.Count+cols-1)/cols)*237);}
  int Columns(){return Math.Max(1,(ClientSize.Width-18+14)/166);}
  protected override void OnSizeChanged(EventArgs e){base.OnSizeChanged(e);Arrange();}
  protected override void OnPaint(PaintEventArgs e){var g=e.Graphics;g.Clear(Ui.Bg);g.SmoothingMode=SmoothingMode.AntiAlias;hits.Clear();int cols=Columns(),gap=14,w=(Math.Max(130,ClientSize.Width-19)-gap*(cols-1))/cols;
   if(Items.Count==0){Icons.Draw(g,"search",new Rectangle(Math.Max(0,Width/2-16),45,32,32),Ui.Muted);Ui.Text(g,"Produto não encontrado",new Rectangle(0,94,Width-20,25),12,Ui.Ink,FontStyle.Bold,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter);Ui.Text(g,"Tente outro nome, código ou categoria.",new Rectangle(0,125,Width-20,30),8.5f,Ui.Muted,FontStyle.Regular,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter);return;}
   for(int i=0;i<Items.Count;i++){int x=(i%cols)*(w+gap),y=(i/cols)*237+ScrollOffset.Y;var r=new Rectangle(x,y,w,223);hits.Add(new KeyValuePair<Rectangle,Product>(r,Items[i]));if(y+223<0||y>Height)continue;var p=Items[i];Ui.Box(g,r,Ui.Card,SelectedProduct==p&&Focused?Ui.Green:Ui.Line,12);var art=new Rectangle(x+7,y+7,w-14,110);Color tint=Art(p.icon),ink=ArtInk(p.icon);Ui.Box(g,art,tint,Color.Empty,8);if(!ProductPhotos.Draw(g,p,art)){using(var b=new SolidBrush(Ui.Dark?Color.FromArgb(15,220,220,180):Color.FromArgb(80,255,255,255)))g.FillEllipse(b,x+w/2-39,y+24,78,78);Icons.Draw(g,p.icon,new Rectangle(x+w/2-25,y+36,50,50),ink);}
    if(p.stock<=p.minStock)using(var b=new SolidBrush(Color.FromArgb(193,147,66)))g.FillEllipse(b,x+w-23,y+16,7,7);
    var line=Draft==null?null:Draft.cart.Find(l=>l.productId==p.id);if(line!=null){string q=D.Qty(line.quantity,p.unit);int qw=TextRenderer.MeasureText(q,Font).Width+24;Ui.Box(g,new Rectangle(x+w-qw-12,y+85,qw,23),Ui.Accent,Color.Empty,6);Ui.Text(g,q,new Rectangle(x+w-qw-10,y+85,qw-4,23),7.5f,Color.White,FontStyle.Bold,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter);}
    Ui.Text(g,p.category,new Rectangle(x+13,y+127,w-26,17),7.5f,Ui.Muted);Ui.Text(g,p.name,new Rectangle(x+13,y+146,w-22,27),10,Ui.Ink,FontStyle.Bold);Ui.Text(g,D.Money(p.price)+" / "+p.unit,new Rectangle(x+13,y+177,w-50,22),9.5f,Ui.Green,FontStyle.Bold);Ui.Box(g,new Rectangle(x+w-36,y+176,24,24),Ui.Soft,Color.Empty,12);Icons.Draw(g,"plus",new Rectangle(x+w-30,y+182,12,12),Ui.Green);Ui.Text(g,p.stock>0?D.Qty(p.stock,p.unit)+" "+p.unit+" em estoque":"Sem estoque",new Rectangle(x+13,y+202,w-26,15),7.5f,Ui.Muted);
   }
  }
  protected override void OnMouseClick(MouseEventArgs e){base.OnMouseClick(e);Focus();var h=hits.FirstOrDefault(x=>x.Key.Contains(e.Location));if(h.Value==null)return;SelectedProduct=h.Value;Invalidate();if(h.Value.stock>0&&Chosen!=null)Chosen(h.Value);}
  protected override void OnKeyDown(KeyEventArgs e){base.OnKeyDown(e);int i=Items.IndexOf(SelectedProduct);if(e.KeyCode==Keys.Enter&&SelectedProduct!=null&&Chosen!=null){Chosen(SelectedProduct);e.Handled=true;return;}int n=e.KeyCode==Keys.Right?i+1:e.KeyCode==Keys.Left?i-1:e.KeyCode==Keys.Down?i+Columns():e.KeyCode==Keys.Up?i-Columns():i;if(n!=i&&Items.Count>0){SelectedProduct=Items[Math.Max(0,Math.Min(n,Items.Count-1))];ScrollOffset=new Point(0,Math.Max(0,(Items.IndexOf(SelectedProduct)/Columns())*237-Height/2));Invalidate();e.Handled=true;}}
  public static Color Art(string icon){if(Ui.Dark)return icon=="cake"?Color.FromArgb(65,44,38):icon=="coffee"||icon=="juice"?Color.FromArgb(42,57,39):Color.FromArgb(64,55,37);return icon=="cake"?Color.FromArgb(247,233,228):icon=="coffee"?Color.FromArgb(237,240,230):icon=="juice"?Color.FromArgb(234,240,232):Color.FromArgb(247,240,226);}
  public static Color ArtInk(string icon){return icon=="cake"?Color.FromArgb(197,139,120):icon=="coffee"||icon=="juice"?Color.FromArgb(139,163,117):Color.FromArgb(173,137,75);}
  public void ThemeChanged(){BackColor=Ui.Bg;Invalidate();}
 }
 public class CartList:CanvasView,IThemed {
  public Draft Draft;public List<Product> Products;public Action<int,string> Action;readonly List<Rectangle> rowHits=new List<Rectangle>();public CartList(){Dock=DockStyle.Fill;Cursor=Cursors.Hand;SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.ResizeRedraw,true);}
  int RowHeight{get{return Height<110?52:102;}}
  public void RefreshItems(){VirtualSize=new Size(0,Draft==null?0:Draft.cart.Count*RowHeight);Invalidate();}
  protected override void OnSizeChanged(EventArgs e){base.OnSizeChanged(e);RefreshItems();}
  protected override void OnPaint(PaintEventArgs e){var g=e.Graphics;g.Clear(Ui.Card);g.SmoothingMode=SmoothingMode.AntiAlias;rowHits.Clear();int w=ClientSize.Width-(ScrollBar.Visible?18:0);if(Draft==null||Draft.cart.Count==0){if(Height<155){Icons.Draw(g,"basket",new Rectangle(20,Math.Max(5,(Height-24)/2),24,24),Ui.Muted);Ui.Text(g,"Selecione um produto ao lado",new Rectangle(55,0,w-70,Height),8.5f,Ui.Muted);return;}Icons.Draw(g,"basket",new Rectangle(w/2-20,Math.Max(20,Height/2-56),40,40),Ui.Muted);Ui.Text(g,"Vamos começar?",new Rectangle(14,Height/2,w-28,27),12,Ui.Ink,FontStyle.Bold,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter);Ui.Text(g,"Selecione os produtos ao lado\npara montar sua venda.",new Rectangle(20,Height/2+35,w-40,50),9,Ui.Muted,FontStyle.Regular,TextFormatFlags.HorizontalCenter|TextFormatFlags.WordBreak);return;}
   for(int i=0;i<Draft.cart.Count;i++){int y=i*RowHeight+ScrollOffset.Y;rowHits.Add(new Rectangle(0,y,w,RowHeight));if(y+RowHeight<0||y>Height)continue;var l=Draft.cart[i];var p=Products.Find(x=>x.id==l.productId);if(p==null){Ui.Text(g,"Produto indisponível",new Rectangle(18,y,w-40,30),10,Ui.Ink);continue;}if(RowHeight==52){Ui.Text(g,p.name,new Rectangle(18,y+1,w-64,23),9,Ui.Ink,FontStyle.Bold);Icons.Draw(g,"close",new Rectangle(w-33,y+6,14,14),Ui.Muted);Ui.Box(g,new Rectangle(16,y+26,108,24),Ui.Card,Ui.Line,6);Icons.Draw(g,"minus",new Rectangle(23,y+32,11,11),Ui.Ink);Icons.Draw(g,"plus",new Rectangle(106,y+32,11,11),Ui.Ink);Ui.Text(g,D.Qty(l.quantity,p.unit)+(p.unit=="kg"?" kg":""),new Rectangle(40,y+26,63,24),8,Ui.Ink,FontStyle.Regular,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter);Ui.Text(g,D.Money(D.Rounded(p.price,l.quantity)),new Rectangle(140,y+26,w-158,24),9,Ui.Ink,FontStyle.Bold,TextFormatFlags.Right|TextFormatFlags.VerticalCenter);continue;}Ui.Box(g,new Rectangle(17,y+17,35,38),ProductCatalog.Art(p.icon),Color.Empty,8);Icons.Draw(g,p.icon,new Rectangle(24,y+25,22,22),ProductCatalog.ArtInk(p.icon));Ui.Text(g,p.name,new Rectangle(64,y+13,w-110,23),9.5f,Ui.Ink,FontStyle.Bold);Ui.Text(g,D.Money(p.price)+" / "+p.unit,new Rectangle(64,y+38,w-90,18),8,Ui.Muted);Icons.Draw(g,"close",new Rectangle(w-35,y+18,15,15),Ui.Muted);Ui.Box(g,new Rectangle(64,y+65,108,26),Ui.Card,Ui.Line,6);Icons.Draw(g,"minus",new Rectangle(71,y+73,11,11),Ui.Ink);Icons.Draw(g,"plus",new Rectangle(154,y+73,11,11),Ui.Ink);Ui.Text(g,D.Qty(l.quantity,p.unit)+(p.unit=="kg"?" kg":""),new Rectangle(86,y+65,63,26),8,Ui.Ink,FontStyle.Regular,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter);Ui.Text(g,D.Money(D.Rounded(p.price,l.quantity)),new Rectangle(180,y+65,w-198,26),9,Ui.Ink,FontStyle.Bold,TextFormatFlags.Right|TextFormatFlags.VerticalCenter);using(var pen=new Pen(Ui.Line))g.DrawLine(pen,17,y+101,w-18,y+101);
   }
  }
  protected override void OnMouseClick(MouseEventArgs e){base.OnMouseClick(e);for(int i=0;i<rowHits.Count;i++){var r=rowHits[i];if(!r.Contains(e.Location))continue;if(RowHeight==52){string compact=e.X>=r.Width-46&&e.Y-r.Y<26?"remove":e.Y-r.Y>=26&&e.X>=16&&e.X<40?"minus":e.Y-r.Y>=26&&e.X>=102&&e.X<126?"plus":"edit";if(Action!=null)Action(i,compact);return;}string a=e.X>=r.Width-46&&e.Y-r.Y<48?"remove":e.Y-r.Y>=60&&e.X>=64&&e.X<88?"minus":e.Y-r.Y>=60&&e.X>=150&&e.X<174?"plus":"edit";if(Action!=null)Action(i,a);return;}}
  public void ThemeChanged(){BackColor=Ui.Card;Invalidate();}
 }
 public class StatCard:Control,IThemed {
  public string Caption,Value="—",Detail="",IconName="chart";public bool Amber;
  public StatCard(string caption,string icon){Caption=caption;IconName=icon;Height=147;SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.ResizeRedraw,true);}
  protected override void OnPaint(PaintEventArgs e){var g=e.Graphics;g.Clear(Ui.Bg);g.SmoothingMode=SmoothingMode.AntiAlias;Ui.Box(g,new Rectangle(0,0,Width-1,Height-1),Ui.Card,Ui.Line,12);Ui.Text(g,Caption,new Rectangle(19,18,Width-65,26),9,Ui.Muted);Ui.Box(g,new Rectangle(Width-49,16,30,30),Amber?ProductCatalog.Art("bread"):Ui.Soft,Color.Empty,8);Icons.Draw(g,IconName,new Rectangle(Width-43,22,18,18),Amber?ProductCatalog.ArtInk("bread"):Ui.Green);Ui.Text(g,Value,new Rectangle(19,55,Width-35,46),Width<190?20:25,Ui.Ink,FontStyle.Bold);Ui.Text(g,Detail,new Rectangle(19,107,Width-37,27),8,Ui.Muted);}
  public void ThemeChanged(){Invalidate();}
 }
 public class WelcomeBanner:Control,IThemed {
  public string OperatorName;
  public WelcomeBanner(string name){OperatorName=name;Height=152;SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.ResizeRedraw,true);}
  protected override void OnPaint(PaintEventArgs e){var g=e.Graphics;g.Clear(Ui.Bg);g.SmoothingMode=SmoothingMode.AntiAlias;Ui.Box(g,new Rectangle(0,0,Width-1,Height-1),Ui.Soft,Ui.Line,12);Ui.Text(g,"BOM TRABALHO, "+(OperatorName??"").ToUpper(),new Rectangle(28,22,Width-140,22),7.5f,Ui.Green,FontStyle.Bold);Ui.Text(g,"Seu dia começa com um bom controle.",new Rectangle(28,51,Width-140,34),19,Ui.Ink,FontStyle.Bold);Ui.Text(g,"Acompanhe o balcão, o estoque e o caixa em um só lugar.",new Rectangle(28,101,Width-140,26),9,Ui.Muted);Icons.Draw(g,"wheat",new Rectangle(Width-111,31,76,88),Ui.Dark?Color.FromArgb(86,112,70):Color.FromArgb(159,181,128));}
  public void ThemeChanged(){Invalidate();}
 }
 public class RankingPanel:CanvasView,IThemed {
  public List<Ranked> Items=new List<Ranked>();public RankingPanel(){SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.ResizeRedraw,true);}
  public void Bind(List<Ranked> rows){Items=rows.Take(300).ToList();VirtualSize=new Size(0,108+Items.Count*76+Items.Select(x=>x.unit).Distinct().Count()*42+44);Invalidate();}
  protected override void OnPaint(PaintEventArgs e){var g=e.Graphics;g.Clear(Ui.Bg);g.SmoothingMode=SmoothingMode.AntiAlias;int w=ClientSize.Width-(ScrollBar.Visible?18:0),height=Math.Max(Height-1,VirtualSize.Height);int sy=ScrollOffset.Y;Ui.Box(g,new Rectangle(0,sy,w-1,height),Ui.Card,Ui.Line,12);Ui.Text(g,"Produtos mais vendidos",new Rectangle(22,20+sy,w-170,28),12,Ui.Ink,FontStyle.Bold);Ui.Text(g,"Ordenados pela quantidade vendida no período.",new Rectangle(22,53+sy,w-38,22),8.5f,Ui.Muted);Ui.Box(g,new Rectangle(w-127,22+sy,106,25),Ui.Soft,Color.Empty,6);Ui.Text(g,"Por quantidade",new Rectangle(w-120,22+sy,92,25),7.5f,Ui.Green,FontStyle.Regular,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter);using(var p=new Pen(Ui.Line))g.DrawLine(p,0,95+sy,w,95+sy);
   if(Items.Count==0){Icons.Draw(g,"chart",new Rectangle(w/2-20,143+sy,40,40),Ui.Muted);Ui.Text(g,"Os números começam nas vendas",new Rectangle(20,199+sy,w-40,35),11,Ui.Ink,FontStyle.Bold,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter);Ui.Text(g,"Conclua uma venda para acompanhar os produtos.",new Rectangle(20,240+sy,w-40,35),8.5f,Ui.Muted,FontStyle.Regular,TextFormatFlags.HorizontalCenter|TextFormatFlags.WordBreak);return;}
   int y=108+sy;foreach(string unit in new[]{"un","kg"}){var rows=Items.Where(x=>x.unit==unit).ToList();if(rows.Count==0)continue;Ui.Text(g,unit=="un"?"Vendidos por unidade":"Vendidos por peso (kg)",new Rectangle(22,y,w-44,28),9,Ui.Muted,FontStyle.Bold);y+=41;for(int i=0;i<rows.Count;i++){var r=rows[i];if(y+76>=0&&y<Height){Ui.Text(g,(i+1).ToString("00"),new Rectangle(22,y+10,27,26),9,Ui.Muted);Ui.Text(g,r.name,new Rectangle(62,y+5,w-172,29),10,Ui.Ink,FontStyle.Bold);Ui.Text(g,D.Money(r.value),new Rectangle(62,y+34,w-174,18),7.5f,Ui.Muted);Ui.Text(g,D.Qty(r.quantity,unit)+" "+unit,new Rectangle(w-100,y+12,77,30),10,Ui.Ink,FontStyle.Bold,TextFormatFlags.Right|TextFormatFlags.VerticalCenter);Ui.Box(g,new Rectangle(62,y+61,w-88,4),Ui.Soft,Color.Empty,2);int bar=(int)((w-88)*(r.quantity/(decimal)rows[0].quantity));if(bar>0)Ui.Box(g,new Rectangle(62,y+61,bar,4),Ui.Dark?Color.FromArgb(125,157,101):Color.FromArgb(115,144,90),Color.Empty,2);}y+=76;}}
   Ui.Text(g,"Unidades e kg separados. Valores antes dos descontos.",new Rectangle(22,y+4,w-44,30),7.5f,Ui.Muted);
  }
  public void ThemeChanged(){Invalidate();}
 }
 public class PaymentsPanel:Control,IThemed {
  public ReportResult Result;public PaymentsPanel(){Height=380;SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.ResizeRedraw,true);}
  protected override void OnPaint(PaintEventArgs e){var g=e.Graphics;g.Clear(Ui.Bg);g.SmoothingMode=SmoothingMode.AntiAlias;Ui.Box(g,new Rectangle(0,0,Width-1,Height-1),Ui.Card,Ui.Line,12);Ui.Text(g,"Formas de pagamento",new Rectangle(22,20,Width-44,28),12,Ui.Ink,FontStyle.Bold);Ui.Text(g,"Como seus clientes pagaram.",new Rectangle(22,53,Width-44,22),8.5f,Ui.Muted);for(int i=0;i<4;i++){int y=111+i*58;long n=Result==null?0:Result.payments[D.Methods[i]];Icons.Draw(g,i==0?"wallet":i==1?"pix":"card",new Rectangle(22,y+3,20,20),Ui.Green);Ui.Text(g,D.MethodNames[i],new Rectangle(55,y,Width/2-45,30),9,Ui.Ink);Ui.Text(g,D.Money(n),new Rectangle(Width/2,y,Width/2-22,27),10,Ui.Ink,FontStyle.Bold,TextFormatFlags.Right|TextFormatFlags.VerticalCenter);Ui.Text(g,(Result==null||Result.revenue==0?0:(int)Math.Round(n*100m/Result.revenue))+"% do total",new Rectangle(Width/2,y+27,Width/2-22,20),8,Ui.Muted,FontStyle.Regular,TextFormatFlags.Right|TextFormatFlags.VerticalCenter);}}
  public void ThemeChanged(){Invalidate();}
 }
}
