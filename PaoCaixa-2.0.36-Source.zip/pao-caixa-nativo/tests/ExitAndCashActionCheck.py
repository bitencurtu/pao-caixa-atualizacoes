﻿#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
main=(root/'src/MainForm.cs').read_text(encoding='utf-8-sig')
store=(root/'src/Store.cs').read_text(encoding='utf-8-sig')
visual=(root/'src/VisualControls.cs').read_text(encoding='utf-8-sig')
pages=(root/'src/PresentationPages.cs').read_text(encoding='utf-8-sig')
assert 'FormClosing+=(sender,e)=>ConfirmExit(e)' in main
closing=main.split('void ConfirmExit(FormClosingEventArgs e){')[1].split('void GuardUi(',1)[0]
assert closing.index('if(closingForUpdate)return;')<closing.index('db.HasOpenCash()')
assert closing.index('if(busy)')<closing.index('db.HasOpenCash()')
assert 'lock(db.Sync)open=db.HasOpenCash()' in closing
assert 'MessageBoxButtons.YesNo' in closing and 'MessageBoxDefaultButton.Button2' in closing
assert 'if(choice!=DialogResult.Yes){e.Cancel=true;return;}' in closing
assert closing.index('if(choice!=DialogResult.Yes)')<closing.index('db.SetDraft(finalDraft)')
assert 'public bool HasOpenCash(){return OpenRaw()!=null;}' in store
assert 'header.ShowCashAction=user!=null&&user.role!="financial"' in main
assert 'header.CanOpenCash=header.ShowCashAction&&!cashOccupied&&currentRegister==null' in main
assert 'if(ShowCashAction&&cashHit.Contains(e.Location)&&CashAction!=null)CashAction()' in visual
assert 'Ui.Text(g,"Abrir caixa"' in visual and 'canOpen?Ui.Accent' in visual
assert 'themeLeft-chipWidth-12' in visual
assert 'toolbar.Controls.Add(open)' in pages
assert 'new Size(196,52)' in pages
assert 'if(view.open==null&&!view.occupied)' in pages
assert 'if(page=="Meu caixa"||page=="Visão geral")LoadPage()' in main
assert '2.0.36' in (root/'version.json').read_text(encoding='utf-8')
print('PASS exit warning, offline cash status and prominent open cash actions')
