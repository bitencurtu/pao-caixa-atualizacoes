﻿# Pão & Caixa 2.0.36

## Correção 2.0.36 — fotos e ícone

- Os 117 produtos do catálogo da padaria têm fotos de referência individuais embutidas no aplicativo.
- O ícone do menu, do aplicativo e do instalador usa o vermelho e o amarelo do Pão & Caixa.
- Basta atualizar a instalação. A atualização das fotos embutidas dispensa a importação ou limpeza do catálogo.

## Correção 2.0.35 — testes do catálogo
- Corrigido o teste automatizado que esperava 115 inclusões e 2 atualizações de preço.
- Na base de teste, **Café com leite, Chocolate quente e Refrigerante lata** já estão cadastrados na mesma unidade. Assim, importar 117 itens resulta em 114 inclusões e 3 preços atualizados.
- Acrescentadas verificações para confirmar que os três produtos existentes conservam estoque e custo; banco de dados, catálogo do cliente e rotina de importação não foram alterados nesta versão.
- A limpeza comercial continua **manual e protegida por administrador**, com backup e confirmação `ZERAR TESTES`, como na 2.0.33.

## Novidades 2.0.33 — 24 itens de bebidas e manteigas (117 no total)
- Base de instalação inicial continua com **limpeza opcional confirmada por administrador**, mas agora instala 117 itens.
- Cliente que **já executou o reset 2.0.32** recebe automaticamente apenas os 24 novos itens, sem reinicializar o banco. A migração só roda depois de verificar o marcador do reset e faz backup antes.
- Nenhum outro cliente do canal compartilhado recebe esses itens automaticamente. Sem o reset anterior, eles só entram quando o administrador confirmar a instalação limpa.
- Produtos novos começam com estoque e custo zero; cadastros, preços, estoque, vendas e caixa preexistentes são preservados na migração incremental.
- As manteigas de 500 g Qualy e outras marcas são itens separados; bebidas com embalagem diferenciada também têm itens próprios.

## Novidades 2.0.32 — iniciar catálogo com base limpa (somente após confirmação local)
- Em **Configurações > Iniciar catálogo do cliente**, um administrador pode confirmar a exclusão de todos os produtos e dados comerciais de TESTE da instalação escolhida.
- É necessário confirmar o aviso de exclusão e digitar **ZERAR TESTES**. Publicar no GitHub sozinho NÃO apaga dados de nenhuma padaria.
- É criado backup SQLite completo antes de alterar os dados. A transação apaga produtos, fotos, vendas, caixas, sangrias, suprimentos, movimentos de estoque e rascunhos, e reinicia a numeração.
- Importa exatamente 93 produtos e preços, com custo e estoque zero. Preserva usuários/senhas, configurações e bloqueio remoto.
- Marcador impede aplicar a limpeza novamente, preservando futuras vendas; testes de regressão adicionados.
- O catálogo deixa de ser importado automaticamente por todas as instalações do canal compartilhado, para não afetar outros clientes.
- Para zerar tudo **automaticamente apenas no computador do cliente**, será necessário identificar a instalação (ID remoto) e produzir uma versão direcionada. Não use limpeza silenciosa no canal compartilhado.

## Novidades 2.0.31 — importação automática dos produtos do estabelecimento
- 93 preços de produtos fornecidos em 05/11/2026, importados no primeiro início da nova versão.
- Não duplica na reabertura; operação transacional com backup anterior.
- Preserva contas, vendas, históricos, estoque, custos, fotos e códigos já cadastrados.
- Produtos já existentes com mesmo nome e unidade recebem o preço informado, uma única vez.
- Produtos sem cadastro entram com estoque 0 e custo 0; ajuste o estoque antes de vender.
- Produtos vendidos em porções de 100 g usam kg como unidade, com preço convertido para kg.
- **ATENÇÃO:** essa atualização é geral para todas as instalações no mesmo canal GitHub; use canal separado se houver outros clientes.
- Consulte CATALOGO-CLIENTE-2026-11-05.md para revisão antes da publicação.

## Melhorias 2.0.30 — identidade vermelho e amarelo
- Interface de padaria com vermelho cereja nos botões principais, navegação e seleções.
- Amarelo trigo nos ícones, indicadores, gráficos e detalhes; fundo neutro quente.
- Temas claro e escuro mantidos, com contraste entre texto e fundo.
- Catálogo sem fotos usa ilustrações de produtos com cores quentes.
- Alteração apenas visual: permanecem as contas, permissões, impressão, dados, caixa e atualização automática.

## Melhorias 2.0.29
- Confirmação com Sim/Não ao fechar a janela com caixa aberto (não fecha o caixa automaticamente).
- Aviso também depois de sair da conta, quando ainda existe caixa aberto no computador.
- Botão **Abrir caixa** destacado na barra superior e na Visão geral.
- Botão maior na aba Meu caixa; removida a opção de abrir quando o caixa pertence a outro operador.
- Atualiza a Visão geral após abertura, sem manter indicador antigo.


PDV Windows nativo em C# 5, Windows Forms, .NET Framework 4.5+ e SQLite x86. O cliente não precisa de Node, navegador ou GPU dedicada.

## Mudanças desta versão

- Rolagem de catálogo, carrinho e páginas com desaceleração gradual, relógio monotônico e timer ativo somente durante o movimento. O ponteiro direciona a roda para o painel sob o mouse, inclusive sobre seus textos. Grades nativas, listas suspensas e textos multilinha mantêm o comportamento próprio.
- Calendário desenhado com as cores dos temas claro e escuro, setas separadas, destaque da seleção e de hoje. Aceita teclado, anos bissextos, limites de data e abre dentro da área visível da tela. Escape cancela sem mudar o filtro.
- A barra manual e reposicionamentos explícitos interrompem animações pendentes. Redimensionar ou reduzir o conteúdo mantém a posição dentro dos limites.
- O calendário é descartado depois de concluir o fechamento no Windows, para evitar erro de objeto já encerrado ao confirmar a data.
- As tabelas reutilizam a fonte dos cabeçalhos ao trocar tema. Retornos do download não tentam atualizar janelas encerradas. Desconto inválido desabilita o botão de pagamento até a correção.

A estrutura geral da interface, as regras de vendas e caixa, o esquema SQLite, as contas e os perfis foram preservados. A atualização automática da 2.0.4 continua antes do login, com verificação do instalador, backup e adiamento caso haja caixa aberto ou pedido salvo em qualquer conta. O controle Cloudflare continua em consultas de 15 segundos e com a mesma política offline.

Leia `GUIA-PaoCaixa-Windows.md` para instalação, uso, contas, backup e atualização; `VALIDACAO.md` registra o escopo das verificações. Documentos de testes da 2.0.3 são referências históricas, não o procedimento de publicação atual.

## Estrutura e distribuição

`src` contém o aplicativo; `resources` contém a configuração, exemplos e ícone; `vendor/sqlite` contém a DLL oficial x86; `tests` usa somente dados e senhas fictícios. Os dados reais permanecem em `%APPDATA%\PaoCaixa`, separados da pasta de instalação. O instalador não inclui banco de clientes.

O ZIP `PaoCaixa-2.0.36-Source.zip` é compilado e testado pelo workflow `.github/workflows/publicar.yml`. Pull requests validam sem publicar; main publica como Latest somente após sucesso dos testes. A distribuição tem instalador EXE, `latest.yml` em UTF-8 sem BOM com LF e `SHA256.txt`, todos gerados pela mesma compilação. Não é necessário compilar no computador do cliente.

Os números de versão em `version.json`, `src/Updates.cs`, `src/Program.cs`, `resources/app.manifest` e `installer.nsi` precisam concordar. Para desenvolvimento local, `GERAR-INSTALADOR.bat` é uma alternativa à automação.

## Validação

CoreTests verifica vendas, dinheiro/troco, estoque, caixa, permissões, migração e backups. UpdateTests verifica canal, arquivo, cancelamento, prazos, guardas e instalação automática; a versão futura de teste deriva da versão atual, para não ficar desatualizada a cada release. RemotePolicyTests verifica bloqueio e autorização offline. VisualBehaviorTests verifica calendário, rolagem, roteamento da roda e recursos de interface. UiTests e StartupUiTests percorrem a interface com dados fictícios e geram imagens locais.

O GitHub Actions usa o compilador C# do .NET Framework no Windows, executa os testes, consulta o canal HTTPS real e instala silenciosamente o pacote em uma pasta temporária sem abrir o PDV nem cadastrar PCs de teste na Cloudflare. Windows 7/8, Celeron com 4 GB, DPI e periféricos ainda exigem verificação em equipamento real. O instalador não possui assinatura Authenticode.


## Interface de produtos (2.0.21)

Removidos os botões **Adicionar 30 produtos de exemplo** e **Ver movimentações** da barra de ações da tela de produtos e estoque. **Novo produto**, **Editar produto**, **Ajustar estoque** e pesquisa continuam disponíveis. Nenhum produto, fotografia ou registro de movimentação de estoque existente é excluído pela atualização. A lógica de importação de exemplos e o histórico de movimentações foram mantidos internamente para preservar a compatibilidade.

## Fotos próprias nos produtos (2.0.20)

Na tela **Produtos e estoque** > **Novo produto** ou **Editar produto**, use **Escolher foto** para selecionar JPG, PNG, BMP ou GIF. A imagem é reduzida para 360×252 pixels e convertida para JPEG, permitindo funcionamento offline com consumo menor de memória. **Remover** exclui a foto personalizada e volta à imagem do catálogo padrão, quando houver.

As fotos personalizadas ficam dentro do banco `padaria.sqlite` (tabela `product_photos`), junto com os dados do estabelecimento. São incluídas no **Backup completo** (.sqlite), nos backups antes de atualização e no **Backup comercial JSON**. A inclusão, edição ou remoção da foto acontece dentro da mesma transação do cadastro do produto.

Teste no Windows antes de publicar: criar um produto com foto, editar a foto, fechar/reabrir, restaurar backups, e conferir a imagem nos cartões do PDV. Os testes em `tests/CatalogPhotoTests.cs` foram ampliados para cobrir essas operações.

## Organização do painel (2.0.22)

- **Visão geral:** Vendido hoje, Vendas realizadas, Situação do caixa e Estoque para revisar. Atalhos de consultar período e exportar foram removidos somente desta tela; permanecem disponíveis em Relatórios.
- **Meu caixa:** operações de caixa, sangrias, suprimentos, movimentações e histórico mantidos. Se não houver registros, os painéis usam altura reduzida.
- **Relatórios:** Faturamento, Lucro bruto (R$), Margem bruta (%), Tíquete médio e Média diária. Mantidos produtos mais vendidos, formas de pagamento e vendas por dia, com quadro diário compacto em períodos sem vendas.
- **Últimas vendas:** quadro menor quando não há vendas; histórico continua acessível pela aba Vendas.
- Mudanças somente de apresentação, sem alterações no esquema SQLite nem nas operações de vendas.

## Simplificação de Relatórios (2.0.23)

- Removido o cartão **Margem bruta (%)** da tela de Relatórios a pedido do usuário.
- Os quatro indicadores permanecem: **Faturamento**, **Lucro bruto (R$)**, **Tíquete médio**, **Média diária**.
- Ajustados os índices das informações apresentadas e o layout responsivo usa a quantidade real de cartões.
- Sem mudanças nos registros de venda, regras de caixa, SQLite, backups ou exportação.

## Troca de unidade kg ↔ un (2.0.24)

- Campo Unidade habilitado ao editar produtos existentes.
- Ao trocar, os campos de preço, custo, estoque e mínimo são reiniciados para evitar interpretar kg como unidades; o administrador informa os novos valores e confirma a alteração.
- Histórico de movimentações de estoque passa a registrar a unidade da movimentação. Movimentos antigos são anotados na unidade original durante a troca.
- Nova unidade/estoque gravados na mesma transação SQLite; vendas anteriores guardam a unidade original no comprovante.
- Não é permitida troca se o produto estiver em carrinhos não finalizados ou em vendas canceláveis de caixa aberto.
- Não foram alterados os valores dos pedidos concluídos, nem o cálculo de vendas e troco.

## Campo de senha com altura padronizada (2.0.25)

A janela Criar/Editar conta usa um campo de senha de uma única linha (42px, mesma altura dos outros campos) mesmo quando houver espaço sobrando no formulário. A máscara e as regras de senha não mudaram. Há testes de regressão no VisualBehaviorTests.cs.

## Operadores e comprovantes (2.0.26)

- Operador agora vê **Produtos** no menu e pode consultar e ajustar o estoque (entrada/saída com motivo), inclusive sem caixa aberto. Ajustes têm trilha de auditoria com nome da conta.
- Operador continua sem criar/editar produtos, preços, custos e fotos. Perfil Financeiro continua sem permissão de ajuste. Validação ocorre no banco em `Store.AdjustStock`, não apenas na interface.
- Na 2.0.26, o operador recebia uma confirmação para abrir o comprovante; isso foi aprimorado na 2.0.27.
- Falhas da impressora não desfazem uma venda já concluída.
- Testar no Windows: operador acessa Produtos, ajusta estoque e não consegue alterar preços; financeiro não ajusta; venda concluída oferece comprovante; imprimir, cancelar impressão e sem impressora.

## Impressão em duas vias (2.0.27)

- Depois de concluir a venda, a **prévia do comprovante abre automaticamente**, sem precisar aprovar a abertura. A venda já está gravada no banco antes de qualquer tentativa de impressão.
- A prévia pergunta **Imprimir primeira via?**. Em **Sim**, envia a via do estabelecimento diretamente à impressora **padrão do Windows**, sem o seletor de impressoras; em **Não**, não envia nenhuma impressão.
- Se a primeira via foi enviada ao driver, a prévia pergunta **Imprimir também a via do cliente?**. O segundo Sim imprime uma via identificada como cliente; o Não encerra o fluxo automático.
- A prévia continua aberta para conferência, reimpressão manual de qualquer via ou exportação TXT. Pelo histórico **Vendas**, a prévia continua disponível sem as perguntas automáticas.
- Sem impressora padrão válida ou com erro de impressão, exibe uma mensagem explicativa. **Não cancela nem duplica a venda.** O aplicativo não consegue garantir que o papel saiu; verifica somente se o Windows aceitou o trabalho. Configure a impressora conectada como **impressora padrão do Windows**.

**Validação pendente:** execução em Windows com impressora real, incluindo cancelamentos de cada pergunta, impressora indisponível, duas vias e impressão manual. O erro da execução #64 no GitHub Actions requer as linhas da etapa vermelha para diagnóstico conclusivo; o print da lista de execuções não contém esse log.

## Correção de compilação (2.0.28)

- Corrigido erro `CS1513` de sintaxe em `src/Ui.cs` (método `Fields.Add`):
  um comentário de linha na versão anterior ocultava o fechamento do método.
- O campo de senha permanece com altura de 42 px, e as funcionalidades de
  impressão em duas vias e permissões dos operadores da 2.0.27 são preservadas.
