# Pão & Caixa 2.0.38 — roteiro de validação

1. Publique `PaoCaixa-2.0.38-Source.zip` e confirme o GitHub Actions verde antes de atualizar a instalação.
2. Com um caixa aberto, crie uma venda de teste e vá em **Vendas → Cancelar venda**.
3. Confirme que a janela exige motivo e **Senha de autorização** mascarada.
4. Tente senha vazia e errada; a venda, o dinheiro e o estoque devem permanecer inalterados.
5. Use a senha global combinada com o responsável; a venda deve ficar com status **Cancelada**, com estorno de estoque e registro em auditoria. Não há exclusão física do histórico.
6. Com o caixa ainda aberto, clique no X da janela e depois pressione Alt+F4. Nas duas tentativas, confira o alerta e escolha **Não**: o aplicativo deve permanecer aberto. Escolhendo **Sim**, o programa encerra mas o caixa fica aberto.
7. Feche o caixa normalmente e confira que o programa sai sem o alerta de caixa aberto.
8. Teste também a instalação de uma atualização e confirme que a saída automática do atualizador segue funcionando.

Observação: a regra de cancelamento da versão-base permanece — somente vendas do caixa atualmente aberto e, para operadores, somente as próprias vendas. A senha de cancelamento é fixa no executável, não no banco SQLite. Sua universalidade não oferece proteção forte contra alguém com acesso ao programa ou ao código.
