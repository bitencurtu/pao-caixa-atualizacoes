﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Diagnostics;
using System.Collections;
using System.Web.Script.Serialization;
using PaoCaixa;
class CoreTests {
 static int n;static void Check(bool ok,string name){if(!ok)throw new Exception("FALHA: "+name);n++;Console.WriteLine("OK "+name);}
 static void Denied(Action a,string name){bool denied=false;try{a();}catch{denied=true;}Check(denied,name);}
 public class Vector {public string password,salt,expected;public int N,r,p;}
 static bool SameJson(object a,object b){var serializer=new JavaScriptSerializer{MaxJsonLength=int.MaxValue};return Same(serializer.DeserializeObject(J.Write(a)),serializer.DeserializeObject(J.Write(b)));}
 static bool Same(object a,object b){
  if(a==null||b==null)return a==b;
  var da=a as Dictionary<string,object>;var db=b as Dictionary<string,object>;
  if(da!=null&&db!=null){if(da.Count!=db.Count)return false;foreach(var key in da.Keys)if(!db.ContainsKey(key)||!Same(da[key],db[key]))return false;return true;}
  var la=a as IList;var lb=b as IList;if(la!=null&&lb!=null){if(la.Count!=lb.Count)return false;for(int i=0;i<la.Count;i++)if(!Same(la[i],lb[i]))return false;return true;}
  return object.Equals(a,b);
 }
 static void Main(string[] args){string dir=args[0];foreach(var v in J.Read<List<Vector>>(File.ReadAllText(dir+"/vectors.json")))Check(Passwords.Hash(v.password,v.salt,v.N,v.r,v.p)==v.expected,"scrypt compatível com Node / UTF-8 "+v.N);
  var before=J.Read<State>(File.ReadAllText(dir+"/before.json"));using(var db=new Store(dir)){Denied(()=>db.Products(),"dados exigem login");Denied(()=>db.NextNumber(),"número do pedido exige login");db.Login(Store.OwnerEmail,"Teste-Pdv-2026");var after=db.Export();Check(db.NextNumber()==before.nextSale,"número da venda exibido sem alterar numeração");Check(SameJson(before,after),"migração mantém todos os dados comerciais");Check(db.GetDraft().note=="Pedido preservado","pedido antigo preservado");Check(db.Users().Count==4,"contas antigas preservadas");using(var sql=new Sqlite(db.FilePath)){var ids=J.Read<List<Dictionary<string,object>>>(File.ReadAllText(dir+"/identities.json"));foreach(var old in ids){var row=sql.Query("SELECT id,email,role,salt,password_hash,credential_version FROM users WHERE id=?",old["id"])[0];Check(SameJson(row,old),"credenciais preservadas "+old["role"]);}Denied(()=>sql.Exec("DELETE FROM users WHERE is_owner=1"),"proprietário protegido no SQLite");Denied(()=>sql.Exec("UPDATE users SET active=0 WHERE is_owner=1"),"proprietário não pode ser desativado");}
   Check(Directory.GetFiles(db.Backups,"*-antes-versao-nativa-*.sqlite").Length==1,"backup anterior à migração");Check(db.SessionTotals(db.Open().id).drawer==15140,"saldo anterior inclui venda sem suprimento duplicado");Denied(()=>db.PrepareInstall(),"atualização impedida com caixa aberto");
   var report=ReportResult.Build(db.Report(DateTime.Today.AddDays(-1),DateTime.Today.AddDays(2)));Check(report.revenue==8280&&report.count==2,"faturamento preservado");Check(report.daily.Values.Sum()==report.revenue,"gráfico diário usa somente o faturamento do período");Check(report.ranking.Where(x=>x.unit=="un").First().quantity==5000,"ranking por quantidade em unidades");Check(report.ranking.Where(x=>x.unit=="kg").First().quantity==1000,"ranking de peso separado");
   db.Logout();db.Login("financeiro@teste.local","Teste-Pdv-2026");Check(db.Sales(DateTime.Today.AddDays(-1),DateTime.Today.AddDays(2)).Count==2,"financeiro consulta todas as vendas");Denied(()=>db.OpenCash(0),"financeiro não abre caixa");Denied(()=>db.SetDraft(new Draft()),"financeiro não cria pedido");Denied(()=>db.AdjustStock(before.products[0].id,1000,"Teste"),"financeiro não altera estoque");Denied(()=>db.Export(),"financeiro não exporta contas no backup completo");Denied(()=>db.Users(),"painel exclusivo do proprietário");
   Denied(()=>db.AuditEntries(DateTime.Today,DateTime.Today.AddDays(1)),"financeiro não consulta a auditoria");
   db.Logout();db.Login("operador@teste.local","Teste-Pdv-2026");Check(db.Open()==null&&db.Occupied(),"operador não recebe caixa de outra conta");Check(db.Sales(DateTime.Today.AddDays(-1),DateTime.Today.AddDays(2)).Count==0,"operador não vê vendas de outro caixa");Check(db.Products().All(prod=>prod.cost==0),"operador não recebe custo de produto");Check(db.GetDraft().note=="Privado do operador","rascunho privado preservado");Denied(()=>db.MoveCash("supply",100,"Teste"),"operador não move caixa de outro");Denied(()=>db.SaveProduct(before.products[0]),"operador não cadastra produto");
   var stockItem=db.Products().First(x=>x.id==before.products[0].id);
   long stockBefore=stockItem.stock;
   db.AdjustStock(stockItem.id,1000);
   Check(db.Products().First(x=>x.id==stockItem.id).stock==stockBefore+1000,"operador pode repor estoque");
   db.AdjustStock(stockItem.id,-1000,"Correção teste");
   Check(db.Products().First(x=>x.id==stockItem.id).stock==stockBefore,"operador pode corrigir estoque sem alterar quantidade final");
   Denied(()=>db.StockHistory(stockItem.id),"histórico administrativo permanece protegido");
   Denied(()=>db.AuditEntries(DateTime.Today,DateTime.Today.AddDays(1)),"operador não consulta a auditoria");
   db.Logout();db.Login(Store.OwnerEmail,"Teste-Pdv-2026");var totals=db.SessionTotals(db.Open().id);var counted=new Dictionary<string,long>(totals.payments);counted["dinheiro"]=totals.drawer;db.CloseCash(counted);db.SetDraft(new Draft());Denied(()=>db.PrepareInstall(),"atualização detecta rascunho de outra conta");db.Logout();db.Login("operador@teste.local","Teste-Pdv-2026");db.SetDraft(new Draft());db.OpenCash(5000);var p=db.Products().First(x=>x.code=="002");long initial=p.stock;var draft=new Draft{cart=new List<Line>{new Line{productId=p.id,quantity=2000}},note="Teste"};db.SetDraft(draft);var sale=db.Finish(draft.cart,100,new List<Payment>{new Payment{method="dinheiro",amount=400},new Payment{method="pix",amount=200}},500,"Misto");Check(sale.total==600&&sale.change==100,"pagamento misto e troco exatos");Check(db.SessionTotals(db.Open().id).drawer==5400,"dinheiro da venda entra automaticamente");Check(db.Products().First(x=>x.id==p.id).stock==initial-2000,"baixa automática de estoque");Check(db.GetDraft().cart.Count==0,"venda limpa só o próprio pedido");string cancelTestPassword=System.Text.Encoding.UTF8.GetString(Convert.FromBase64String("RmFiaWFub1BhZGFyaWExMjM="));
   Denied(()=>db.Cancel(sale.id,"Teste indevido","errada"),"senha incorreta bloqueia cancelamento no banco de operações");
   Denied(()=>db.Cancel(sale.id,"Teste indevido",null),"senha ausente bloqueia cancelamento");
   Check(db.SessionTotals(db.Open().id).drawer==5400&&db.Products().First(x=>x.id==p.id).stock==initial-2000,"tentativas inválidas não alteram venda nem estoque");
   db.Cancel(sale.id,"Cliente desistiu",cancelTestPassword);Check(db.SessionTotals(db.Open().id).drawer==5000&&db.Products().First(x=>x.id==p.id).stock==initial,"cancelamento autorizado restaura caixa e estoque");
   Denied(()=>db.Cancel(sale.id,"Novamente",cancelTestPassword),"cancelamento não duplica estorno");Denied(()=>db.MoveCash("withdrawal",5001,"Teste"),"sangria acima do saldo negada");db.MoveCash("supply",200,"Troco");db.MoveCash("withdrawal",300,"Cofre");Check(db.SessionTotals(db.Open().id).drawer==4900,"suprimento e sangria calculados");db.CloseCash(new Dictionary<string,long>{{"dinheiro",4900},{"pix",0},{"debito",0},{"credito",0}});Check(db.Sales(DateTime.Today.AddDays(-1),DateTime.Today.AddDays(2)).Count==0,"operador não consulta períodos fechados");
   db.Logout();db.Login("admin@teste.local","Teste-Pdv-2026");
   var audit=db.AuditEntries(DateTime.Today.AddDays(-1),DateTime.Today.AddDays(1));
   Check(audit.Any(x=>(string)x["action"]=="account.create"&&(string)x["detail"]=="admin@teste.local"),"auditoria existente continua visível após atualização");
   Check(audit.Any(x=>(string)x["action"]=="stock.adjust"&&(string)x["actor"]=="Operador teste"&&((string)x["detail"]).Contains("Entrada de estoque")),"estoque sem motivo manual registra responsável e entrada");
   Check(audit.Count(x=>(string)x["action"]=="sale.cancel")==1,"cancelamento repetido não gera evento de auditoria");
   Check(audit.Any(x=>(string)x["action"]=="sale.finish"&&(string)x["actor"]=="Operador teste"),"venda concluída identifica operador");
   Check(db.AuditEntries(DateTime.Today.AddDays(-10),DateTime.Today.AddDays(-9)).Count==0,"auditoria respeita o filtro de período");
   Denied(()=>db.Block(true,"Mensalidade"),"administrador comum não bloqueia instalação");Denied(()=>db.SaveUser(null,"extra@teste.local","Extra","admin",true,"Teste-Pdv-2026"),"administrador comum não cria conta");db.Logout();db.Login(Store.OwnerEmail,"Teste-Pdv-2026");db.Block(true,"Teste de bloqueio");db.Logout();Denied(()=>db.Login("financeiro@teste.local","Teste-Pdv-2026"),"bloqueio impede acesso das demais contas");db.Login(Store.OwnerEmail,"Teste-Pdv-2026");db.Block(false,"");Check(File.Exists(db.PrepareInstall()),"atualização gera backup com caixa fechado");
   var snapshot=db.Export();db.Restore(snapshot,db.Revision());Check(db.Users().Count==4,"restauração comercial mantém as contas");var invalid=J.Read<State>(J.Write(snapshot));invalid.sales[0].total++;Denied(()=>db.Restore(invalid,db.Revision()),"backup inconsistente rejeitado sem alterar banco");Check(db.Export().sales[0].total==snapshot.sales[0].total,"restauração inválida preserva os valores");
   // Somente admin autenticado, sob confirmacao da interface, pode zerar testes.
   var originalSettings=J.Write(db.Shop());
   Check(!db.ClientResetApplied(),"limpeza comercial ainda nao aplicada");
   var cleanBackup=db.ResetDemoDataAndInstallClientCatalog();
   Check(File.Exists(cleanBackup),"backup completo criado antes da limpeza comercial");
   var clean=db.Export();
   Check(clean.products.Count==117,"catalogo exclusivo de 117 produtos");
   Check(clean.products.All(x=>x.stock==0&&x.cost==0),"estoque e custo novos nao foram inventados");
   Check(clean.products.Single(x=>x.name=="Pão francês").unit=="un"&&clean.products.Single(x=>x.name=="Pão francês").price==50,"pao frances vendido por unidade a 50 centavos");
   Check(clean.sales.Count==0&&clean.sessions.Count==0&&clean.cashMoves.Count==0&&clean.stockMoves.Count==0,"vendas caixas e historicos comerciais removidos");
   Check(clean.productPhotos.Count==0,"fotos de produtos antigos removidas");
   Check(db.NextNumber()==1,"numeracao das vendas reiniciada");
   Check(db.GetDraft().cart.Count==0&&db.Users().Count==4&&J.Write(db.Shop())==originalSettings,"rascunhos apagados e contas e configuracoes mantidas");
   Check(db.ClientResetApplied(),"marcador de limpeza aplicado");
   Denied(()=>db.ResetDemoDataAndInstallClientCatalog(),"segunda limpeza proibida para preservar futuras vendas");
   // Simula um cliente que fez o reset na 2.0.32 (93 itens) e agora atualiza.
   // Não apaga nenhum registro real: este é um banco temporário de teste.
   using(var raw=new Sqlite(db.FilePath)){
    raw.Transaction(()=>{
     for(int i=ClientCatalog.PreviousCatalogCount;i<ClientCatalog.Items.Length;i++){
      string code="PXC-C2611-"+(i+1).ToString("000");
      var product=db.Products().First(x=>x.code==code);
      raw.Exec("DELETE FROM products WHERE id=?",product.id);
     }
     raw.Exec("DELETE FROM client_catalog_imports WHERE migration_key=?",ClientCatalog.ExtrasMigrationKey);
    });
   }
   Check(db.Products().Count==93,"fixture simula 93 itens apos reset na 2.0.32");
   var beforeExtras=db.Export();
   Check(db.AppendClientCatalogExtrasAfterReset()==24,"2.0.33 adiciona somente 24 itens em base ja limpa");
   Check(db.Products().Count==117,"2.0.33 preserva anteriores e adiciona 24 itens");
   Check(db.AppendClientCatalogExtrasAfterReset()==0,"importacao incremental nao repete na segunda abertura");
   Check(J.Write(db.Export().sales)==J.Write(beforeExtras.sales)&&J.Write(db.Export().sessions)==J.Write(beforeExtras.sessions),"importacao incremental preserva todo historico financeiro");
   Check(db.Products().All(x=>x.stock==0&&x.cost==0),"nenhum estoque/custo foi inventado");


  }
  var prefs=Preferences.Load(dir);Check(prefs.url==Preferences.DefaultChannel,"GitHub preconfigurado");prefs.theme="dark";prefs.Save(dir);Check(Preferences.Load(dir).theme=="dark","tema escuro persiste");prefs.theme="light";prefs.Save(dir);Check(Preferences.Load(dir).theme=="light","tema claro persiste");Denied(()=>Preferences.ValidateUrl("http://example.com"),"canal sem HTTPS rejeitado");Denied(()=>Updates.Parse("version: 3.0.0\npath: ../../bad.exe\nsha512: bad\n"),"atualização malformada rejeitada");Console.WriteLine("PASS "+n+" verificações");
 }
}
