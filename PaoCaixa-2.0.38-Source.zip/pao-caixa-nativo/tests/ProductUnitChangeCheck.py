"""Static regression for editable product units; run with Python 3."""
from pathlib import Path
root=Path(__file__).resolve().parent.parent
ui=(root/'src/MainForm.cs').read_text(encoding='utf-8-sig')
store=(root/'src/Store.cs').read_text(encoding='utf-8-sig')
models=(root/'src/Models.cs').read_text(encoding='utf-8-sig')
assert 'unit.Enabled=old==null' not in ui
assert 'unit.SelectedIndexChanged' in ui
assert 'quantity.Enabled=changed;' in ui
assert 'price.Text="";cost.Text="0,00";quantity.Text="0";min.Text="0";' in ui
assert 'Trocar "+old.unit+" por "+unit.SelectedItem+' in ui
assert 'old.unit!=p.unit' in store
assert 'p.stock=old==null?p.stock:old.stock' not in store
assert 'unidade não pode ser alterada' not in store
assert 'cart.Any(line=>line.productId==p.id)' in store
assert 'openRegisterIds.Contains(sale.sessionId)' in store
assert 'move.unit=old.unit;' in store
assert 'unit=old.unit,quantity=-old.stock' in store
assert 'unit=p.unit,quantity=p.stock' in store
assert 'string.IsNullOrEmpty(move.unit)?p.unit:move.unit' in ui
assert 'sale.items.Any(item=>item.productId==p.id)' in store
assert 'p.unit!=i.unit' in store
assert 'saleId,unit;' in models
assert '2.0.38' in (root/'version.json').read_text()
print('PASS product unit change safety checks')
