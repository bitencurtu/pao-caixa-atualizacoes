from pathlib import Path
import base64, hashlib, json, re
root=Path(__file__).resolve().parents[1]
main=(root/'src/MainForm.cs').read_text(encoding='utf-8-sig')
store=(root/'src/Store.cs').read_text(encoding='utf-8-sig')
gate=(root/'src/CancellationAuthorization.cs').read_text(encoding='utf-8')
assert 'var authorization=f.TextField("Senha de autorização","",true);' in main
assert 'if(!CancellationAuthorization.Verify(password))' in main
assert 'db.Cancel(v.id,reason,password)' in main
assert 'public void Cancel(string id,string reason,string authorizationPassword)' in store
assert 'if(!CancellationAuthorization.Verify(authorizationPassword))throw' in store
assert 'public void Cancel(string id,string reason)' not in store
assert 'product_photos' not in gate and 'sqlite' not in gate.lower()
hash_in_src=re.search(r'ExpectedDigest="([^"]+)"',gate).group(1)
assert len(base64.b64decode(hash_in_src))==32
assert 'FormClosing+=(sender,e)=>ConfirmExit(e)' in main
exit=main.split('void ConfirmExit(FormClosingEventArgs e){')[1].split('void GuardUi(',1)[0]
for fragment in ('db.HasOpenCash()','MessageBoxButtons.YesNo','MessageBoxDefaultButton.Button2',
                 'if(choice!=DialogResult.Yes){e.Cancel=true;return;}'):
    assert fragment in exit
assert exit.index('db.HasOpenCash()') < exit.index('MessageBoxButtons.YesNo')
assert json.loads((root/'version.json').read_text(encoding='utf-8'))['version']=='2.0.38'
print('PASS: senha global no aplicativo, negativa antes do estorno e aviso de caixa aberto')
