﻿#!/usr/bin/env python3
"""Source-level guardrails run without C# compiler; Windows CI runs CoreTests."""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
main=(root/'src/MainForm.cs').read_text(encoding='utf-8')
store=(root/'src/Store.cs').read_text(encoding='utf-8')
assert 'new[]{"Pedidos","Produtos","Meu caixa","Vendas","Meu perfil"}' in main
assert 'if(!stock&&user.role=="admin")' in main, 'Operators must not edit product/price fields'
assert 'bar.Controls.Add(Ui.Button("Ajustar estoque"' in main
assert 'User StockEditor()' in store and 'u.role!="admin"&&u.role!="operator"' in store
assert re.search(r'public void AdjustStock\([^)]*\)\{var editor=StockEditor\(\)', store)
assert 'public void SaveProduct(Product p,byte[] customPhoto=null,bool removePhoto=false){Admin();' in store
assert 'public void StockHistory' not in store or 'public List<StockMove> StockHistory(string id,int offset=0){Admin();' in store
checkout=main.split('void Checkout(){',1)[1].split('void OpenCash()',1)[0]
assert checkout.index('db.Finish(')<checkout.index('Receipt(sale,true)')
assert 'Deseja abrir o comprovante para imprimir?' not in checkout
assert 'try{Receipt(sale,true);}' in checkout
receipt=main.split('void Receipt(Sale v,bool afterCheckout=false){',1)[1].split('void BuildProducts(bool stock)',1)[0]
assert 'if(afterCheckout)' in receipt and 'f.Shown+=' in receipt
assert receipt.index('Imprimir a primeira via?')<receipt.index('Imprimir também a via do cliente?')
assert receipt.count('PrintReceipt(f,receipt,"Via do estabelecimento",ref printer)')>=2
assert 'if(!PrintReceipt(f,receipt,"Via do estabelecimento",ref printer))return;' in receipt
assert 'if(second==DialogResult.Yes)PrintReceipt(f,receipt,"Via do cliente",ref printer)' in receipt
assert 'Ui.Show(this,f)' in receipt
printer=(root/'src/ReceiptDocument.cs').read_text(encoding='utf-8')
assert 'new ReceiptPreview(receipt)' in receipt
assert 'ReceiptPrinter.Choose(owner,printer)' in main
assert 'doc.PrinterSettings.IsValid' in printer
assert 'doc.Print();' in printer and 'doc.PrinterSettings.PrintToFile=false' in printer
assert 'PrinterSettings.InstalledPrinters' in printer and 'PORTPROMPT:' in printer
adjust=main.split('void Adjust(Product p)',1)[1].split('void ',1)[0]
assert 'db.AdjustStock(p.id,amount)' in adjust and 'Motivo' not in adjust
assert 'AuditEntries(DateTime from,DateTime until,int offset=0){\n   Admin();' in store
assert '2.0.38' in (root/'version.json').read_text(encoding='utf-8')
print('PASS operator inventory, automatic preview and two-copy receipt source checks')
