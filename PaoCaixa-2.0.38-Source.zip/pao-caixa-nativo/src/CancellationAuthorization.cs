using System;
using System.Security.Cryptography;
using System.Text;
namespace PaoCaixa {
 // Politica global do aplicativo: nenhuma instalacao grava senha de cancelamento no banco.
 // ATENCAO: senha fixa compilada pode ser recuperada por quem tem acesso ao executavel/codigo.
 internal static class CancellationAuthorization {
  // SHA-256 da senha fixa distribuida com o aplicativo (nao a senha em texto claro).
  const string ExpectedDigest="Dk9W4i7NnwyyP2scQu9F2dOMRtV6NvTY9T1nq6VVcZI=";
  internal static bool Verify(string password){
   if(string.IsNullOrEmpty(password)||password.Length>128)return false;
   byte[] input=Encoding.UTF8.GetBytes(password),expected=Convert.FromBase64String(ExpectedDigest);
   try{
    using(var sha=SHA256.Create()){
     var actual=sha.ComputeHash(input);
     int mismatch=actual.Length^expected.Length;
     for(int i=0;i<actual.Length;i++)mismatch|=actual[i]^(i<expected.Length?expected[i]:0);
     return mismatch==0;
    }
   }finally{Array.Clear(input,0,input.Length);}
  }
 }
}
