using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace PaoCaixa {
 public partial class MainForm {
  static string AuditAction(string action){
   switch(action){
    case "login":return "Entrou no sistema";
    case "account.create":return "Criou conta";
    case "account.update":return "Editou conta";
    case "password.change":return "Alterou a própria senha";
    case "stock.adjust":return "Ajustou estoque";
    case "product.create":return "Cadastrou produto";
    case "product.update":return "Editou produto";
    case "sale.finish":return "Concluiu venda";
    case "sale.cancel":return "Cancelou venda";
    case "sale.cancel.password":return "Configurou senha de cancelamento";
    case "cash.open":return "Abriu caixa";
    case "cash.close":return "Fechou caixa";
    case "cash.supply":return "Registrou suprimento";
    case "cash.withdrawal":return "Registrou sangria";
    case "settings.update":return "Alterou configurações";
    case "installation.block":return "Bloqueou a instalação";
    case "installation.unblock":return "Desbloqueou a instalação";
    case "catalog.cleanstart":return "Instalou catálogo da padaria";
    case "catalog.examples":return "Importou produtos de exemplo";
    case "restore":return "Restaurou dados comerciais";
    default:return action;
   }
  }

  void BuildAudit(){
   if(user.role!="admin")throw new UnauthorizedAccessException("A auditoria é exclusiva para administradores.");
   var content=Content();
   var bar=Ui.Flow();
   var from=new DateField{Value=DateTime.Today.AddDays(-6)};
   var to=new DateField{Value=DateTime.Today};
   bar.Controls.Add(Ui.Caption("De"));bar.Controls.Add(from);
   bar.Controls.Add(Ui.Caption("até"));bar.Controls.Add(to);
   var grid=Ui.Grid("Data e hora","Conta","Ação","Detalhes");
   grid.Columns[0].FillWeight=24;
   grid.Columns[1].FillWeight=23;
   grid.Columns[2].FillWeight=28;
   grid.Columns[3].FillWeight=56;
   grid.CellDoubleClick+=(sender,e)=>{
    if(e.RowIndex<0)return;
    var cells=grid.Rows[e.RowIndex].Cells;
    MessageBox.Show(this,cells[0].Value+" • "+cells[1].Value+"\n\n"+cells[3].Value,cells[2].Value.ToString());
   };
   var empty=Ui.Caption("");
   empty.Dock=DockStyle.Bottom;empty.Height=30;empty.AutoSize=false;
   DateTime start=from.Value.Date,until=to.Value.Date.AddDays(1);
   int offset=0;
   PaginationBar pager=null;
   Action<DateTime,DateTime,int> load=(requestedStart,requestedUntil,requestedOffset)=>{
    if(grid.IsDisposed||page!="Auditoria")return;
    if(requestedUntil<=requestedStart)throw new ArgumentException("Confira o período da auditoria.");
    Fire(()=>db.AuditEntries(requestedStart,requestedUntil,requestedOffset),result=>{
     if(grid.IsDisposed||page!="Auditoria")return;
     var rows=(List<Dictionary<string,object>>)result;
     start=requestedStart;until=requestedUntil;offset=requestedOffset;
     grid.Rows.Clear();
     foreach(var row in rows.Take(100)){
      var timestamp=(string)row["at"];
      DateTimeOffset local;
      if(DateTimeOffset.TryParse(timestamp,out local))timestamp=local.ToLocalTime().ToString("dd/MM/yyyy HH:mm:ss");
      grid.Rows.Add(timestamp,row["actor"],AuditAction((string)row["action"]),row["detail"]);
     }
     empty.Text=rows.Count==0?"Nenhuma atividade encontrada neste período.":"Clique duas vezes em uma linha para ver os detalhes.";
     pager.PageText="Página "+(offset/100+1);
     pager.Previous.Enabled=offset>0;
     pager.Next.Enabled=rows.Count>100;
    });
   };
   pager=new PaginationBar(()=>load(start,until,Math.Max(0,offset-100)),()=>load(start,until,offset+100));
   pager.Previous.Enabled=pager.Next.Enabled=false;
   bar.Controls.Add(Ui.Button("Consultar",()=>load(from.Value.Date,to.Value.Date.AddDays(1),0)));
   content.Controls.Add(grid);content.Controls.Add(empty);content.Controls.Add(pager);content.Controls.Add(bar);
   PostUi(()=>load(start,until,0));
  }
 }
}
