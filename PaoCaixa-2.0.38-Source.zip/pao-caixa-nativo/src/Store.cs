﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
namespace PaoCaixa {
 public sealed class Store:IDisposable {
  public const string OwnerId="owner-biel",OwnerEmail="biel.bitencourt01@gmail.com";
  public readonly object Sync=new object(); public readonly string DirectoryPath,FilePath,Backups;
  readonly Sqlite sql; readonly RemoteControl remote; string sessionId;long sessionVersion; User dummy;
  static readonly string[] Tables={"products","sales","sessions","cash_moves","stock_moves"};
  public static string Resource(string name){using(var s=Assembly.GetExecutingAssembly().GetManifestResourceStream(name))using(var r=new StreamReader(s))return r.ReadToEnd();}
  public Store(string directory,RemoteControl remoteControl=null){remote=remoteControl;DirectoryPath=directory;FilePath=Path.Combine(directory,"padaria.sqlite");Backups=Path.Combine(directory,"backups");Directory.CreateDirectory(Backups);bool existing=File.Exists(FilePath);sql=new Sqlite(FilePath);
   try{
    bool firstNative=sql.Scalar("SELECT name FROM sqlite_master WHERE name='native_sales_at'")==null;
    if(existing&&(string)sql.Scalar(firstNative?"PRAGMA integrity_check":"PRAGMA quick_check")!="ok")throw new Exception("O banco precisa ser recuperado. O arquivo original foi preservado.");long version=Convert.ToInt64(sql.Scalar("PRAGMA user_version"));if(version>2)throw new Exception("Banco de uma versão mais nova. Instale a versão mais recente.");
    if(version==0){if(sql.Query("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").Count!=0)throw new Exception("Banco desconhecido. O arquivo original foi preservado.");sql.Transaction(()=>{
      sql.Exec("CREATE TABLE metadata(singleton INTEGER PRIMARY KEY CHECK(singleton=1),revision INTEGER NOT NULL,next_sale INTEGER NOT NULL,settings TEXT NOT NULL)");foreach(var t in Tables)sql.Exec("CREATE TABLE "+t+"(id TEXT PRIMARY KEY,position INTEGER NOT NULL,payload TEXT NOT NULL)");sql.Exec("CREATE TABLE draft(singleton INTEGER PRIMARY KEY CHECK(singleton=1),payload TEXT NOT NULL)");WriteState(D.Validate(J.Read<State>(Resource("seed.json"))));sql.Exec("PRAGMA user_version=1");
     });}
    sql.Exec("PRAGMA journal_mode=WAL");
    sql.Exec("CREATE TABLE IF NOT EXISTS product_photos(product_id TEXT PRIMARY KEY REFERENCES products(id) ON DELETE CASCADE,image BLOB NOT NULL)");
    if(firstNative)D.Validate(LoadRaw());else if(sql.Scalar("SELECT revision FROM metadata WHERE singleton=1")==null)throw new Exception("Banco incompleto.");
    if(version<2){if(existing)Backup("antes-contas");sql.Transaction(()=>{
      sql.Exec("CREATE TABLE users(id TEXT PRIMARY KEY,email TEXT NOT NULL UNIQUE COLLATE NOCASE,name TEXT NOT NULL,role TEXT NOT NULL CHECK(role IN ('admin','operator','financial')),is_owner INTEGER NOT NULL DEFAULT 0 CHECK(is_owner IN(0,1)),active INTEGER NOT NULL DEFAULT 1 CHECK(active IN(0,1)),salt TEXT NOT NULL,password_hash TEXT NOT NULL,credential_version INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL)");
      sql.Exec("CREATE UNIQUE INDEX only_one_owner ON users(is_owner) WHERE is_owner=1");sql.Exec("CREATE TRIGGER protect_owner_delete BEFORE DELETE ON users WHEN OLD.is_owner=1 BEGIN SELECT RAISE(ABORT,'A conta proprietária não pode ser removida.'); END");
      sql.Exec("CREATE TRIGGER protect_owner_update BEFORE UPDATE ON users WHEN OLD.is_owner=1 AND(NEW.id<>OLD.id OR NEW.email<>OLD.email OR NEW.role<>'admin' OR NEW.is_owner<>1 OR NEW.active<>1) BEGIN SELECT RAISE(ABORT,'A conta proprietária não pode ser alterada ou bloqueada.'); END");
      sql.Exec("CREATE TABLE user_drafts(user_id TEXT PRIMARY KEY REFERENCES users(id),payload TEXT NOT NULL)");sql.Exec("CREATE TABLE login_attempts(singleton INTEGER PRIMARY KEY CHECK(singleton=1),failures INTEGER NOT NULL,blocked_until INTEGER NOT NULL)");sql.Exec("CREATE TABLE installation_control(singleton INTEGER PRIMARY KEY CHECK(singleton=1),blocked INTEGER NOT NULL DEFAULT 0,reason TEXT NOT NULL DEFAULT '',changed_at TEXT)");sql.Exec("INSERT INTO installation_control(singleton) VALUES(1)");sql.Exec("CREATE TABLE access_audit(id INTEGER PRIMARY KEY,at TEXT NOT NULL,actor_id TEXT NOT NULL,action TEXT NOT NULL,detail TEXT NOT NULL)");sql.Exec("PRAGMA user_version=2");
     });}
    sql.Transaction(()=>{
     if(!sql.Query("PRAGMA table_info(access_audit)").Any(column=>(string)column["name"]=="actor_name"))
      sql.Exec("ALTER TABLE access_audit ADD COLUMN actor_name TEXT");
    });
    sql.Exec("CREATE INDEX IF NOT EXISTS access_audit_at ON access_audit(at,id)");
    var bootstrap=J.Read<Dictionary<string,string>>(Resource("owner-bootstrap.json"));dummy=new User{salt=bootstrap["salt"],password_hash=bootstrap["password_hash"]};
    if(sql.Scalar("SELECT id FROM users WHERE is_owner=1")==null){sql.Transaction(()=>{
      sql.Exec("INSERT INTO users(id,email,name,role,is_owner,active,salt,password_hash,created_at) VALUES(?,?,?,'admin',1,1,?,?,?)",OwnerId,OwnerEmail,"Biel Carreon",dummy.salt,dummy.password_hash,D.Now());
      string raw=(string)sql.Scalar("SELECT payload FROM draft WHERE singleton=1")??J.Write(new Draft());sql.Exec("INSERT INTO user_drafts VALUES(?,?)",OwnerId,raw);sql.Exec("INSERT OR REPLACE INTO draft VALUES(1,?)",J.Write(new Draft()));var r=OpenRaw();if(r!=null&&string.IsNullOrEmpty(r.userId)){r.userId=OwnerId;Update("sessions",r.id,r);}
     });}
    var owner=UserRecord("SELECT * FROM users WHERE is_owner=1");if(owner==null||owner.id!=OwnerId||owner.email!=OwnerEmail||owner.role!="admin"||owner.active!=1)throw new Exception("Conta proprietária inválida. Recupere um backup.");
    if(existing&&firstNative)Backup("antes-versao-nativa");
    sql.Exec("CREATE INDEX IF NOT EXISTS native_sales_session ON sales(json_extract(payload,'$.sessionId'),json_extract(payload,'$.status'))");sql.Exec("CREATE INDEX IF NOT EXISTS native_sales_at ON sales(json_extract(payload,'$.at'))");sql.Exec("CREATE INDEX IF NOT EXISTS native_session_status ON sessions(json_extract(payload,'$.status'))");sql.Exec("CREATE INDEX IF NOT EXISTS native_cash_session ON cash_moves(json_extract(payload,'$.sessionId'))");sql.Exec("CREATE INDEX IF NOT EXISTS native_stock_product ON stock_moves(json_extract(payload,'$.productId'))");
   }catch{sql.Dispose();throw;}
  }
  static User MapUser(Dictionary<string,object> r){return new User{id=(string)r["id"],email=(string)r["email"],name=(string)r["name"],role=(string)r["role"],salt=(string)r["salt"],password_hash=(string)r["password_hash"],created_at=(string)r["created_at"],active=(long)r["active"],is_owner=(long)r["is_owner"],credential_version=(long)r["credential_version"]};}
  User UserRecord(string q,params object[] a){var rows=sql.Query(q,a);return rows.Count==0?null:MapUser(rows[0]);}
  public ControlState Control(){Current();return ControlRaw();}
  ControlState ControlRaw(){var r=sql.Query("SELECT * FROM installation_control WHERE singleton=1")[0];return new ControlState{blocked=(long)r["blocked"],reason=(string)r["reason"],changed_at=(string)r["changed_at"]};}
  public User Current(){if(remote!=null)remote.AssertAllowed();var u=sessionId==null?null:UserRecord("SELECT * FROM users WHERE id=?",sessionId);if(u==null||u.active!=1||u.credential_version!=sessionVersion){sessionId=null;throw new Exception("Entre com seu e-mail e senha para continuar.");}if(!u.Owner&&ControlRaw().blocked==1)throw new Exception("O acesso desta instalação foi suspenso. Entre em contato com o responsável.");return u;}
  public User Admin(){var u=Current();if(u.role!="admin")throw new Exception("Somente administradores podem realizar esta operação.");return u;}
  // Apenas ajustes de estoque sao liberados a operadores; cadastro, preco, custo e outras rotinas continuam administrativos.
  User StockEditor(){var u=Current();if(u.role!="admin"&&u.role!="operator")throw new Exception("Somente operadores e administradores podem ajustar estoque.");return u;}
  public User Owner(){var u=Current();if(!u.Owner)throw new Exception("Este painel é exclusivo da conta proprietária.");return u;}
  User Cashier(){var u=Current();if(u.role=="financial")throw new Exception("O perfil financeiro tem acesso de consulta e não pode operar o caixa.");return u;}
  User OwnRegister(){var u=Cashier();var r=OpenRaw();if(r==null)throw new Exception("Abra o caixa antes de vender.");if(u.role=="operator"&&r.userId!=u.id)throw new Exception("Você só pode operar seu próprio caixa aberto.");return u;}
  public User Login(string email,string password){if(remote!=null)remote.AssertAllowed();if(sessionId!=null)throw new Exception("Saia da conta atual antes de entrar em outra.");var rows=sql.Query("SELECT * FROM login_attempts WHERE singleton=1");long failures=rows.Count==0?0:(long)rows[0]["failures"],until=rows.Count==0?0:(long)rows[0]["blocked_until"],now=(long)(DateTime.UtcNow-new DateTime(1970,1,1)).TotalMilliseconds;if(until>now)throw new Exception("Muitas tentativas. Aguarde "+(int)Math.Ceiling((until-now)/1000.0)+" segundos.");
   var u=UserRecord("SELECT * FROM users WHERE email=?",(email??"").Trim().ToLowerInvariant());bool valid=Passwords.Verify(password,u??dummy);if(u==null||u.active!=1||!valid){failures++;until=failures>=5?now+Math.Min(600000,30000*(long)Math.Pow(2,Math.Min(5,failures-5))):0;sql.Exec("INSERT OR REPLACE INTO login_attempts VALUES(1,?,?)",failures,until);throw new Exception("E-mail ou senha inválidos, ou conta desativada.");}if(!u.Owner&&ControlRaw().blocked==1)throw new Exception("O acesso desta instalação foi suspenso. Entre em contato com o responsável.");sql.Exec("DELETE FROM login_attempts");sessionId=u.id;sessionVersion=u.credential_version;Audit("login","");return Current();
  }
  public void Logout(){sessionId=null;}
  void Audit(string action,string detail){
   var u=Current();
   sql.Exec("INSERT INTO access_audit(at,actor_id,actor_name,action,detail) VALUES(?,?,?,?,?)",D.Now(),u.id,u.name,action,detail);
  }
  public List<Dictionary<string,object>> AuditEntries(DateTime from,DateTime until,int offset=0){
   Admin();
   if(until<=from||offset<0)throw new ArgumentException("Confira o período da auditoria.");
   return sql.Query(@"SELECT a.at,COALESCE(a.actor_name,u.name,a.actor_id) AS actor,a.action,a.detail
    FROM access_audit a LEFT JOIN users u ON u.id=a.actor_id
    WHERE a.at>=? AND a.at<? ORDER BY a.at DESC,a.id DESC LIMIT 101 OFFSET ?",
    from.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ",System.Globalization.CultureInfo.InvariantCulture),
    until.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ",System.Globalization.CultureInfo.InvariantCulture),offset);
  }
  public List<User> Users(){Owner();return sql.Query("SELECT * FROM users ORDER BY is_owner DESC,created_at").Select(MapUser).Select(u=>{u.salt=null;u.password_hash=null;return u;}).ToList();}
  public List<Dictionary<string,object>> AuditList(){Owner();return sql.Query("SELECT at,action,detail FROM access_audit ORDER BY id DESC LIMIT 50");}
  static string Role(string r){if(!new[]{"admin","operator","financial"}.Contains(r))throw new Exception("Perfil inválido.");return r;}
  public void SaveUser(string id,string email,string name,string role,bool active,string password){Owner();name=D.Text(name,"o nome",60);Role(role);var old=string.IsNullOrEmpty(id)?null:UserRecord("SELECT * FROM users WHERE id=?",id);if(!string.IsNullOrEmpty(id)&&old==null)throw new Exception("Conta não encontrada.");if(old!=null&&old.Owner)throw new Exception("A conta proprietária é protegida.");if(old==null){email=(email??"").Trim().ToLowerInvariant();if(email.Length>254||!Regex.IsMatch(email,@"^[^\s@]+@[^\s@]+\.[^\s@]+$"))throw new Exception("Informe um e-mail válido.");if(sql.Scalar("SELECT id FROM users WHERE email=?",email)!=null)throw new Exception("Já existe uma conta com este e-mail.");}string salt=old==null?Passwords.Salt():old.salt,hash=old==null?null:old.password_hash;if(old==null||!string.IsNullOrEmpty(password)){Passwords.Validate(password);salt=Passwords.Salt();hash=Passwords.Hash(password,salt);}Owner();
   sql.Transaction(()=>{if(old==null)sql.Exec("INSERT INTO users(id,email,name,role,active,salt,password_hash,created_at) VALUES(?,?,?,?,?,?,?,?)",D.Id(),email,name,role,active?1:0,salt,hash,D.Now());else sql.Exec("UPDATE users SET name=?,role=?,active=?,salt=?,password_hash=?,credential_version=credential_version+1 WHERE id=?",name,role,active?1:0,salt,hash,id);Audit(old==null?"account.create":"account.update",old==null?email:old.email);});
  }
  public void ChangePassword(string current,string next){var u=Current();if(!Passwords.Verify(current,u))throw new Exception("A senha atual está incorreta.");Passwords.Validate(next);var salt=Passwords.Salt();var hash=Passwords.Hash(next,salt);Current();sql.Transaction(()=>{sql.Exec("UPDATE users SET salt=?,password_hash=?,credential_version=credential_version+1 WHERE id=?",salt,hash,u.id);sessionVersion++;Audit("password.change","");});}
  public void Block(bool blocked,string reason){Owner();if((reason??"").Length>200)throw new Exception("Motivo deve ter até 200 caracteres.");sql.Transaction(()=>{sql.Exec("UPDATE installation_control SET blocked=?,reason=?,changed_at=? WHERE singleton=1",blocked?1:0,(reason??"").Trim(),D.Now());Audit(blocked?"installation.block":"installation.unblock",reason??"");});}
  List<T> All<T>(string table){return sql.Query("SELECT payload FROM "+table+" ORDER BY position").Select(r=>J.Read<T>((string)r["payload"])).ToList();}
  public Dictionary<string,byte[]> ProductImages(){
   Current();return sql.Query("SELECT product_id,image FROM product_photos").ToDictionary(x=>(string)x["product_id"],x=>(byte[])x["image"]);
  }
  public byte[] ProductPhoto(string id){Admin();var value=sql.Scalar("SELECT image FROM product_photos WHERE product_id=?",id);return value==null?null:(byte[])value;}
  public List<Product> Products(){var u=Current();var p=All<Product>("products");if(u.role=="operator")foreach(var x in p)x.cost=0;return p;}
  Product ProductRaw(string id){var s=(string)sql.Scalar("SELECT payload FROM products WHERE id=?",id);if(s==null)throw new Exception("Produto não encontrado.");return J.Read<Product>(s);}
  Register OpenRaw(){var s=(string)sql.Scalar("SELECT payload FROM sessions WHERE json_extract(payload,'$.status')='open' LIMIT 1");return s==null?null:J.Read<Register>(s);}
  // Consulta somente leitura: usada no fechamento da janela mesmo apos logout.
  public bool HasOpenCash(){return OpenRaw()!=null;}
  public Register Open(){var u=Current();var r=OpenRaw();return u.role=="operator"&&r!=null&&r.userId!=u.id?null:r;}
  public bool Occupied(){var u=Current();var r=OpenRaw();return r!=null&&u.role=="operator"&&r.userId!=u.id;}
  public long NextNumber(){Current();return Convert.ToInt64(sql.Scalar("SELECT next_sale FROM metadata WHERE singleton=1"));}
  public Settings Shop(){Current();return J.Read<Settings>((string)sql.Scalar("SELECT settings FROM metadata WHERE singleton=1"));}
  public long Revision(){return Convert.ToInt64(sql.Scalar("SELECT revision FROM metadata WHERE singleton=1"));}
  void Mutation(Action a){sql.Transaction(()=>{Current();a();sql.Exec("UPDATE metadata SET revision=revision+1 WHERE singleton=1");});}
  void Update(string table,string id,object payload){sql.Exec("UPDATE "+table+" SET payload=? WHERE id=?",J.Write(payload),id);}
  void Insert(string table,string id,object payload){sql.Exec("INSERT INTO "+table+" VALUES(?,COALESCE((SELECT MIN(position)-1 FROM "+table+"),0),?)",id,J.Write(payload));}
  public void OpenCash(long opening){var u=Cashier();D.Int(opening,"Fundo de troco");Mutation(()=>{if(OpenRaw()!=null)throw new Exception("Já existe um caixa aberto.");var r=new Register{id=D.Id(),openedAt=D.Now(),operatorName=u.name,userId=u.id,opening=opening,status="open"};Insert("sessions",r.id,r);Audit("cash.open","Fundo de troco: "+D.Money(opening));});}
  public Totals SessionTotals(string id){var u=Current();var raw=(string)sql.Scalar("SELECT payload FROM sessions WHERE id=?",id);if(raw==null)throw new Exception("Caixa não encontrado.");var r=J.Read<Register>(raw);if(u.role=="operator"&&(r.status!="open"||r.userId!=u.id))throw new Exception("Você só pode consultar o seu caixa atualmente aberto.");return TotalsRaw(r);}
  Totals TotalsRaw(Register r){
   var t=new Totals{drawer=r.opening};
   var a=sql.Query("SELECT COUNT(*) AS count,COALESCE(SUM(json_extract(payload,'$.total')),0) AS revenue FROM sales WHERE json_extract(payload,'$.sessionId')=? AND json_extract(payload,'$.status')='paid'",r.id)[0];t.sales=(int)(long)a["count"];t.revenue=(long)a["revenue"];
   foreach(var p in sql.Query("SELECT json_extract(p.value,'$.method') AS method,SUM(json_extract(p.value,'$.amount')) AS amount FROM sales AS s,json_each(s.payload,'$.payments') AS p WHERE json_extract(s.payload,'$.sessionId')=? AND json_extract(s.payload,'$.status')='paid' GROUP BY method",r.id))t.payments[(string)p["method"]]=(long)p["amount"];
   foreach(var m in sql.Query("SELECT json_extract(payload,'$.type') AS kind,SUM(json_extract(payload,'$.amount')) AS amount FROM cash_moves WHERE json_extract(payload,'$.sessionId')=? GROUP BY kind",r.id)){if((string)m["kind"]=="supply")t.supplied=(long)m["amount"];else t.withdrawn=(long)m["amount"];}t.drawer+=t.payments["dinheiro"]+t.supplied-t.withdrawn;return t;
  }
  List<CashMove> CashRaw(string id){return sql.Query("SELECT payload FROM cash_moves WHERE json_extract(payload,'$.sessionId')=? ORDER BY position",id).Select(x=>J.Read<CashMove>((string)x["payload"])).ToList();}
  public List<CashMove> CashMoves(string id,int offset=0){SessionTotals(id);return sql.Query("SELECT payload FROM cash_moves WHERE json_extract(payload,'$.sessionId')=? ORDER BY position LIMIT 101 OFFSET ?",id,offset).Select(x=>J.Read<CashMove>((string)x["payload"])).ToList();}
  public List<Register> Registers(int offset=0){var u=Current();if(u.role=="operator"){var r=Open();return r==null?new List<Register>():new List<Register>{r};}return sql.Query("SELECT payload FROM sessions ORDER BY position LIMIT 101 OFFSET ?",offset).Select(x=>J.Read<Register>((string)x["payload"])).ToList();}
  public void MoveCash(string kind,long amount,string reason){OwnRegister();if(kind!="supply"&&kind!="withdrawal")throw new Exception("Movimentação inválida.");D.Int(amount,"Valor",1);reason=D.Text(reason,"o motivo");Mutation(()=>{OwnRegister();var r=OpenRaw();if(kind=="withdrawal"&&amount>TotalsRaw(r).drawer)throw new Exception("A sangria supera o dinheiro disponível no caixa.");var m=new CashMove{id=D.Id(),sessionId=r.id,at=D.Now(),type=kind,amount=amount,reason=reason};Insert("cash_moves",m.id,m);Audit(kind=="supply"?"cash.supply":"cash.withdrawal",D.Money(amount)+" • "+reason);});}
  public void CloseCash(Dictionary<string,long> counted){OwnRegister();foreach(var m in D.Methods){if(!counted.ContainsKey(m))throw new Exception("Contagem inválida.");D.Int(counted[m],"Contagem");}Mutation(()=>{OwnRegister();var r=OpenRaw();var t=TotalsRaw(r);r.expected=t.payments;r.expected["dinheiro"]=t.drawer;r.counted=counted;r.difference=counted["dinheiro"]-t.drawer;r.closedAt=D.Now();r.status="closed";Update("sessions",r.id,r);Audit("cash.close","Dinheiro contado: "+D.Money(counted["dinheiro"])+" • Diferença: "+D.Money(r.difference));});}
  public Draft GetDraft(){var u=Current();if(u.role=="financial")return new Draft();var raw=(string)sql.Scalar("SELECT payload FROM user_drafts WHERE user_id=?",u.id);return raw==null?new Draft():J.Read<Draft>(raw);}
  public void SetDraft(Draft d){WriteDraft(Cashier().id,d);}
  void WriteDraft(string userId,Draft d){if(d==null||d.cart==null||d.cart.Count>10000||d.discount==null||d.discount.Length>50||d.note==null||d.note.Length>200)throw new Exception("Venda em andamento inválida.");var seen=new HashSet<string>();foreach(var l in d.cart){if(string.IsNullOrEmpty(l.productId)||!seen.Add(l.productId)||l.quantity<=0||l.quantity>1000000000)throw new Exception("Item inválido.");}sql.Exec("INSERT INTO user_drafts VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET payload=excluded.payload",userId,J.Write(d));}
  internal void PreserveDraftOnRemoteLock(Draft d){
   if(remote==null||!remote.Denied)throw new Exception("Preservação restrita à suspensão remota.");
   var u=sessionId==null?null:UserRecord("SELECT * FROM users WHERE id=?",sessionId);
   if(u==null||u.active!=1||u.credential_version!=sessionVersion||u.role=="financial")throw new Exception("Não há pedido de operador autenticado para preservar.");
   WriteDraft(u.id,d); // Only saves the current private draft, never a sale or cash movement.
  }
  public bool HasDrafts(){return sql.Query("SELECT payload FROM user_drafts").Any(x=>J.Read<Draft>((string)x["payload"]).cart.Count>0);}
  public Sale Finish(List<Line> lines,long discount,List<Payment> payments,long received,string note){var u=OwnRegister();note=note??"";if(note.Length>200)throw new Exception("Observação deve ter até 200 caracteres.");Sale result=null;Mutation(()=>{OwnRegister();var r=OpenRaw();if(lines.Count==0)throw new Exception("Adicione um produto à venda.");var products=lines.Select(l=>ProductRaw(l.productId)).ToList();var c=D.Calculate(products,lines,discount);if(c.total<=0)throw new Exception("A venda deve ter um total maior que zero.");var methods=new HashSet<string>();foreach(var p in payments){if(!D.Methods.Contains(p.method)||!methods.Add(p.method))throw new Exception("Forma de pagamento inválida ou repetida.");D.Int(p.amount,"Pagamento",1);}if(payments.Sum(p=>p.amount)!=c.total)throw new Exception("A soma dos pagamentos deve ser igual ao total.");D.Int(received,"Dinheiro recebido");long cash=payments.Where(p=>p.method=="dinheiro").Sum(p=>p.amount);if(received<cash)throw new Exception("Dinheiro recebido insuficiente.");if(cash==0&&received!=0)throw new Exception("Dinheiro recebido requer pagamento em dinheiro.");
    result=new Sale{id=D.Id(),sessionId=r.id,at=D.Now(),number=Convert.ToInt64(sql.Scalar("SELECT next_sale FROM metadata WHERE singleton=1")),operatorName=u.name,userId=u.id,items=c.items,subtotal=c.subtotal,discount=discount,total=c.total,payments=payments,cashReceived=received,change=received-cash,note=note.Trim(),status="paid"};Insert("sales",result.id,result);foreach(var i in c.items){var p=products.Find(x=>x.id==i.productId);p.stock-=i.quantity;Update("products",p.id,p);var m=new StockMove{id=D.Id(),productId=p.id,at=result.at,quantity=-i.quantity,unit=p.unit,reason="Venda #"+result.number,saleId=result.id};Insert("stock_moves",m.id,m);}sql.Exec("UPDATE metadata SET next_sale=next_sale+1 WHERE singleton=1");sql.Exec("DELETE FROM user_drafts WHERE user_id=?",u.id);
    Audit("sale.finish","#"+result.number+" • "+D.Money(result.total)+" • "+result.items.Count+" linhas");
   });return result;}
  public void Cancel(string id,string reason,string authorizationPassword){if(!CancellationAuthorization.Verify(authorizationPassword))throw new Exception("Senha de autorização inválida para cancelar a venda.");var u=OwnRegister();reason=D.Text(reason,"o motivo do cancelamento");Mutation(()=>{OwnRegister();var raw=(string)sql.Scalar("SELECT payload FROM sales WHERE id=?",id);var v=raw==null?null:J.Read<Sale>(raw);var r=OpenRaw();if(v==null||v.status!="paid")throw new Exception("Venda inexistente ou já cancelada.");if(v.sessionId!=r.id)throw new Exception("Só é possível cancelar vendas do caixa atualmente aberto.");if(u.role=="operator"&&v.userId!=u.id)throw new Exception("Você só pode cancelar suas próprias vendas.");if(TotalsRaw(r).drawer<v.payments.Where(p=>p.method=="dinheiro").Sum(p=>p.amount))throw new Exception("Dinheiro insuficiente para devolver esta venda. Registre um suprimento.");v.status="cancelled";v.cancelledAt=D.Now();v.cancelReason=reason;Update("sales",id,v);foreach(var i in v.items){var p=ProductRaw(i.productId);if(p.unit!=i.unit)throw new Exception("Unidade do produto mudou desde a venda. Não é possível estornar o estoque automaticamente.");p.stock+=i.quantity;D.Int(p.stock,"Estoque");Update("products",p.id,p);var m=new StockMove{id=D.Id(),productId=p.id,at=v.cancelledAt,quantity=i.quantity,unit=p.unit,reason="Cancelamento #"+v.number,saleId=v.id};Insert("stock_moves",m.id,m);}Audit("sale.cancel","#"+v.number+" • "+D.Money(v.total)+" • "+reason);});}
  public List<Sale> Sales(DateTime start,DateTime end,int offset=0,int limit=101){var u=Current();string where="json_extract(payload,'$.at')>=? AND json_extract(payload,'$.at')<?";var args=new List<object>{start.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),end.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ")};if(u.role=="operator"){var r=Open();if(r==null)return new List<Sale>();where+=" AND json_extract(payload,'$.sessionId')=?";args.Add(r.id);}args.Add(limit);args.Add(offset);var rows=sql.Query("SELECT payload FROM sales WHERE "+where+" ORDER BY position LIMIT ? OFFSET ?",args.ToArray()).Select(x=>J.Read<Sale>((string)x["payload"])).ToList();if(u.role=="operator")foreach(var v in rows)foreach(var i in v.items)i.cost=0;return rows;}
  public IEnumerable<Sale> Report(DateTime start,DateTime end){ // Stream batches; callers aggregate, never keep the full history on the screen.
   int offset=0;while(true){var rows=Sales(start,end,offset,500);foreach(var v in rows)yield return v;if(rows.Count<500)yield break;offset+=500;}
  }
  public void SaveProduct(Product p,byte[] customPhoto=null,bool removePhoto=false){Admin();
   if(customPhoto!=null&&removePhoto)throw new Exception("Escolha adicionar ou remover a foto.");
   if(customPhoto!=null&&!ProductPhotos.IsJpeg(customPhoto))throw new Exception("A foto enviada não é um JPEG válido ou ultrapassa 256 KB.");
   p.name=D.Text(p.name,"o nome",100);p.code=D.Text(p.code,"o código",60);p.category=D.Text(p.category,"a categoria",60);
   if(p.unit!="un"&&p.unit!="kg")throw new Exception("Unidade inválida.");
   D.Int(p.price,"Preço",1);D.Int(p.cost,"Custo");D.Int(p.stock,"Estoque");D.Int(p.minStock,"Estoque mínimo");
   Mutation(()=>{
    var all=All<Product>("products");var old=all.Find(x=>x.id==p.id);
    if(all.Any(x=>string.Equals(x.code,p.code,StringComparison.OrdinalIgnoreCase)&&x.id!=p.id))throw new Exception("Já existe um produto com esse código.");
    bool changed=old!=null&&old.unit!=p.unit;
    if(changed){
     // Do not reinterpret a kg cart draft as a per-piece sale (or vice versa).
     foreach(var row in sql.Query("SELECT payload FROM user_drafts")){
      var draft=J.Read<Draft>((string)row["payload"]);
      if(draft!=null&&draft.cart!=null&&draft.cart.Any(line=>line.productId==p.id))
       throw new Exception("Este produto está em uma venda não concluída. Remova-o do carrinho antes de trocar a unidade.");
     }
     // A paid sale in an OPEN register can still be cancelled. Keep its unit compatible.
     var openRegisterIds=new HashSet<string>(sql.Query("SELECT id FROM sessions WHERE json_extract(payload,'$.status')='open'").Select(row=>(string)row["id"]));
     if(openRegisterIds.Count>0){
      var openSales=sql.Query("SELECT payload FROM sales WHERE json_extract(payload,'$.status')='paid' AND json_extract(payload,'$.sessionId') IN (SELECT id FROM sessions WHERE json_extract(payload,'$.status')='open')");
      foreach(var row in openSales){var sale=J.Read<Sale>((string)row["payload"]);
       if(openRegisterIds.Contains(sale.sessionId)&&sale.items.Any(item=>item.productId==p.id))
        throw new Exception("Este produto possui vendas no caixa aberto. Feche o caixa antes de trocar a unidade, para preservar os estornos.");
      }
     }
     // Old historical movements had no unit snapshot. Annotate them before the change.
     var previousMoves=sql.Query("SELECT id,payload FROM stock_moves WHERE json_extract(payload,'$.productId')=?",p.id);
     foreach(var row in previousMoves){var move=J.Read<StockMove>((string)row["payload"]);
      if(string.IsNullOrEmpty(move.unit)){move.unit=old.unit;Update("stock_moves",move.id,move);}
     }
     // A unit conversion is not automatic: quantity must be supplied in the NEW unit.
     string now=D.Now();
     var leaving=new StockMove{id=D.Id(),productId=p.id,at=now,unit=old.unit,quantity=-old.stock,reason="Troca de unidade: saldo anterior ("+old.unit+")"};Insert("stock_moves",leaving.id,leaving);
     var entering=new StockMove{id=D.Id(),productId=p.id,at=now,unit=p.unit,quantity=p.stock,reason="Troca de unidade: novo saldo informado ("+p.unit+")"};Insert("stock_moves",entering.id,entering);
    }else if(old!=null)p.stock=old.stock;
    if(p.unit=="un"&&(p.stock%1000!=0||p.minStock%1000!=0))throw new Exception("Estoque por unidade deve ser inteiro.");
    p.icon=p.icon??"bread";
    if(old==null){p.id=D.Id();Insert("products",p.id,p);if(p.stock!=0){var m=new StockMove{id=D.Id(),productId=p.id,at=D.Now(),quantity=p.stock,unit=p.unit,reason="Estoque inicial"};Insert("stock_moves",m.id,m);}}
    else Update("products",p.id,p);
    if(removePhoto)sql.Exec("DELETE FROM product_photos WHERE product_id=?",p.id);
    else if(customPhoto!=null)sql.Exec("INSERT OR REPLACE INTO product_photos(product_id,image) VALUES(?,?)",p.id,customPhoto);
    var details=new List<string>();
    if(old==null){
     details.Add("Preço: "+D.Money(p.price)+" / "+p.unit);
     details.Add("Estoque inicial: "+D.Qty(p.stock,p.unit)+" "+p.unit);
    }else{
     AuditChange(details,"Nome",old.name,p.name);
     AuditChange(details,"Código",old.code,p.code);
     AuditChange(details,"Categoria",old.category,p.category);
     AuditChange(details,"Unidade",old.unit,p.unit);
     AuditChange(details,"Preço",D.Money(old.price),D.Money(p.price));
     AuditChange(details,"Custo",D.Money(old.cost),D.Money(p.cost));
     AuditChange(details,"Estoque",D.Qty(old.stock,old.unit)+" "+old.unit,D.Qty(p.stock,p.unit)+" "+p.unit);
     AuditChange(details,"Estoque mínimo",D.Qty(old.minStock,old.unit)+" "+old.unit,D.Qty(p.minStock,p.unit)+" "+p.unit);
     AuditChange(details,"Situação",old.active?"Ativo":"Inativo",p.active?"Ativo":"Inativo");
    }
    if(removePhoto)details.Add("Foto personalizada removida");
    else if(customPhoto!=null)details.Add("Foto personalizada salva");
    if(details.Count>0)Audit(old==null?"product.create":"product.update",p.code+" • "+p.name+" • "+string.Join(" • ",details));
   });}
  static void AuditChange(List<string> details,string label,string before,string after){
   if(before!=after)details.Add(label+": "+before+" → "+after);
  }
  // Adiciona somente produtos demonstrativos ausentes; não altera preços,
  // estoques ou códigos de produtos já cadastrados pelo estabelecimento.
  public int ImportExampleProducts(){
   Admin();
   var samples=J.Read<List<Product>>(Resource("catalog-extras.json"));
   int added=0;
   Mutation(()=>{
    var existing=All<Product>("products");
    var codes=new HashSet<string>(existing.Select(x=>x.code),StringComparer.OrdinalIgnoreCase);
    var names=new HashSet<string>(existing.Select(x=>x.name),StringComparer.CurrentCultureIgnoreCase);
    foreach(var template in samples){
     if(codes.Contains(template.code)||names.Contains(template.name))continue;
     var p=new Product{id=D.Id(),name=template.name,code=template.code,category=template.category,
      unit="un",price=template.price,cost=0,stock=0,minStock=0,active=true,
      icon=template.icon,photoKey=template.photoKey};
     Insert("products",p.id,p);
     codes.Add(p.code);names.Add(p.name);added++;
    }
    if(added>0)Audit("catalog.examples",added+" produtos de exemplo adicionados");
   });
   return added;
  }
  // Importacao comercial solicitada pelo proprietario em 05/11/2026.
  // A chamada acontece na inicializacao (antes do login), depois de abrir o banco e
  // de gerar um backup. Somente precos de produtos com mesmo nome E mesma unidade
  // sao atualizados; nunca converte peso em pecas ou inventa estoque/custo.
  public int ApplyClientCatalogOnce(){
   sql.Exec("CREATE TABLE IF NOT EXISTS client_catalog_imports (migration_key TEXT PRIMARY KEY, applied_at TEXT NOT NULL, added INTEGER NOT NULL, updated INTEGER NOT NULL)");
   if(sql.Scalar("SELECT migration_key FROM client_catalog_imports WHERE migration_key=?",ClientCatalog.MigrationKey)!=null)return 0;
   // Mantem uma copia anterior independente do backup diario ou da atualizacao.
   Backup("antes-catalogo-cliente");
   int added=0,updated=0;
   sql.Transaction(()=>{
    if(sql.Scalar("SELECT migration_key FROM client_catalog_imports WHERE migration_key=?",ClientCatalog.MigrationKey)!=null)return;
    var existing=All<Product>("products");
    var codes=new HashSet<string>(existing.Select(x=>x.code),StringComparer.OrdinalIgnoreCase);
    for(int i=0;i<ClientCatalog.Items.Length;i++){
     var item=ClientCatalog.Items[i];
     // Mesmo nome, mas unidades diferentes: preservar produto antigo e historico.
     string name=item.Name;
     var candidates=existing.Where(x=>string.Equals(x.name,name,StringComparison.CurrentCultureIgnoreCase)).ToList();
     if(candidates.Count>0&&!candidates.Any(x=>x.unit==item.Unit))
      name += item.Unit=="un"?" (unidade)":" (por kg)";
     var match=existing.FirstOrDefault(x=>x.unit==item.Unit&&string.Equals(x.name,name,StringComparison.CurrentCultureIgnoreCase));
     if(match!=null){
      if(match.price!=item.Price){match.price=item.Price;Update("products",match.id,match);updated++;}
      continue;
     }
     string code="PXC-C2611-"+(i+1).ToString("000");
     // Respeitar codigos manuais eventualmente usados pelo estabelecimento.
     if(codes.Contains(code)){
      int suffixNumber=2;while(codes.Contains(code+"-"+suffixNumber))suffixNumber++;
      code=code+"-"+suffixNumber;
     }
     var created=new Product{id=D.Id(),name=name,code=code,category=item.Category,
      unit=item.Unit,price=item.Price,cost=0,stock=0,minStock=0,active=true,icon=item.Icon};
     Insert("products",created.id,created);
     existing.Add(created);codes.Add(code);added++;
    }
    sql.Exec("INSERT INTO client_catalog_imports(migration_key,applied_at,added,updated) VALUES(?,?,?,?)",
      ClientCatalog.MigrationKey,D.Now(),added,updated);
    sql.Exec("UPDATE metadata SET revision=revision+1 WHERE singleton=1");
   });
   return added;
  }
  // Incremento seguro para instalações que JA fizeram a limpeza de testes na 2.0.32.
  // Não toca nos outros clientes no mesmo canal, nem altera vendas, preços existentes,
  // estoque, custos ou fotos. Roda uma vez e somente quando o reset anterior existir.
  public int AppendClientCatalogExtrasAfterReset(){
   if(sql.Scalar("SELECT name FROM sqlite_master WHERE type='table' AND name='client_data_resets'")==null)return 0;
   if(sql.Scalar("SELECT migration_key FROM client_data_resets WHERE migration_key=?",ClientResetKey)==null)return 0;
   sql.Exec("CREATE TABLE IF NOT EXISTS client_catalog_imports (migration_key TEXT PRIMARY KEY,applied_at TEXT NOT NULL,added INTEGER NOT NULL,updated INTEGER NOT NULL)");
   if(sql.Scalar("SELECT migration_key FROM client_catalog_imports WHERE migration_key=?",ClientCatalog.ExtrasMigrationKey)!=null)return 0;
   // Backup completo ANTES de qualquer alteração: falha de backup cancela a importação.
   Backup("antes-produtos-adicionais");
   int added=0;
   sql.Transaction(()=>{
    if(sql.Scalar("SELECT migration_key FROM client_catalog_imports WHERE migration_key=?",ClientCatalog.ExtrasMigrationKey)!=null)return;
    var existing=All<Product>("products");
    var codes=new HashSet<string>(existing.Select(x=>x.code),StringComparer.OrdinalIgnoreCase);
    for(int i=ClientCatalog.PreviousCatalogCount;i<ClientCatalog.Items.Length;i++){
     var item=ClientCatalog.Items[i];
     // Nome encontrado: não sobrescrever o que o estabelecimento já personalizou.
     if(existing.Any(x=>string.Equals(x.name,item.Name,StringComparison.CurrentCultureIgnoreCase)))continue;
     string code="PXC-C2611-"+(i+1).ToString("000");
     if(codes.Contains(code)){
      int suffix=2;while(codes.Contains(code+"-"+suffix))suffix++;
      code+="-"+suffix;
     }
     var product=new Product{id=D.Id(),name=item.Name,code=code,category=item.Category,
      unit=item.Unit,price=item.Price,cost=0,stock=0,minStock=0,active=true,icon=item.Icon};
     Insert("products",product.id,product);existing.Add(product);codes.Add(code);added++;
    }
    sql.Exec("INSERT INTO client_catalog_imports(migration_key,applied_at,added,updated) VALUES(?,?,?,0)",
     ClientCatalog.ExtrasMigrationKey,D.Now(),added);
    sql.Exec("UPDATE metadata SET revision=revision+1 WHERE singleton=1");
    D.Validate(LoadRaw());
   });
   return added;
  }
  // Limpeza explicita de uma BASE DE TESTES, confirmada por um administrador no proprio PC.
  // Nunca disparar no inicio ou pela atualizacao compartilhada do GitHub: outras lojas
  // podem utilizar o mesmo canal. Backup antes, transacao atomica e marcador de uso unico.
  const string ClientResetKey="cliente-2026-11-05-base-limpa-v1";
  public bool ClientResetApplied(){
   Admin();
   sql.Exec("CREATE TABLE IF NOT EXISTS client_data_resets (migration_key TEXT PRIMARY KEY,applied_at TEXT NOT NULL,product_count INTEGER NOT NULL)");
   return sql.Scalar("SELECT migration_key FROM client_data_resets WHERE migration_key=?",ClientResetKey)!=null;
  }
  public string ResetDemoDataAndInstallClientCatalog(){
   Admin();
   if(ClientResetApplied())throw new Exception("Este catálogo já foi instalado. Os dados novos não serão apagados novamente.");
   // Se o backup falhar, NENHUM dado sera modificado.
   string backup=Backup("antes-limpar-testes");
   sql.Transaction(()=>{
    Admin();
    if(sql.Scalar("SELECT migration_key FROM client_data_resets WHERE migration_key=?",ClientResetKey)!=null)
     throw new Exception("A limpeza já foi executada nesta instalação.");
    // Remove tudo que pertence aos testes comerciais, inclusive pedidos nao concluídos,
    // sessoes, caixa aberto, pagamentos, movimentos e imagens antigas. Contas, senhas,
    // configuracoes da loja e controle remoto sao preservados.
    foreach(string table in new[]{"product_photos","stock_moves","cash_moves","sales","sessions","products","user_drafts","draft"})
     sql.Exec("DELETE FROM "+table);
    sql.Exec("INSERT INTO draft(singleton,payload) VALUES(1,?)",J.Write(new Draft()));
    for(int i=0;i<ClientCatalog.Items.Length;i++){
     var item=ClientCatalog.Items[i];
     var product=new Product{id=D.Id(),name=item.Name,code="PXC-C2611-"+(i+1).ToString("000"),
      category=item.Category,unit=item.Unit,price=item.Price,cost=0,stock=0,minStock=0,
      active=true,icon=item.Icon};
     Insert("products",product.id,product);
    }
    // Zera numeracao financeira junto do historico removido.
    sql.Exec("UPDATE metadata SET next_sale=1,revision=revision+1 WHERE singleton=1");
    // Impede que um downgrade para 2.0.31 reimporte a lista por cima.
    sql.Exec("CREATE TABLE IF NOT EXISTS client_catalog_imports (migration_key TEXT PRIMARY KEY,applied_at TEXT NOT NULL,added INTEGER NOT NULL,updated INTEGER NOT NULL)");
    sql.Exec("INSERT OR IGNORE INTO client_catalog_imports(migration_key,applied_at,added,updated) VALUES(?,?,?,?)",
     ClientCatalog.MigrationKey,D.Now(),ClientCatalog.Items.Length,0);
    // A base limpa já contém também as 24 novidades: dispensar nova importação.
    sql.Exec("INSERT OR IGNORE INTO client_catalog_imports(migration_key,applied_at,added,updated) VALUES(?,?,?,0)",
     ClientCatalog.ExtrasMigrationKey,D.Now(),ClientCatalog.Items.Length-ClientCatalog.PreviousCatalogCount);
    sql.Exec("DELETE FROM access_audit");
    Audit("catalog.cleanstart","Base comercial de testes zerada; "+ClientCatalog.Items.Length+" produtos importados. Backup: "+Path.GetFileName(backup));
    sql.Exec("INSERT INTO client_data_resets(migration_key,applied_at,product_count) VALUES(?,?,?)",
     ClientResetKey,D.Now(),ClientCatalog.Items.Length);
    D.Validate(LoadRaw());
   });
   return backup;
  }
  public void AdjustStock(string id,long q,string reason=null){var editor=StockEditor();
   if(q==0||q < -1000000000||q>1000000000)throw new Exception("Informe uma quantidade válida.");
   reason=string.IsNullOrWhiteSpace(reason)?(q>0?"Entrada de estoque":"Saída de estoque"):D.Text(reason,"o motivo");
   Mutation(()=>{
    StockEditor();
    var p=ProductRaw(id);
    if(p.unit=="un"&&q%1000!=0)throw new Exception("Quantidade por unidade deve ser inteira.");
    long previous=p.stock;
    p.stock+=q;D.Int(p.stock,"Estoque");Update("products",id,p);
    var m=new StockMove{id=D.Id(),productId=id,at=D.Now(),quantity=q,unit=p.unit,reason=reason+" (por "+editor.name+")"};
    Insert("stock_moves",m.id,m);
    Audit("stock.adjust",p.code+" • "+p.name+" • "+(q>0?"+":"")+D.Qty(q,p.unit)+" "+p.unit+
     " • Saldo: "+D.Qty(previous,p.unit)+" → "+D.Qty(p.stock,p.unit)+" "+p.unit+" • "+reason);
   });
  }
  public List<StockMove> StockHistory(string id,int offset=0){Admin();return sql.Query("SELECT payload FROM stock_moves WHERE json_extract(payload,'$.productId')=? ORDER BY position LIMIT 101 OFFSET ?",id,offset).Select(x=>J.Read<StockMove>((string)x["payload"])).ToList();}
  public void SaveSettings(Settings s){Admin();s.name=D.Text(s.name,"o nome da padaria",100);s.@operator=D.Text(s.@operator,"o operador",60);if(s.footer==null||s.footer.Length>200)throw new Exception("Rodapé inválido.");Mutation(()=>{
   var before=Shop();
   sql.Exec("UPDATE metadata SET settings=? WHERE singleton=1",J.Write(s));
   var details=new List<string>();
   AuditChange(details,"Nome da padaria",before.name,s.name);
   AuditChange(details,"Operador da loja",before.@operator,s.@operator);
   if(before.footer!=s.footer)details.Add("Rodapé do comprovante alterado");
   if(details.Count>0)Audit("settings.update",string.Join(" • ",details));
  });}
  State LoadRaw(){var m=sql.Query("SELECT * FROM metadata WHERE singleton=1");if(m.Count==0)throw new Exception("Banco incompleto. Restaure um backup.");return new State{revision=(long)m[0]["revision"],nextSale=(long)m[0]["next_sale"],settings=J.Read<Settings>((string)m[0]["settings"]),products=All<Product>("products"),sales=All<Sale>("sales"),sessions=All<Register>("sessions"),cashMoves=All<CashMove>("cash_moves"),stockMoves=All<StockMove>("stock_moves"),productPhotos=sql.Query("SELECT product_id,image FROM product_photos").ToDictionary(x=>(string)x["product_id"],x=>Convert.ToBase64String((byte[])x["image"]))};}
  public State Export(){Admin();return LoadRaw();}
  void WriteState(State s){sql.Exec("INSERT OR REPLACE INTO metadata VALUES(1,?,?,?)",s.revision,s.nextSale,J.Write(s.settings));foreach(var t in Tables)sql.Exec("DELETE FROM "+t);WriteRows("products",s.products.Select(p=>new KeyValuePair<string,object>(p.id,p)));WriteRows("sales",s.sales.Select(p=>new KeyValuePair<string,object>(p.id,p)));WriteRows("sessions",s.sessions.Select(p=>new KeyValuePair<string,object>(p.id,p)));WriteRows("cash_moves",s.cashMoves.Select(p=>new KeyValuePair<string,object>(p.id,p)));WriteRows("stock_moves",s.stockMoves.Select(p=>new KeyValuePair<string,object>(p.id,p)));}
  void WriteRows(string table,IEnumerable<KeyValuePair<string,object>> rows){long i=0;foreach(var r in rows)sql.Exec("INSERT INTO "+table+" VALUES(?,?,?)",r.Key,i++,J.Write(r.Value));}
  public void Restore(State incoming,long expected){var u=Admin();D.Validate(incoming);if(Revision()!=expected)throw new Exception("Os dados mudaram. Confira e tente novamente.");Backup("antes-restauracao");sql.Transaction(()=>{if(Revision()!=expected)throw new Exception("Os dados mudaram.");incoming.revision=expected+1;foreach(var r in incoming.sessions)r.userId=r.status=="open"?u.id:null;foreach(var v in incoming.sales)v.userId=null;WriteState(incoming);
    sql.Exec("DELETE FROM product_photos");
    if(incoming.productPhotos!=null)foreach(var image in incoming.productPhotos)sql.Exec("INSERT INTO product_photos(product_id,image) VALUES(?,?)",image.Key,Convert.FromBase64String(image.Value));
    sql.Exec("DELETE FROM user_drafts");sql.Exec("DELETE FROM draft");Audit("restore","");});}
  public string Backup(string reason="manual"){if(!Regex.IsMatch(reason,"^[a-z-]+$"))throw new Exception("Nome inválido.");string path=Path.Combine(Backups,DateTime.UtcNow.ToString("yyyy-MM-ddTHH-mm-ss-fff")+"-"+reason+"-"+D.Id().Substring(0,8)+".sqlite");sql.Exec("VACUUM INTO ?",path);return path;}
  public void DailyBackup(){string day=DateTime.UtcNow.ToString("yyyy-MM-dd");if(!Directory.GetFiles(Backups,day+"*-diario-*.sqlite").Any())Backup("diario");foreach(var p in Directory.GetFiles(Backups,"*-diario-*.sqlite").OrderByDescending(x=>x).Skip(30))File.Delete(p);}
  string UpdateBlockReason(){if(OpenRaw()!=null)return "Feche e confira o caixa antes de instalar a atualização.";if(HasDrafts())return "Conclua ou limpe todas as vendas em andamento antes de atualizar.";return null;}
  public string PrepareInstall(){Admin();string reason=UpdateBlockReason();if(reason!=null)throw new Exception(reason);return Backup("antes-atualizacao");}
  internal string StartupUpdateBlockReason(){return UpdateBlockReason();}
  internal string PrepareStartupInstall(){if(sessionId!=null)throw new Exception("A atualização automática só instala antes de entrar na conta.");string reason=UpdateBlockReason();if(reason!=null)throw new Exception(reason);return Backup("antes-atualizacao");}
  public void Dispose(){sql.Dispose();}
 }
}
