﻿"""Check the warm red/yellow theme and consistent release metadata.

Source-only validation; Windows Forms rendering and C# compilation are checked in CI.
"""
from pathlib import Path
import json
import re

root=Path(__file__).resolve().parents[1]
ui=(root/'src/Ui.cs').read_text(encoding='utf-8-sig')
visual=(root/'src/VisualControls.cs').read_text(encoding='utf-8-sig')
for key in ('Bg','Card','Side','Ink','Muted','Line','Soft','Accent','AccentHover','Gold'):
    assert f'Color {key}' in ui, f'missing palette color: {key}'
assert 'Color Accent=Color.FromArgb(159,29,42)' in ui
assert 'Color.FromArgb(246,198,91)' in ui
assert 'Color.FromArgb(139,75,10)' in ui
assert 'Ui.Gold' in visual and 'Ui.Accent' in visual
assert 'Ui.Green' not in ''.join(f.read_text(encoding='utf-8-sig') for f in (root/'src').glob('*.cs'))

version=json.loads((root/'version.json').read_text(encoding='utf-8'))['version']
assert version=='2.0.35'
assert f'Version="{version}"' in (root/'src/Updates.cs').read_text(encoding='utf-8-sig')
assert f'{version}.0' in (root/'src/Program.cs').read_text(encoding='utf-8-sig')
assert f'!define VERSION "{version}"' in (root/'installer.nsi').read_text(encoding='utf-8-sig')
assert f'{version}.0' in (root/'resources/app.manifest').read_text(encoding='utf-8-sig')

def contrast(fore,back):
    def luminance(rgb):
        v=[x/255 for x in rgb]
        v=[x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4 for x in v]
        return sum(a*b for a,b in zip(v,(.2126,.7152,.0722)))
    a,b=sorted([luminance(fore),luminance(back)])
    return (b+.05)/(a+.05)

for name,fg,bg in [
    ('red button', (255,255,255),(159,29,42)),
    ('red hover dark', (255,255,255),(189,42,56)),
    ('dark gold', (246,198,91),(43,33,30)),
    ('light gold', (139,75,10),(255,255,255)),
    ('dark muted', (200,179,164),(43,33,30)),
    ('light muted', (118,94,80),(255,255,255)),
]:
    assert contrast(fg,bg)>=4.5, f'{name} low contrast'
print('PASS: red/yellow theme, metadata and contrast')
