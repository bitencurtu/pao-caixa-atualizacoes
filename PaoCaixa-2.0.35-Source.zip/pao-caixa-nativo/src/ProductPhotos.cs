﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Reflection;

namespace PaoCaixa {
 // Uma única imagem de catálogo embutida no EXE, sem acesso a rede e
 // sem carregar 46 bitmaps separados na memória dos computadores fracos.
 public static class ProductPhotos {
  const int Columns=8,TileWidth=180,TileHeight=126;
  static readonly Dictionary<string,int> Slots=BuildSlots();
  static readonly Dictionary<string,string> ExistingNames=new Dictionary<string,string>(StringComparer.CurrentCultureIgnoreCase){
   {"Pão francês","seed-01"},{"Pão de queijo","seed-02"},{"Croissant tradicional","seed-03"},
   {"Pão na chapa","seed-04"},{"Café espresso","seed-05"},{"Café com leite","seed-06"},
   {"Coxinha de frango","seed-07"},{"Bolo de cenoura","seed-08"},{"Sonho de creme","seed-09"},
   {"Suco de laranja","seed-10"},{"Misto quente","seed-11"},{"Água mineral 500 ml","seed-12"},
   {"Baguete artesanal","seed-13"},{"Cookie de chocolate","seed-14"},
   {"Empada de frango","seed-15"},{"Pão integral","seed-16"}
  };
  static readonly Dictionary<string,string> ClientNames=BuildClientNames();
  static readonly object Sync=new object();
  public const int MaxPhotoBytes=256*1024;
  static Image atlas;
  static bool attempted;
  static readonly Dictionary<string,byte[]> Custom=new Dictionary<string,byte[]>(StringComparer.OrdinalIgnoreCase);
  // Maximum 40 decoded thumbnails; JPEGs remain compressed in memory.
  static readonly Dictionary<string,Bitmap> Cache=new Dictionary<string,Bitmap>(StringComparer.OrdinalIgnoreCase);
  static readonly LinkedList<string> Recent=new LinkedList<string>();
  public static void SetCustomPhotos(IDictionary<string,byte[]> photos){
   lock(Sync){
    foreach(var img in Cache.Values)img.Dispose();Cache.Clear();Recent.Clear();Custom.Clear();
    if(photos!=null)foreach(var item in photos)if(IsJpeg(item.Value))Custom[item.Key]=item.Value;
   }
  }
  public static bool IsJpeg(byte[] image){
   return image!=null&&image.Length>=4&&image.Length<=MaxPhotoBytes&&image[0]==255&&image[1]==216&&image[image.Length-2]==255&&image[image.Length-1]==217;
  }
  // Resize/crop to a single, small offline photo with consistent 10:7 card ratio.
  public static byte[] PreparePhoto(string file){
   if(new FileInfo(file).Length>15L*1024*1024)throw new Exception("Escolha uma imagem de até 15 MB.");
   using(var original=Image.FromFile(file)){
    if(original.Width<1||original.Height<1||(long)original.Width*original.Height>30000000L)throw new Exception("Resolução da foto inválida ou muito grande.");
    using(var scaled=new Bitmap(360,252))
    using(var g=Graphics.FromImage(scaled)){
     g.Clear(Color.White);
     g.InterpolationMode=InterpolationMode.HighQualityBicubic;
     g.CompositingQuality=CompositingQuality.HighQuality;
     g.SmoothingMode=SmoothingMode.HighQuality;
     float ratio=Math.Max(360f/original.Width,252f/original.Height);
     float w=original.Width*ratio,h=original.Height*ratio;
     g.DrawImage(original,new RectangleF((360-w)/2,(252-h)/2,w,h));
     var encoder=ImageCodecInfo.GetImageEncoders().First(x=>x.FormatID==ImageFormat.Jpeg.Guid);
     using(var stream=new MemoryStream())using(var args=new EncoderParameters(1)){
      args.Param[0]=new EncoderParameter(System.Drawing.Imaging.Encoder.Quality,80L);
      scaled.Save(stream,encoder,args);
      var bytes=stream.ToArray();
      if(!IsJpeg(bytes))throw new Exception("Não foi possível compactar a foto em até 256 KB.");
      return bytes;
     }
    }
   }
  }
  public static Bitmap Preview(byte[] bytes){
   if(!IsJpeg(bytes))return null;
   using(var s=new MemoryStream(bytes))using(var im=Image.FromStream(s,true,true))return new Bitmap(im);
  }
  static Bitmap CustomImage(string id){
   lock(Sync){
    byte[] data;if(string.IsNullOrEmpty(id)||!Custom.TryGetValue(id,out data))return null;
    Bitmap cached;if(Cache.TryGetValue(id,out cached)){
     Recent.Remove(id);Recent.AddLast(id);return cached;
    }
    try{cached=Preview(data);}catch{return null;}
    if(cached==null)return null;
    Cache[id]=cached;Recent.AddLast(id);
    while(Cache.Count>40){string expired=Recent.First.Value;Recent.RemoveFirst();Cache[expired].Dispose();Cache.Remove(expired);}
    return cached;
   }
  }
  static Dictionary<string,int> BuildSlots(){
   var d=new Dictionary<string,int>(StringComparer.OrdinalIgnoreCase);
   for(int i=0;i<16;i++)d["seed-"+(i+1).ToString("00")]=i;
   for(int i=0;i<30;i++)d["ex-"+(101+i)]=16+i;
   for(int i=0;i<ClientCatalog.Items.Length;i++)d["cl-"+(i+1).ToString("000")]=46+i;
   return d;
  }
  static Dictionary<string,string> BuildClientNames(){
   var d=new Dictionary<string,string>(StringComparer.CurrentCultureIgnoreCase);
   for(int i=0;i<ClientCatalog.Items.Length;i++)d[ClientCatalog.Items[i].Name]="cl-"+(i+1).ToString("000");
   return d;
  }
  public static bool HasPhoto(Product product){
   if(product==null)return false;
   int ignored;lock(Sync)if(Custom.ContainsKey(product.id??""))return true;return Slots.TryGetValue(ResolveKey(product),out ignored);
  }
  static string ResolveKey(Product product){
   if(!string.IsNullOrEmpty(product.photoKey))return product.photoKey;
   string name=product.name??"";
   string key;
   if(ClientNames.TryGetValue(name,out key))return key;
   return ExistingNames.TryGetValue(name,out key)?key:"";
  }
  static Image Atlas(){
   if(attempted)return atlas;
   lock(Sync){
    if(attempted)return atlas;
    try{
     using(var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("catalog-photos.jpg")){
      if(stream!=null)using(var image=Image.FromStream(stream))atlas=new Bitmap(image);
     }
    }catch{atlas=null;}
    attempted=true;
    return atlas;
   }
  }
  public static bool Draw(Graphics g,Product product,Rectangle box){
   if(product==null||box.Width<=0||box.Height<=0)return false;
   var custom=CustomImage(product.id);
   if(custom!=null){
    var saved=g.Save();
    try{g.SetClip(box);g.InterpolationMode=InterpolationMode.HighQualityBicubic;g.PixelOffsetMode=PixelOffsetMode.HighQuality;g.DrawImage(custom,box);}finally{g.Restore(saved);}
    return true;
   }
   int slot;if(!Slots.TryGetValue(ResolveKey(product),out slot))return false;
   var image=Atlas();
   if(image==null)return false;
   var source=new Rectangle(slot%Columns*TileWidth,slot/Columns*TileHeight,TileWidth,TileHeight);
   if(source.Right>image.Width||source.Bottom>image.Height)return false;
   var state=g.Save();
   try{
    g.SetClip(box);
    g.InterpolationMode=InterpolationMode.HighQualityBicubic;
    g.PixelOffsetMode=PixelOffsetMode.HighQuality;
    g.DrawImage(image,box,source,GraphicsUnit.Pixel);
   }finally{g.Restore(state);}
   return true;
  }
 }
}